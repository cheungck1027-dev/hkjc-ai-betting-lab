#!/usr/bin/env python3
"""
Generate 100 unique, realistic Hong Kong characters for HKJC AI 賭波聯盟.
Each character has: MBTI, unique personality, betting strategy, social bonds, life events.
Designed to feel like a real community of Hong Kong people.
"""
import json
import random

random.seed(42)

# ============================================================
# 16 MBTI types with distributions matching real-world
# ============================================================
MBTI_TYPES = {
    'ISTJ': {'label': '物流師', 'color': '#4a9ecc', 'group': 'SJ守護者'},
    'ISFJ': {'label': '守衛者', 'color': '#4acc8a', 'group': 'SJ守護者'},
    'ESTJ': {'label': '總經理', 'color': '#cc4a4a', 'group': 'SJ守護者'},
    'ESFJ': {'label': '執政官', 'color': '#cc8a4a', 'group': 'SJ守護者'},
    'ISTP': {'label': '鑒賞家', 'color': '#7a4acc', 'group': 'SP探險家'},
    'ISFP': {'label': '探險家', 'color': '#4acccc', 'group': 'SP探險家'},
    'ESTP': {'label': '企業家', 'color': '#cc4a8a', 'group': 'SP探險家'},
    'ESFP': {'label': '表演者', 'color': '#cccc4a', 'group': 'SP探險家'},
    'INTJ': {'label': '建築師', 'color': '#2a6e9e', 'group': 'NT理性者'},
    'INTP': {'label': '邏輯學家', 'color': '#2a9e6e', 'group': 'NT理性者'},
    'ENTJ': {'label': '指揮官', 'color': '#9e2a2a', 'group': 'NT理性者'},
    'ENTP': {'label': '辯論家', 'color': '#9e6e2a', 'group': 'NT理性者'},
    'INFJ': {'label': '提倡者', 'color': '#6e2a9e', 'group': 'NF理想家'},
    'INFP': {'label': '調停者', 'color': '#2a9e9e', 'group': 'NF理想家'},
    'ENFJ': {'label': '主人公', 'color': '#9e2a6e', 'group': 'NF理想家'},
    'ENFP': {'label': '競選者', 'color': '#9e9e2a', 'group': 'NF理想家'},
}

# ============================================================
# 20+ Betting Strategies
# ============================================================
STRATEGIES = [
    # Analytical
    'value',          # 數據分析找value
    'statistical',    # 統計模型
    'contrarian',     # 逆市操作
    'arbitrage',      # 套利思維
    # Emotional/Intuitive
    'excitement',     # 追求刺激
    'gut_feeling',    # 直覺型
    'superstitious',  # 迷信型
    'dream',          # 發夢/預感
    # Conservative
    'safe_favorite',  # 只買大熱門
    'ultra_safe',     # 超保守
    'bankroll',       # 資金管理優先
    # Social
    'follow_trend',   # 跟風
    'contrarian_social', # 反群眾
    'influencer',     # 帶風向
    # Narrative
    'story',          # 故事驅動
    'loyalty',        # 忠誠支持者
    'underdog',       # 撐細狗
    # Strategic
    'portfolio',      # 組合投資
    'momentum',       # 追勢
    'hedging',        # 對沖
    # Wild
    'yolo',           # All in
    'random',         # 隨機
    'ethical',        # 道德投注
    'seasonal',       # 看時間/季節
]

STRATEGY_LABELS = {
    'value': '數據分析型', 'statistical': '統計模型型', 'contrarian': '逆市操作型',
    'arbitrage': '套利思維型', 'excitement': '追求刺激型', 'gut_feeling': '直覺型',
    'superstitious': '迷信型', 'dream': '預感型', 'safe_favorite': '穩陣大熱型',
    'ultra_safe': '超級保守型', 'bankroll': '資金管理型', 'follow_trend': '跟風型',
    'contrarian_social': '反群眾型', 'influencer': '帶風向型', 'story': '故事驅動型',
    'loyalty': '忠誠支持型', 'underdog': '撐細狗型', 'portfolio': '組合投資型',
    'momentum': '追勢型', 'hedging': '對沖型', 'yolo': 'YOLO型', 'random': '隨機型',
    'ethical': '道德投注型', 'seasonal': '時節型',
}

DECISION_STYLES = [
    'analytical', 'intuitive', 'cautious', 'strategic', 'follower',
    'traditional', 'dramatic', 'experiential', 'ethical', 'yolo',
    'social', 'systematic', 'emotional', 'philosophical', 'impulsive',
]

STRESS_RESPONSES = [
    'withdraw', 'impulsive', 'freeze', 'adapt', 'avoid',
    'refuse', 'perform', 'chase', 'guilt', 'double_down',
    'meditate', 'vent', 'analyze', 'socialize', 'deny',
]

# ============================================================
# Character Templates - Hong Kong realistic backgrounds
# ============================================================
OCCUPATIONS = [
    # Professional
    ('項目經理', 28, 45, '👩‍💼'), ('金融VP', 30, 50, '🧑‍💼'), ('律師', 28, 55, '⚖️'),
    ('會計師', 26, 40, '🧮'), ('醫生', 30, 60, '👨‍⚕️'), ('工程師', 25, 45, '👨‍💻'),
    ('建築師', 28, 50, '🏗️'), ('大學教授', 35, 65, '👨‍🏫'), ('銀行經理', 30, 50, '🏦'),
    ('投資分析師', 25, 40, '📈'),
    # Creative
    ('藝術系學生', 18, 25, '🧑‍🎨'), ('攝影師', 22, 40, '📷'), ('設計師', 23, 38, '🎨'),
    ('YouTuber', 18, 30, '🎬'), ('音樂人', 20, 35, '🎵'), ('生活網紅', 22, 35, '💃'),
    ('作家', 25, 55, '✍️'), ('插畫師', 22, 35, '🖌️'),
    # Blue Collar / Traditional
    ('菜檔檔主', 40, 65, '👩‍🍳'), ('紅的司機', 35, 60, '🚕'), ('茶餐廳老闆', 38, 60, '🍜'),
    ('地盤工人', 25, 55, '👷'), ('巴士司機', 30, 58, '🚌'), ('街市魚販', 40, 65, '🐟'),
    ('麵包師傅', 28, 50, '🍞'), ('水電師傅', 30, 55, '🔧'), ('保安員', 35, 65, '🛡️'),
    ('郵差', 30, 55, '📮'),
    # Service / Retail
    ('髮型師', 22, 40, '💇'), ('健身教練', 22, 38, '💪'), ('酒店前台', 22, 35, '🏨'),
    ('空姐', 23, 35, '✈️'), ('護士', 24, 45, '👩‍⚕️'), ('社工', 25, 40, '🌱'),
    ('幼稚園老師', 24, 40, '👩‍🏫'), ('售貨員', 18, 35, '🛍️'),
    # Tech
    ('程式員', 23, 40, '💻'), ('數據分析師', 24, 38, '📊'), ('IT支援', 22, 40, '🖥️'),
    ('遊戲開發者', 22, 35, '🎮'), ('AI研究員', 25, 40, '🤖'),
    # Students / Young
    ('大學一年級生', 18, 22, '🧑‍🎤'), ('中學生', 14, 18, '📚'), ('研究生', 23, 30, '🎓'),
    ('DSE考生', 17, 19, '📝'), ('交換生', 19, 24, '🌍'),
    # Retired / Senior
    ('退休公務員', 58, 75, '👴'), ('退休教師', 58, 70, '👵'), ('退休警察', 55, 70, '🫡'),
    ('退休商人', 55, 75, '🧓'),
    # Others
    ('自由工作者', 25, 40, '🏠'), ('Uber司機', 25, 45, '🚗'), ('快遞員', 22, 40, '📦'),
    ('股票經紀', 28, 50, '💹'), ('記者', 24, 45, '📰'), ('廚師', 22, 50, '👨‍🍳'),
    ('花店老闆', 28, 50, '🌸'), ('寵物店員', 20, 35, '🐕'), ('漫畫家', 22, 40, '📕'),
    ('電台DJ', 25, 40, '📻'), ('瑜伽教練', 25, 40, '🧘'), ('外賣仔', 18, 30, '🛵'),
]

# Common HK surnames + first names
SURNAMES_M = ['陳', '林', '黃', '張', '李', '王', '劉', '吳', '鄭', '周', '蔡', '何', '曾', '馬', '蕭', '梁', '趙', '謝', '許', '盧']
SURNAMES_F = ['陳', '林', '黃', '張', '李', '王', '劉', '吳', '鄭', '周', '蔡', '何', '曾', '馬', '蕭', '梁', '趙', '謝', '許', '盧']
FIRST_NAMES_M = ['俊傑', '志明', '偉強', '家豪', '浩然', '子軒', '嘉明', '文傑', '國強', '建明', '永康', '銘', '昊天', '晉', '朗', '瑋', '正', '哲', '賢', '達']
FIRST_NAMES_F = ['雨涵', '詩琪', '嘉欣', '美琪', '慧敏', '雅婷', '芷晴', '紫晴', '曉琳', '佩珊', '潔', '倩', '萱', '琪', '瑤', '穎', '雯', '瑩', '淑', '蘭']

# English-style names (some HK people use English names)
ENGLISH_NAMES = ['Jessica', 'Tony', 'Kelvin', 'Samantha', 'Jason', 'Vivian', 'Alex', 'Cathy', 'Derek', 'Fiona',
                 'Gary', 'Helen', 'Ivan', 'Karen', 'Leo', 'Mandy', 'Nick', 'Penny', 'Ray', 'Shirley',
                 'Tommy', 'Venus', 'Wilson', 'Yolanda', 'Brian', 'Diana', 'Eric', 'Grace', 'Hugo', 'Iris']

# Nicknames (some characters have 花名)
NICKNAMES = ['大佬', '阿姐', '肥仔', '靚仔', '靚女', '大B', '細佬', '老友記', '波牛', '波霸',
             '阿伯', '阿叔', '阿嬸', '老豆', '阿媽', '大師', '鬼佬', '小丸子', '公主', '少爺']

# Preferred leagues
LEAGUE_POOLS = {
    'mainstream': ['英格蘭超級聯賽', '歐洲聯賽冠軍盃'],
    'european': ['英格蘭超級聯賽', '歐洲聯賽冠轉盃', '西班牙甲組聯賽', '意大利甲組聯賽', '德國甲組聯賽'],
    'asia': ['日本職業聯賽', '南韓職業聯賽', '澳洲甲組聯賽'],
    'americas': ['巴西甲組聯賽', '美國職業足球大聯盟', '阿根廷甲組聯賽'],
    'women': ['女子亞洲盃', '女子瑞典盃', '女子西班牙盃', '女子德國盃'],
    'lower': ['英格蘭冠軍聯賽', '英格蘭甲組聯賽', '荷蘭甲組聯賽'],
    'all': ['英格蘭超級聯賽', '歐洲聯賽冠軍盃', '歐霸盃', '西班牙甲組聯賽', '意大利甲組聯賽'],
}

# Personality templates
PERSONALITY_TEMPLATES = {
    'analytical': [
        '理性分析師，相信數據勝過直覺。會用Excel計算期望值。',
        '凡事講邏輯，唔信運氣。每場波都要做功課先落注。',
        '數學思維型，用概率論分析每個賠率。',
        '會用Python爬數據，建模分析。',
    ],
    'emotional': [
        '感性派，完全跟心情買波。開心就大手，唔開心就唔買。',
        '容易被比賽氣氛感染，睇直播會衝動加注。',
        '心思細密，會因為一個球員故事而改變投注。',
    ],
    'social': [
        '社交型，買波主要為咗同朋友有話題。',
        '群組活躍份子，成日分享自己嘅投注。',
        '意見領袖，朋友圈D人都聽佢講。',
    ],
    'conservative': [
        '精打細算，每分錢都要想清楚。',
        '超級保守，寧願唔賺都唔想輸。',
        '穩陣派，只買大熱門。',
    ],
    'wild': [
        'YOLO青年，搏一鋪大嘅。',
        '賭徒心態，越輸越追。',
        '瘋狂型，買波完全唔跟邏輯。',
    ],
    'strategic': [
        '策略型投資者，把足球投注當Portfolio Management。',
        '長線思維，唔在乎個別場次輸贏。',
        '用凱利公式計注碼。',
    ],
}

BUDGET_STYLES = ['spread', 'heavy', 'minimal', 'balanced', 'tiny', 'token', 'dramatic', 'confident', 'reluctant', 'all_in', 'calculated', 'impulse']

# ============================================================
# Generate 100 characters
# ============================================================
def generate_characters():
    characters = []
    used_names = set()
    mbti_list = list(MBTI_TYPES.keys())

    for i in range(1, 101):
        # Assign MBTI - roughly even distribution with some skew
        mbti = mbti_list[(i - 1) % 16]
        # Add some variation
        if random.random() < 0.3:
            mbti = random.choice(mbti_list)

        mbti_info = MBTI_TYPES[mbti]

        # Pick occupation
        occ = random.choice(OCCUPATIONS)
        title, age_min, age_max, emoji = occ
        age = random.randint(age_min, age_max)

        # Generate name
        gender = 'F' if random.random() < 0.5 else 'M'
        use_english = random.random() < 0.25  # 25% use English names
        use_nickname = random.random() < 0.15  # 15% use nicknames

        if use_nickname and NICKNAMES:
            name = random.choice(NICKNAMES)
            NICKNAMES.remove(name) if name in NICKNAMES else None
        elif use_english and ENGLISH_NAMES:
            name = random.choice(ENGLISH_NAMES)
            ENGLISH_NAMES.remove(name) if name in ENGLISH_NAMES else None
        else:
            if gender == 'M':
                surname = random.choice(SURNAMES_M)
                first = random.choice(FIRST_NAMES_M)
            else:
                surname = random.choice(SURNAMES_F)
                first = random.choice(FIRST_NAMES_F)
            name = surname + first

        # Ensure unique
        while name in used_names:
            name = random.choice(SURNAMES_M) + random.choice(FIRST_NAMES_M if random.random() > 0.5 else FIRST_NAMES_F)
        used_names.add(name)

        # Strategy based on personality type
        if mbti[2] == 'T':  # Thinking types
            strategy_pool = ['value', 'statistical', 'contrarian', 'arbitrage', 'portfolio', 'hedging', 'bankroll', 'momentum']
        elif mbti[2] == 'F':  # Feeling types
            strategy_pool = ['excitement', 'gut_feeling', 'story', 'loyalty', 'underdog', 'ethical', 'dream', 'follow_trend']
        else:
            strategy_pool = STRATEGIES

        # Introverts tend toward analytical, extroverts toward social
        if mbti[0] == 'I':
            strategy_pool += ['value', 'statistical', 'ultra_safe', 'bankroll']
        else:
            strategy_pool += ['follow_trend', 'influencer', 'story', 'excitement']

        # Young people more yolo
        if age < 25:
            strategy_pool += ['yolo', 'excitement', 'random']
        # Older people more conservative
        if age > 55:
            strategy_pool += ['ultra_safe', 'safe_favorite', 'bankroll']

        strategy = random.choice(strategy_pool)

        # Risk tolerance
        risk_base = {
            'value': 0.3, 'statistical': 0.25, 'contrarian': 0.6, 'arbitrage': 0.35,
            'excitement': 0.8, 'gut_feeling': 0.55, 'superstitious': 0.5, 'dream': 0.6,
            'safe_favorite': 0.15, 'ultra_safe': 0.05, 'bankroll': 0.3, 'follow_trend': 0.2,
            'contrarian_social': 0.65, 'influencer': 0.5, 'story': 0.6, 'loyalty': 0.4,
            'underdog': 0.7, 'portfolio': 0.45, 'momentum': 0.5, 'hedging': 0.3,
            'yolo': 0.9, 'random': 0.7, 'ethical': 0.1, 'seasonal': 0.35,
        }.get(strategy, 0.4)
        risk = round(min(1, max(0.02, risk_base + random.uniform(-0.15, 0.15))), 2)

        # Bet range (min, max bets per round)
        if risk < 0.2:
            bet_range = [0, random.randint(1, 3)]
        elif risk < 0.5:
            bet_range = [1, random.randint(3, 6)]
        elif risk < 0.7:
            bet_range = [2, random.randint(4, 8)]
        else:
            bet_range = [2, random.randint(3, 6)]

        # Preferred leagues
        if strategy in ['ethical']:
            leagues = LEAGUE_POOLS['women']
        elif strategy in ['follow_trend', 'story', 'loyalty', 'excitement']:
            leagues = LEAGUE_POOLS['mainstream'] + random.choice([LEAGUE_POOLS['european'], LEAGUE_POOLS['all']])
        elif strategy in ['contrarian', 'underdog']:
            leagues = LEAGUE_POOLS['lower'] + LEAGUE_POOLS['americas']
        elif random.random() < 0.3:
            leagues = LEAGUE_POOLS['all']
        else:
            pool_key = random.choice(list(LEAGUE_POOLS.keys()))
            leagues = LEAGUE_POOLS[pool_key]
        leagues = list(set(leagues))

        # Budget style
        budget_style = random.choice(BUDGET_STYLES)
        max_single_bet_pct = round(random.uniform(0.03, 0.5), 2)
        if strategy in ['ultra_safe', 'ethical', 'bankroll']:
            max_single_bet_pct = round(random.uniform(0.03, 0.1), 2)
        elif strategy in ['yolo']:
            max_single_bet_pct = round(random.uniform(0.3, 0.8), 2)

        # Decision style
        ds_map = {
            'value': 'analytical', 'statistical': 'systematic', 'contrarian': 'strategic',
            'excitement': 'impulsive', 'gut_feeling': 'experiential', 'story': 'dramatic',
            'follow_trend': 'follower', 'ethical': 'ethical', 'yolo': 'yolo',
            'safe_favorite': 'cautious', 'ultra_safe': 'traditional',
        }
        decision_style = ds_map.get(strategy, random.choice(DECISION_STYLES))

        # Stress response
        stress = random.choice(STRESS_RESPONSES)

        # Social energy
        if mbti[0] == 'E':
            social = random.choice(['high', 'very_high', 'medium'])
        else:
            social = random.choice(['low', 'medium', 'low'])

        # Personality text
        ptype = 'analytical' if strategy in ['value', 'statistical', 'arbitrage', 'bankroll'] else \
                'strategic' if strategy in ['portfolio', 'hedging', 'momentum', 'contrarian'] else \
                'conservative' if strategy in ['safe_favorite', 'ultra_safe'] else \
                'wild' if strategy in ['yolo', 'random'] else \
                'social' if strategy in ['follow_trend', 'influencer'] else \
                'emotional'
        personality = random.choice(PERSONALITY_TEMPLATES.get(ptype, PERSONALITY_TEMPLATES['emotional']))

        # Traits
        traits = {
            'dataOriented': strategy in ['value', 'statistical', 'arbitrage', 'portfolio', 'bankroll'],
            'emotional': strategy in ['excitement', 'gut_feeling', 'story', 'dream', 'loyalty'],
            'impulsive': strategy in ['excitement', 'yolo', 'random', 'dream'],
            'superstitious': strategy in ['superstitious', 'dream', 'seasonal'] or random.random() < 0.2,
        }

        # Starting wallet varies by character background
        if title in ['金融VP', '律師', '醫生', '銀行經理', '投資分析師', '股票經紀', '建築師']:
            wallet = random.choice([15000, 20000, 25000, 30000])
        elif title in ['中學生', 'DSE考生']:
            wallet = random.choice([2000, 3000, 5000])
        elif title in ['大學一年級生', '研究生', '交換生']:
            wallet = random.choice([5000, 8000])
        elif title in ['退休公務員', '退休教師', '退休警察', '退休商人']:
            wallet = random.choice([10000, 15000, 20000])
        elif title in ['茶餐廳老闆', '花店老闆', '菜檔檔主']:
            wallet = random.choice([8000, 10000, 12000])
        else:
            wallet = random.choice([8000, 10000, 12000, 15000])

        char = {
            'id': i,
            'name': name,
            'age': age,
            'title': title,
            'emoji': emoji,
            'gender': gender,
            'mbti': mbti,
            'mbtiLabel': mbti_info['label'],
            'mbtiColor': mbti_info['color'],
            'mbtiGroup': mbti_info['group'],
            'risk': risk,
            'betRange': bet_range,
            'strategy': strategy,
            'strategyLabel': STRATEGY_LABELS.get(strategy, strategy),
            'preferLeagues': leagues,
            'budgetStyle': budget_style,
            'maxSingleBetPct': max_single_bet_pct,
            'personality': personality,
            'decisionStyle': decision_style,
            'stressResponse': stress,
            'socialEnergy': social,
            'traits': traits,
            'wallet': wallet,
        }
        characters.append(char)

    # ============================================================
    # Generate Social Bonds (30-50 relationships)
    # ============================================================
    bond_types = [
        ('朋友', '成日一齊睇波'),
        ('死對頭', '每次投注都要反著來'),
        ('師徒', '跟住師傅學投注'),
        ('暗中跟注', '偷偷跟住對方買'),
        ('同事', '午飯時間討論波經'),
        ('情侶', '一齊研究賠率'),
        ('鄰居', '茶樓一齊傾波'),
        ('家人', '阿爸帶仔買波'),
        ('群組友', '同一個WhatsApp群'),
        ('競爭對手', '鬥勝率，鬥長線贏面'),
    ]

    bonds = []
    for _ in range(45):
        a = random.randint(1, 100)
        b = random.randint(1, 100)
        while b == a:
            b = random.randint(1, 100)
        bt, bd = random.choice(bond_types)
        na = next(c['name'] for c in characters if c['id'] == a)
        nb = next(c['name'] for c in characters if c['id'] == b)
        bonds.append({
            'charA': a, 'charB': b,
            'type': bt,
            'description': f'{na}同{nb}{bd}'
        })

    # ============================================================
    # Generate Life Events (2-4 per character, 200+ total)
    # ============================================================
    event_templates = [
        ('升職加薪！心情大好', 'happy', 1.15),
        ('被老闆鬧咗一頓', 'stressed', 0.9),
        ('女朋友煮咗靚飯', 'happy', 1.05),
        ('投資蝕咗錢', 'anxious', 0.85),
        ('中咗六合彩安慰獎', 'excited', 1.2),
        ('生日快樂！', 'happy', 1.1),
        ('同朋友吵咗架', 'upset', 0.9),
        ('食咗米芝蓮餐廳', 'happy', 1.05),
        ('發現隔離位中咗大獎', 'envious', 1.15),
        ('屋企漏水要維修', 'stressed', 0.85),
        ('考試成績好好', 'proud', 1.1),
        ('被人放飛機', 'annoyed', 0.95),
        ('收到利是錢', 'happy', 1.1),
        ('感冒唔舒服', 'sick', 0.8),
        ('追到鍾意嘅人', 'ecstatic', 1.2),
        ('俾交通罰單', 'frustrated', 0.9),
        ('睇完勵志電影好有衝勁', 'motivated', 1.15),
        ('夢見自己中大獎', 'superstitious', 1.3),
        ('朋友結婚要俾人情', 'stressed', 0.9),
        ('學識咗新技能', 'confident', 1.1),
        ('車壞咗要修理', 'stressed', 0.85),
        ('客人俾咗小費', 'happy', 1.05),
        ('鄰居投訴太嘈', 'stressed', 0.95),
        ('去咗旅行好開心', 'relaxed', 1.1),
        ('股票升咗10%', 'bullish', 1.2),
    ]

    life_events = {}
    for char in characters:
        num_events = random.randint(2, 4)
        events = random.sample(event_templates, min(num_events, len(event_templates)))
        life_events[str(char['id'])] = [
            {'text': e[0], 'moodEffect': e[1], 'budgetMod': e[2]}
            for e in events
        ]

    return characters, bonds, life_events


if __name__ == '__main__':
    chars, bonds, events = generate_characters()

    # Save characters
    with open('data/characters.json', 'w') as f:
        json.dump(chars, f, ensure_ascii=False, indent=2)

    # Save social bonds
    with open('data/social-bonds.json', 'w') as f:
        json.dump(bonds, f, ensure_ascii=False, indent=2)

    # Save life events
    with open('data/life-events.json', 'w') as f:
        json.dump(events, f, ensure_ascii=False, indent=2)

    # Generate fresh state with 100 characters
    state = {
        'memories': {},
        'roundNum': 0,
        'activeBets': [],
        'history': [],
        'lastScrapeTime': None,
        'lastSettleTime': None,
    }
    for c in chars:
        state['memories'][str(c['id'])] = {
            'wallet': c['wallet'],
            'rounds': [],
            'totalPnL': 0,
            'totalWins': 0,
            'totalLosses': 0,
            'winStreak': 0,
            'loseStreak': 0,
            'totalBetsPlaced': 0,
            'totalBetsWon': 0,
        }

    with open('data/state.json', 'w') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

    # Stats
    print(f"✅ Generated {len(chars)} characters")
    print(f"✅ Generated {len(bonds)} social bonds")
    print(f"✅ Generated {sum(len(v) for v in events.values())} life events")

    # MBTI distribution
    from collections import Counter
    mbti_dist = Counter(c['mbti'] for c in chars)
    print(f"\nMBTI分佈:")
    for m, count in sorted(mbti_dist.items(), key=lambda x: -x[1]):
        print(f"  {m} ({MBTI_TYPES[m]['label']}): {count}人")

    strat_dist = Counter(c['strategy'] for c in chars)
    print(f"\n策略分佈:")
    for s, count in sorted(strat_dist.items(), key=lambda x: -x[1]):
        print(f"  {STRATEGY_LABELS.get(s, s)}: {count}人")

    wallet_total = sum(c['wallet'] for c in chars)
    print(f"\n總資金: ${wallet_total:,}")
    print(f"平均資金: ${wallet_total/len(chars):,.0f}")
    print(f"年齡範圍: {min(c['age'] for c in chars)}-{max(c['age'] for c in chars)}")
