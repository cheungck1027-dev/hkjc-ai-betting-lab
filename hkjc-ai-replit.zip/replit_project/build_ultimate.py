#!/usr/bin/env python3
"""Build ULTIMATE index.html: uses build_dashboard.py as base, then injects:
  1. ROI% column in leaderboard
  2. Person detail expansion (clickable rows → bet history + thinking)
  3. Branding: "HKJC AI 投注實驗室" + "⚡真實數據" badge
  4. Live viewer link (separate page)
"""
import json, os, subprocess, re

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# ── Step 0: Regenerate dashboard.html ──
dashboard_py = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'build_dashboard.py')
print("Regenerating dashboard.html ...")
result = subprocess.run(['python3', dashboard_py], cwd=BASE, capture_output=True, text=True)
print(result.stdout.strip())
if result.returncode != 0:
    print("ERROR:", result.stderr)
    exit(1)

# ── Step 1: Load data for person detail ──
def load_json(name, default=None):
    path = f'{BASE}/{name}'
    if not os.path.exists(path): return default if default is not None else []
    with open(path) as f: return json.load(f)

st = load_json('state.json', {'memories':{},'activeBets':[],'history':[],'roundNum':0})
bl = load_json('bets-log.json', [])
chars = load_json('characters.json', [])
achievements = load_json('achievements.json', {})

# Build person detail dict: cid → {settled, active, bets (with thinking), evo, profile}
pd = {}
for c in chars:
    cid = str(c['id'])
    mem = st['memories'].get(cid, {})

    # Settled bets (compact: with match info, last 6 only)
    settled = []
    for r in mem.get('betResults', [])[-6:]:
        sr = {'w': r.get('won'), 'p': r.get('pnl',0), 'b': r.get('betType',''), 'o': r.get('odds',0)}
        if r.get('home'): sr['h'] = r['home']
        if r.get('away'): sr['a'] = r['away']
        if r.get('choiceLabel'): sr['c'] = r['choiceLabel']
        if r.get('amount'): sr['am'] = r['amount']
        if r.get('result'): sr['rs'] = r['result']
        settled.append(sr)

    # Active bets for this character (minimal)
    active = []
    for b in st.get('activeBets', []):
        if b.get('charId') == c['id']:
            active.append({
                'h': b['home'], 'a': b['away'],
                'b': b['betType'], 'c': b['choiceLabel'],
                'o': b['odds'], 'am': b['amount']
            })

    # Bet history from bets-log (with thinking, keep last 5 per char)
    bets_hist = []
    for rd in bl:
        for cb in rd.get('characterBets', []):
            if cb['charId'] == c['id']:
                for b in cb.get('bets', []):
                    # Keep 4 key thinking lines (decision + context)
                    raw_th = b.get('thinking', [])
                    _keep = ('✅','📰','⚖️','📈','📊','🛡️','🔄','🐶','🎨','📐','🎰','📖','🌱','🚀')
                    filtered_th = [t for t in raw_th if any(t.startswith(p) for p in _keep)][:4]
                    bets_hist.append({
                        'r': rd['round'],
                        'h': b.get('home',''), 'a': b.get('away',''),
                        'b': b['betType'], 'c': b['choiceLabel'],
                        'o': b['odds'], 'am': b['amount'],
                        'th': filtered_th
                    })
    bets_hist = bets_hist[-3:]

    # Evolution from all rounds
    evo = []
    for rd in bl:
        for cb in rd.get('characterBets', []):
            if cb['charId'] == c['id']:
                for e in cb.get('evolution', []):
                    evo.append(e)
    evo = evo[-3:]  # keep last 3

    # Round participation summary (compact)
    round_summary = []
    for rd in bl:
        for cb in rd.get('characterBets', []):
            if cb['charId'] == c['id']:
                round_summary.append({
                    'r': rd['round'], 'n': cb['betsCount'],
                    'w': cb.get('totalWagered', 0),
                })

    # Profile info (compact)
    wallet = mem.get('wallet', c.get('wallet', 10000))
    pnl = round(wallet - 10000, 2)
    tp = mem.get('totalBetsPlaced', 0)
    tw = mem.get('totalBetsWon', 0)
    pd[cid] = {
        'a': c.get('age', 0), 't': c.get('title', ''),
        'ml': c.get('mbtiLabel', ''),
        'tr': [k for k,v in c.get('traits', {}).items() if v][:3] if isinstance(c.get('traits'), dict) else [],
        's': settled, 'ac': active, 'bt': bets_hist, 'ev': evo,
        'rs': round_summary,
        'wt': wallet, 'pnl': pnl, 'tp': tp, 'tw': tw,
    }

j = lambda d: json.dumps(d, ensure_ascii=False)
pd_json = j(pd)
print(f"Person detail data: {len(pd_json):,} bytes ({len(pd_json)/1024:.0f} KB)")

# ── Step 2: Read dashboard.html and inject enhancements ──
with open(f'{BASE}/dashboard.html', 'r') as f:
    html = f.read()

# ─── 2a: Branding ───
html = html.replace(
    '🏆 HKJC AI 賭波聯盟 v4 Ultimate',
    '🏆 HKJC AI 投注實驗室 <span style="background:#4caf50;color:#fff;padding:3px 10px;border-radius:12px;font-size:0.4em;vertical-align:middle;margin-left:8px">⚡真實數據</span>'
)
html = html.replace(
    '<title>HKJC AI 賭波聯盟 v4 Ultimate</title>',
    '<title>HKJC AI 投注實驗室</title>'
)

# Add "所有賽事及賠率數據來自香港賽馬會" note in header stats
html = html.replace(
    '</div>\n</div>\n\n<div class="tabs">',
    '  <div class="stat" style="font-size:0.75em;color:#888;border-color:#333">所有賽事及賠率數據來自香港賽馬會</div>\n  </div>\n</div>\n\n<div class="tabs">'
)

# ─── 2b: Add ROI% column to leaderboard header ───
html = html.replace(
    '<th onclick="sortLB(\'pnl\')">盈虧</th>',
    '<th onclick="sortLB(\'roi\')">ROI%</th>\n        <th onclick="sortLB(\'pnl\')">盈虧</th>'
)

# ─── 2c: Modify leaderboard rendering in-place ───

# Add ROI to sort function
html = html.replace(
    "case'pnl':va=a.pnl;vb=b.pnl;break;",
    "case'roi':va=a.roi;vb=b.roi;break;\n    case'pnl':va=a.pnl;vb=b.pnl;break;"
)

# Modify the leaderboard row rendering to add ROI column + onclick for person detail
# Replace the existing row template
html = html.replace(
    '''document.getElementById('lb-body').innerHTML=list.map((p,i)=>`<tr class="lb-row">
    <td class="lb-rank">${rankMedal(i)}</td>
    <td><div class="lb-name-cell"><span class="lb-emoji">${p.e}</span><div><b>${p.n}</b><div class="lb-title">${p.t}</div></div></div></td>
    <td><span class="mbti-badge" style="background:${p.mc}22;color:${p.mc}">${p.mb}</span></td>
    <td><span class="strat-badge">${p.sl}</span></td>
    <td>${wrDisplay(p.wr)}</td><td>${wrDisplay(p.w10)}</td><td>${wrDisplay(p.w5)}</td>
    <td>${pnlDisplay(p.pnl)}</td>
    <td style="color:#d4af37">$${p.w.toLocaleString()}</td>
    <td>${p.tp>0?p.tw+'/'+p.tp:(p.ac>0?'<span style="color:#888">'+p.ac+'待結</span>':'0')}</td>
    <td>${streakDisplay(p.ws,p.ls)}</td>
    <td>${achBadges(p.ach)}</td>
  </tr>`).join('');''',
    '''document.getElementById('lb-body').innerHTML=list.map((p,i)=>{
    const cid=p.id;
    return`<tr class="lb-row" onclick="togglePerson('${cid}',this)">
    <td class="lb-rank">${rankMedal(i)}</td>
    <td><div class="lb-name-cell"><span class="lb-emoji">${p.e}</span><div><b>${p.n}</b><div class="lb-title">${p.t}</div></div></div></td>
    <td><span class="mbti-badge" style="background:${p.mc}22;color:${p.mc}">${p.mb}</span></td>
    <td><span class="strat-badge">${p.sl}</span></td>
    <td>${wrDisplay(p.wr)}</td><td>${wrDisplay(p.w10)}</td><td>${wrDisplay(p.w5)}</td>
    <td>${roiDisplay(p.roi)}</td>
    <td>${pnlDisplay(p.pnl)}</td>
    <td style="color:#d4af37">$${p.w.toLocaleString()}</td>
    <td>${p.tp>0?p.tw+'/'+p.tp:(p.ac>0?'<span style="color:#888">'+p.ac+'待結</span>':'0')}</td>
    <td>${streakDisplay(p.ws,p.ls)}</td>
    <td>${achBadges(p.ach)}</td>
  </tr>
  <tr class="lb-detail-row" id="detail-${cid}"><td colspan="14"><div class="pd-panel" id="pd-${cid}"></div></td></tr>`;
  }).join('');'''
)

# ─── 2d: Add person detail data + CSS + JS ───

# CSS for person detail expansion
pd_css = '''
/* Person Detail in Leaderboard */
.lb-row{cursor:pointer;transition:background 0.15s}
.lb-row:hover{background:#1f2a60!important}
.lb-row.expanded{background:#1a2860!important;border-left:3px solid #d4af37}
.lb-detail-row{display:none}
.lb-detail-row.show{display:table-row}
.lb-detail-row td{padding:0!important;background:#0d1533}
.pd-panel{padding:16px;animation:pdSlide 0.2s ease-out}
@keyframes pdSlide{from{opacity:0;max-height:0}to{opacity:1;max-height:2000px}}
.pd-grid{display:grid;grid-template-columns:1fr 1fr;gap:15px}
@media(max-width:768px){.pd-grid{grid-template-columns:1fr}}
.pd-section{background:#1a2252;border-radius:8px;padding:12px;border:1px solid #2a3a6a}
.pd-section h4{color:#d4af37;margin-bottom:8px;font-size:0.9em}
.pd-bet{background:#0d1b3e;border-radius:6px;padding:8px 10px;margin-bottom:6px;border-left:3px solid #2a3a6a;font-size:0.85em}
.pd-bet.won{border-left-color:#4caf50}
.pd-bet.lost{border-left-color:#ef5350}
.pd-bet.active{border-left-color:#d4af37}
.pd-trait{display:inline-block;padding:2px 8px;border-radius:10px;font-size:0.7em;background:rgba(212,175,55,0.1);color:#d4af37;margin:2px}
.pd-evo{padding:4px 0;font-size:0.82em;border-bottom:1px solid #1a2252}
.pd-thinking{background:#0a1128;border-radius:6px;padding:10px 12px;margin-top:6px;font-size:0.82em;line-height:1.6;color:#bbb;border:1px solid #1a2a5a}
.pd-stat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:8px}
.pd-stat{text-align:center;background:#0d1b3e;padding:6px;border-radius:6px}
.pd-stat .v{font-size:1.1em;font-weight:bold;color:#d4af37}
.pd-stat .l{font-size:0.7em;color:#888}

/* Full-page person detail overlay */
.person-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:#0a0f2e;z-index:9999;overflow-y:auto;display:none;animation:overlayIn 0.25s ease-out}
.person-overlay.show{display:block}
@keyframes overlayIn{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
.person-overlay-inner{max-width:900px;margin:0 auto;padding:20px}
.person-back-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;margin-bottom:16px;background:#1a2252;border:1px solid #2a3a6a;border-radius:10px;color:#d4af37;font-size:0.95em;cursor:pointer;transition:all 0.15s}
.person-back-btn:hover{background:#2a3a6a;transform:translateX(-3px)}

/* Clickable character names */
.char-link{color:#e0e8ff;cursor:pointer;transition:all 0.15s;border-bottom:1px dashed rgba(212,175,55,0.3);padding-bottom:1px}
.char-link:hover{color:#d4af37;border-bottom-color:#d4af37}
'''

# JS for ROI display + person detail
pd_js = f'''
const PD={pd_json};

function roiDisplay(roi){{
  if(roi==null||roi===undefined)return'<span style="color:#888">—</span>';
  if(roi===0)return'<span style="color:#888">0%</span>';
  const color=roi>0?'#4caf50':'#ef5350';
  const sign=roi>0?'+':'';
  return`<span style="color:${{color}};font-weight:bold">${{sign}}${{roi.toFixed(1)}}%</span>`;
}}

// Add ROI to leaderboard data
LB.forEach(p=>{{p.roi=Math.round((p.w-10000)/100*10)/10;}});

function togglePerson(cid, rowEl) {{
  const dr = document.getElementById('detail-'+cid);
  if(!dr) return;
  const isOpen = dr.classList.contains('show');
  // Close all
  document.querySelectorAll('.lb-detail-row.show').forEach(r=>r.classList.remove('show'));
  document.querySelectorAll('.lb-row.expanded').forEach(r=>r.classList.remove('expanded'));
  if(!isOpen) {{
    dr.classList.add('show');
    rowEl.classList.add('expanded');
    renderPersonPanel(cid);
  }}
}}

function renderPersonPanel(cid) {{
  const el = document.getElementById('pd-'+cid);
  if(!el) return;
  const d = PD[cid];
  const c = charMap[cid];
  if(!c) {{ el.innerHTML='<div style="color:#888;padding:20px">無數據</div>'; return; }}

  const lb = LB.find(p=>String(p.id)===String(cid));
  const wallet = d ? d.wt : (lb ? lb.w : 10000);
  const pnl = d ? d.pnl : (lb ? lb.pnl : 0);
  const roi = Math.round((wallet-10000)/100*10)/10;
  const tp = d ? d.tp : (lb ? lb.tp : 0);
  const tw = d ? d.tw : (lb ? lb.tw : 0);
  const wr = tp > 0 ? Math.round(tw/tp*100) : -1;

  let h = '';

  // Profile header
  h += `<div style="display:flex;align-items:center;gap:15px;margin-bottom:15px;flex-wrap:wrap">
    <span style="font-size:2.5em">${{c.e}}</span>
    <div style="flex:1">
      <div style="font-size:1.3em;font-weight:bold">${{c.n}} <span style="font-size:0.6em;color:#888">${{d?d.a+'歲 '+d.t:''}}</span></div>
      <div style="margin-top:4px">
        <span class="mbti-badge" style="background:${{c.mc}}22;color:${{c.mc}}">${{c.mb}} ${{d?d.ml:''}}</span>
        <span class="strat-badge">${{c.sl}}</span>
        ${{d?(d.tr||[]).map(t=>'<span class="pd-trait">'+t+'</span>').join(''):''}}
      </div>
    </div>
  </div>`;

  // Stats — always show even if all zeros
  h += `<div class="pd-stat-grid">
    <div class="pd-stat"><div class="v">$${{wallet.toLocaleString()}}</div><div class="l">資金</div></div>
    <div class="pd-stat"><div class="v" style="color:${{pnl>=0?'#4caf50':'#ef5350'}}">${{pnl>=0?'+':''}}$${{pnl.toLocaleString()}}</div><div class="l">盈虧</div></div>
    <div class="pd-stat"><div class="v" style="color:${{roi>=0?'#4caf50':'#ef5350'}}">${{roi>=0?'+':''}}${{roi.toFixed(1)}}%</div><div class="l">ROI</div></div>
    <div class="pd-stat"><div class="v">${{tp}}</div><div class="l">已結算</div></div>
    <div class="pd-stat"><div class="v">${{tw}}</div><div class="l">勝出</div></div>
    <div class="pd-stat"><div class="v">${{wr>=0?wr+'%':'—'}}</div><div class="l">勝率</div></div>
  </div>`;

  // Round participation summary — always show
  if(d && d.rs && d.rs.length > 0) {{
    h += '<div style="margin-bottom:12px"><h4 style="color:#d4af37;margin-bottom:6px">📅 每輪參與紀錄</h4>';
    d.rs.forEach(r => {{
      const active = r.n > 0;
      h += `<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;margin:2px;border-radius:6px;background:${{active?'#1a2860':'#151a30'}};border:1px solid ${{active?'#2a4a8a':'#1a2252'}};font-size:0.82em">
        <b style="color:#d4af37">R${{r.r}}</b>
        ${{active?'<span style="color:#4caf50">'+r.n+'注 $'+r.w.toLocaleString()+'</span>':'<span style="color:#666">pass</span>'}}
      </div>`;
    }});
    h += '</div>';
  }} else {{
    h += '<div style="color:#666;font-size:0.85em;margin-bottom:12px;padding:8px;background:#151a30;border-radius:6px">📅 暫未有參與紀錄</div>';
  }}

  h += '<div class="pd-grid">';

  // Active bets
  if(d && d.ac && d.ac.length > 0) {{
    h += '<div class="pd-section"><h4>⏳ 待結算 ('+d.ac.length+'注)</h4>';
    d.ac.forEach(b => {{
      h += `<div class="pd-bet active">
        <div><b>${{b.h}} vs ${{b.a}}</b></div>
        <span class="bi-choice ${{btClass(b.b)}}">${{b.b}}</span>
        <span style="color:#d4af37">${{b.c}} @${{b.o}}</span>
        <span style="color:#888">$${{b.am.toLocaleString()}}</span>
      </div>`;
    }});
    h += '</div>';
  }} else {{
    h += '<div class="pd-section"><h4>⏳ 待結算</h4><div style="color:#666;font-size:0.85em;padding:8px">暫無待結算投注</div></div>';
  }}

  // Settled results (enriched with match info)
  if(d && d.s && d.s.length > 0) {{
    const wins = d.s.filter(b=>b.w===true).length;
    const losses = d.s.filter(b=>b.w===false).length;
    h += '<div class="pd-section"><h4>✅ 已結算 ('+d.s.length+'注: '+wins+'勝'+losses+'負)</h4>';
    d.s.forEach(b => {{
      const cls = b.w===true?'won':b.w===false?'lost':'';
      const icon = b.w===true?'✅':b.w===false?'❌':'➖';
      const matchInfo = b.h ? b.h+' vs '+b.a : '';
      const resultInfo = b.rs ? ' 比分:'+b.rs : '';
      const choiceInfo = b.c ? ' '+b.c : '';
      h += `<div class="pd-bet ${{cls}}">
        <div>${{icon}} ${{matchInfo?'<b>'+matchInfo+'</b>':''}}</div>
        <div style="margin-top:2px">
          <span class="bi-choice ${{btClass(b.b)}}">${{b.b}}</span>${{choiceInfo}}
          <span style="color:#888">@${{b.o}}</span>
          ${{b.am?'<span style="color:#888">$'+b.am.toLocaleString()+'</span>':''}}
          → ${{pnlDisplay(b.p)}}
          ${{resultInfo?'<span style="color:#888;font-size:0.8em">'+resultInfo+'</span>':''}}
        </div>
      </div>`;
    }});
    h += '</div>';
  }} else {{
    h += '<div class="pd-section"><h4>✅ 已結算</h4><div style="color:#666;font-size:0.85em;padding:8px">暫無已結算投注</div></div>';
  }}

  // Bet history with thinking (full detail)
  if(d && d.bt && d.bt.length > 0) {{
    h += '<div class="pd-section" style="grid-column:1/-1"><h4>📝 投注歷史 + AI詳細分析 ('+d.bt.length+'注)</h4>';
    d.bt.forEach((b,idx) => {{
      const isLatest = idx === d.bt.length - 1;
      h += `<div class="pd-bet" style="${{isLatest?'border-left-color:#d4af37;background:#121d45':''}}">
        <div style="display:flex;justify-content:space-between;flex-wrap:wrap;align-items:center">
          <b>${{b.h}} vs ${{b.a}}</b>
          <span style="color:#888;font-size:0.8em">第${{b.r}}輪${{isLatest?' 🆕':''}}</span>
        </div>
        <div style="margin-top:4px">
          <span class="bi-choice ${{btClass(b.b)}}">${{b.b}}</span>
          <span style="color:#d4af37">${{b.c}} @${{b.o}}</span>
          <span style="color:#888">$${{b.am.toLocaleString()}}</span>
          <span style="color:#666;font-size:0.8em">潛在回報$${{Math.round(b.am*b.o).toLocaleString()}}</span>
        </div>
        ${{b.th&&b.th.length?'<div class="pd-thinking"><div style="color:#d4af37;font-size:0.85em;margin-bottom:4px;font-weight:bold">🧠 AI思考過程:</div>'+b.th.map(t=>'<div style="padding:2px 0;border-bottom:1px solid #1a2252">'+t+'</div>').join('')+'</div>':''}}
      </div>`;
    }});
    h += '</div>';
  }} else {{
    h += '<div class="pd-section" style="grid-column:1/-1"><h4>📝 投注歷史</h4><div style="color:#666;font-size:0.85em;padding:8px">暫無投注紀錄 — 此角色目前未有落注</div></div>';
  }}

  // Evolution
  if(d && d.ev && d.ev.length > 0) {{
    h += '<div class="pd-section" style="grid-column:1/-1"><h4>📈 角色進化</h4>';
    d.ev.forEach(e => {{
      h += '<div class="pd-evo">'+e+'</div>';
    }});
    h += '</div>';
  }}

  // Achievements
  const ach = c.ach || [];
  if(ach.length > 0) {{
    h += '<div class="pd-section" style="grid-column:1/-1"><h4>🏅 成就 ('+ach.length+'個)</h4><div class="ach-grid">';
    ach.forEach(a => {{
      h += `<div class="ach-badge"><div class="ach-icon">${{a.icon}}</div><div><div class="ach-name">${{a.name}}</div><div class="ach-desc">${{a.desc}}</div></div></div>`;
    }});
    h += '</div></div>';
  }}

  h += '</div>'; // close pd-grid
  el.innerHTML = h;
}}

// ── Full-page person detail overlay ──
let _prevTab = 0;
function goToPerson(cid) {{
  event && event.stopPropagation && event.stopPropagation();
  const overlay = document.getElementById('person-overlay');
  const content = document.getElementById('person-overlay-content');
  if(!overlay || !content) return;

  // Remember which tab we came from
  const activeTab = document.querySelector('.tab.active');
  if(activeTab) _prevTab = [...document.querySelectorAll('.tab')].indexOf(activeTab);

  // Render the person detail into overlay
  const c = charMap[cid];
  if(!c) return;

  content.innerHTML = '<div class="pd-panel" id="pd-overlay-'+cid+'"></div>';
  const pdEl = document.getElementById('pd-overlay-'+cid);
  // Reuse renderPersonPanel logic by temporarily setting the element
  const origEl = document.getElementById('pd-'+cid);

  // Build header with back button
  let headerHtml = '<div class="person-back-btn" onclick="closePerson()">← 返回</div>';
  content.innerHTML = headerHtml + '<div class="pd-panel" id="pd-overlay-'+cid+'"></div>';

  // Render person panel into overlay element
  const overlayPd = document.getElementById('pd-overlay-'+cid);
  if(overlayPd) {{
    // Call renderPersonPanel with a temporary element trick
    const tempId = 'pd-'+cid;
    let tempEl = document.getElementById(tempId);
    const hadTemp = !!tempEl;
    if(!hadTemp) {{
      tempEl = document.createElement('div');
      tempEl.id = tempId;
      tempEl.style.display = 'none';
      document.body.appendChild(tempEl);
    }}
    renderPersonPanel(cid);
    overlayPd.innerHTML = tempEl.innerHTML;
    if(!hadTemp) tempEl.remove();
  }}

  overlay.classList.add('show');
  overlay.scrollTop = 0;
  document.body.style.overflow = 'hidden';
}}

function closePerson() {{
  const overlay = document.getElementById('person-overlay');
  if(overlay) {{
    overlay.classList.remove('show');
    document.body.style.overflow = '';
  }}
}}

// ESC key to close overlay
document.addEventListener('keydown', function(e) {{
  if(e.key === 'Escape') closePerson();
}});

// Re-run leaderboard to apply new rendering
filterLB();
'''

# ─── 2e: Inject into HTML ───

# Add the person overlay div before </body>
overlay_html = '''
<div class="person-overlay" id="person-overlay">
  <div class="person-overlay-inner" id="person-overlay-content"></div>
</div>
'''
html = html.replace('</body>', overlay_html + '</body>')

# Inject CSS before </style>
html = html.replace('</style>', pd_css + '</style>')

# Inject PD enhancement JS BEFORE the init calls at the end of script
# The init code is: "filterLB();renderReport();..." at the very end before </script>
# Find the LAST standalone filterLB() call (the init call, not inside a function)
import re
# Find the init block: the last "filterLB();" that's followed by other render calls
init_match = re.search(r'\nfilterLB\(\);render', html)
if init_match:
    inject_pos = init_match.start()
    html = html[:inject_pos] + '\n' + pd_js + html[inject_pos:]
    print("Injected pd_js before init calls")
else:
    # Fallback: inject before closing script
    html = html.replace('</script>\n</body>', pd_js + '\n</script>\n</body>')
    if pd_js not in html:
        html = html.replace('</script></body>', pd_js + '\n</script></body>')
    print("Injected pd_js at end of script (fallback)")

# ── Step 3: Live viewer is now embedded as tab 3 (即場直播) ──
# No external link needed

# ── Step 4: Extract large data to external JS files ──

def extract_data_to_file(html, const_name, filename):
    """Extract const XX={...}; from HTML to external JS file"""
    pat = f'const {const_name}='
    idx = html.find(pat)
    if idx == -1:
        print(f"  WARNING: {const_name} not found")
        return html
    start = idx + len(pat)
    ch = html[start]
    close = ']' if ch == '[' else '}'
    depth = 1
    end = start + 1
    while depth > 0 and end < len(html):
        if html[end] == ch: depth += 1
        elif html[end] == close: depth -= 1
        end += 1
    data_val = html[start:end]
    semi = end
    while semi < len(html) and html[semi] in ' \n\t': semi += 1
    if semi < len(html) and html[semi] == ';': semi += 1
    if semi < len(html) and html[semi] == '\n': semi += 1
    ext_path = f'{BASE}/{filename}'
    with open(ext_path, 'w') as f:
        f.write(f'const {const_name}={data_val};\n')
    sz = os.path.getsize(ext_path)
    print(f"  {filename}: {sz:,} bytes ({sz/1024:.0f} KB)")
    html = html[:idx] + html[semi:]
    return html

print("Extracting data to external JS files...")
html = extract_data_to_file(html, 'PD', 'pd-data.js')
html = extract_data_to_file(html, 'CB', 'cb-data.js')
html = extract_data_to_file(html, 'MB', 'mb-data.js')
html = extract_data_to_file(html, 'IPM', 'ipm-data.js')
html = extract_data_to_file(html, 'IP', 'ip-data.js')

# Add external script tags before main script
html = html.replace(
    '<script>\nconst C=',
    '<script src="cb-data.js"></script>\n<script src="mb-data.js"></script>\n<script src="ip-data.js"></script>\n<script src="ipm-data.js"></script>\n<script src="pd-data.js"></script>\n<script>\nconst C='
)

# Write index.html
index_path = f'{BASE}/index.html'
with open(index_path, 'w') as f:
    f.write(html)

file_size = os.path.getsize(index_path)
print(f"\nindex.html (shell): {file_size:,} bytes ({file_size/1024:.0f} KB)")

total = file_size
for fn in ['cb-data.js','mb-data.js','ip-data.js','ipm-data.js','pd-data.js']:
    fp = f'{BASE}/{fn}'
    if os.path.exists(fp): total += os.path.getsize(fp)
print(f"Total (all files): {total:,} bytes ({total/1024:.0f} KB)")
print("dashboard.html preserved as backup")

# ── Step 5: Create full-dashboard.html (single-file, no HTTP server needed) ──
# Re-read and combine everything into one file
full_html = open(f'{BASE}/dashboard.html').read()

# Apply same CSS injection
full_html = full_html.replace('</style>', pd_css + '</style>')

# Apply same JS injection (before init calls)
init_match2 = re.search(r'\nfilterLB\(\);render', full_html)
if init_match2:
    inject_pos2 = init_match2.start()
    full_html = full_html[:inject_pos2] + '\n' + pd_js + full_html[inject_pos2:]

# Add overlay HTML
full_html = full_html.replace('</body>', overlay_html + '</body>')

full_path = f'{BASE}/full-dashboard.html'
with open(full_path, 'w') as f:
    f.write(full_html)
full_size = os.path.getsize(full_path)
print(f"full-dashboard.html: {full_size:,} bytes ({full_size/1024:.0f} KB)")
