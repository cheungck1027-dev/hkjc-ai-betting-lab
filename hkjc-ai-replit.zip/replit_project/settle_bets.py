#!/usr/bin/env python3
"""
Settlement system for HKJC AI Betting League.
Reads match results, settles active bets, updates memories & leaderboard.
Can be called with scraped results or with simulated results for testing.
"""
import json
import os
import re
from datetime import datetime

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def load_data():
    with open(f'{BASE}/state.json') as f: state = json.load(f)
    with open(f'{BASE}/characters.json') as f: chars = json.load(f)
    return state, chars

def save_state(state):
    with open(f'{BASE}/state.json', 'w') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

def load_results():
    """Load scraped results from results.json"""
    path = f'{BASE}/results.json'
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        data = json.load(f)
    # Expected format: { "FB5731": {"homeScore": 2, "awayScore": 1, "halfHomeScore": 1, "halfAwayScore": 0}, ... }
    return data

def check_bet_won(bet, result):
    """
    Check if a bet won based on match result.
    Returns True/False/None (None = match not finished yet)
    """
    if not result:
        return None

    hs = result['homeScore']
    as_ = result['awayScore']
    hhs = result.get('halfHomeScore', None)
    has_ = result.get('halfAwayScore', None)
    total_goals = hs + as_

    bt = bet['betType']
    choice = bet['choice']

    if bt == '主客和':
        if choice == 'H':
            return hs > as_
        elif choice == 'D':
            return hs == as_
        elif choice == 'A':
            return hs < as_

    elif bt == '讓球':
        # Handicap: choice format "H" or "A", choiceLabel contains the line
        label = bet.get('choiceLabel', '')
        # Extract handicap line from label like "讓球主(-1.5)" or "讓球客(+1.5)"
        line_match = re.search(r'([+-]?\d+\.?\d*)', label)
        if line_match:
            line = float(line_match.group(1))
            if 'H' in choice or '主' in label.split('(')[0]:
                adjusted = hs + line - as_
            else:
                adjusted = as_ + line - hs
            if adjusted > 0:
                return True
            elif adjusted < 0:
                return False
            else:
                return None  # Push - refund (treat as no result)
        return None

    elif bt == '入球大細':
        label = bet.get('choiceLabel', '')
        # "大2.5球" or "細2.5球"
        line_match = re.search(r'(\d+\.?\d*)', label)
        if line_match:
            line = float(line_match.group(1))
            if '大' in label:
                return total_goals > line
            else:
                return total_goals < line
        return None

    elif bt == '波膽':
        # Correct score: choiceLabel like "2:1" or "1:0"
        label = bet.get('choiceLabel', '')
        score_match = re.search(r'(\d+):(\d+)', label)
        if score_match:
            pred_h = int(score_match.group(1))
            pred_a = int(score_match.group(2))
            return pred_h == hs and pred_a == as_
        return None

    elif bt == '半全場':
        # Half/Full time: choiceLabel like "主/主", "和/客" etc
        label = bet.get('choiceLabel', '')
        if hhs is None or has_ is None:
            return None
        # Determine half-time result
        if hhs > has_:
            ht = '主'
        elif hhs == has_:
            ht = '和'
        else:
            ht = '客'
        # Determine full-time result
        if hs > as_:
            ft = '主'
        elif hs == as_:
            ft = '和'
        else:
            ft = '客'
        actual = f"{ht}/{ft}"
        return label == actual

    return None

def settle(results=None):
    """
    Main settlement function.
    results: dict of matchId -> {homeScore, awayScore, halfHomeScore, halfAwayScore}
    If None, loads from results.json
    """
    if results is None:
        results = load_results()

    if not results:
        print("No results available to settle.")
        return 0

    state, chars = load_data()
    active_bets = state.get('activeBets', [])
    memories = state.get('memories', {})
    history = state.get('history', [])

    settled_count = 0
    settled_results = []
    remaining_bets = []

    for bet in active_bets:
        mid = bet['matchId']
        if mid not in results:
            remaining_bets.append(bet)
            continue

        result = results[mid]
        won = check_bet_won(bet, result)

        if won is None:
            # Push or can't determine - refund
            cid = str(bet['charId'])
            if cid in memories:
                memories[cid]['wallet'] += bet['amount']
            remaining_bets.append(bet)  # Keep as active? Or refund and remove
            # Actually remove and refund
            remaining_bets.pop()  # Remove the one we just added
            settled_count += 1
            settled_results.append({
                'charId': bet['charId'],
                'charName': bet['charName'],
                'matchId': mid,
                'betType': bet['betType'],
                'choice': bet['choiceLabel'],
                'odds': bet['odds'],
                'amount': bet['amount'],
                'won': None,
                'pnl': 0,
                'result': f"{result['homeScore']}:{result['awayScore']}",
            })
            continue

        cid = str(bet['charId'])
        mem = memories.get(cid, {})

        if won:
            pnl = round(bet['amount'] * (bet['odds'] - 1), 2)
            mem['wallet'] = mem.get('wallet', 0) + bet['amount'] + pnl
            mem['totalBetsWon'] = mem.get('totalBetsWon', 0) + 1
            mem['winStreak'] = mem.get('winStreak', 0) + 1
            mem['loseStreak'] = 0
        else:
            pnl = -bet['amount']
            # Wallet already deducted when bet was placed
            mem['totalBetsWon'] = mem.get('totalBetsWon', 0)  # no change
            mem['loseStreak'] = mem.get('loseStreak', 0) + 1
            mem['winStreak'] = 0

        mem['totalBetsPlaced'] = mem.get('totalBetsPlaced', 0) + 1
        mem['totalPnL'] = round(mem.get('totalPnL', 0) + pnl, 2)
        mem['totalWins'] = mem.get('totalWins', 0) + (1 if won else 0)
        mem['totalLosses'] = mem.get('totalLosses', 0) + (0 if won else 1)

        # Track individual results for win rate calculations
        if 'betResults' not in mem:
            mem['betResults'] = []
        mem['betResults'].append({
            'matchId': mid,
            'home': bet.get('home', ''),
            'away': bet.get('away', ''),
            'won': won,
            'pnl': pnl,
            'betType': bet['betType'],
            'choiceLabel': bet.get('choiceLabel', ''),
            'odds': bet['odds'],
            'amount': bet.get('amount', 0),
            'result': f"{result['homeScore']}:{result['awayScore']}",
            'timestamp': datetime.now().isoformat(),
        })

        memories[cid] = mem
        settled_count += 1

        settled_results.append({
            'charId': bet['charId'],
            'charName': bet['charName'],
            'matchId': mid,
            'betType': bet['betType'],
            'choice': bet['choiceLabel'],
            'odds': bet['odds'],
            'amount': bet['amount'],
            'won': won,
            'pnl': pnl,
            'result': f"{result['homeScore']}:{result['awayScore']}",
        })

    # Update state
    state['activeBets'] = remaining_bets
    state['memories'] = memories

    # Add to history
    history.append({
        'settleTime': datetime.now().isoformat(),
        'settledCount': settled_count,
        'matchesSettled': list(results.keys()),
        'settledResults': settled_results,
    })
    state['history'] = history
    state['lastSettleTime'] = datetime.now().isoformat()

    save_state(state)

    # Print summary
    wins = sum(1 for r in settled_results if r['won'] is True)
    losses = sum(1 for r in settled_results if r['won'] is False)
    pushes = sum(1 for r in settled_results if r['won'] is None)
    total_pnl = sum(r['pnl'] for r in settled_results)

    print(f"=== Settlement Complete ===")
    print(f"Matches settled: {len(results)}")
    print(f"Bets settled: {settled_count}")
    print(f"Wins: {wins} | Losses: {losses} | Pushes: {pushes}")
    print(f"Total PnL: ${total_pnl:+,.2f}")
    print(f"Remaining active bets: {len(remaining_bets)}")

    return settled_count


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == '--test':
        # Test with sample results for first few matches
        print("Running test settlement with sample results...")
        test_results = {}
        with open(f'{BASE}/matches.json') as f:
            matches = json.load(f)
        # Simulate results for matches dated 17/03
        import random
        random.seed(42)
        for m in matches:
            if m['dateTime'].startswith('17/03') or m['dateTime'].startswith('18/03/2026 01') or m['dateTime'].startswith('18/03/2026 03'):
                hs = random.choices([0,1,2,3,4], weights=[15,35,30,15,5])[0]
                as_ = random.choices([0,1,2,3,4], weights=[15,35,30,15,5])[0]
                # Bias based on HAD odds
                if m['hadH'] < m['hadA']:
                    hs = max(hs, random.randint(0,2))
                elif m['hadA'] < m['hadH']:
                    as_ = max(as_, random.randint(0,2))
                hhs = random.randint(0, min(hs, 2))
                has__ = random.randint(0, min(as_, 2))
                test_results[m['id']] = {
                    'homeScore': hs, 'awayScore': as_,
                    'halfHomeScore': hhs, 'halfAwayScore': has__
                }
        print(f"Simulated results for {len(test_results)} matches")
        settle(test_results)
    else:
        settle()
