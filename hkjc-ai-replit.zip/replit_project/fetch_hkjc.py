#!/usr/bin/env python3
"""
Fetch REAL match data & odds from HKJC public JSON API.
Also fetch real match results for settlement.

HKJC Public Endpoints:
- Match list + HAD odds: https://bet.hkjc.com/football/getJSON.aspx?jsontype=search_result.aspx
- All odds: https://bet.hkjc.com/football/getJSON.aspx?jsontype=odds_allodds.aspx
- Match results: https://bet.hkjc.com/football/getJSON.aspx?jsontype=results.aspx
- In-play: https://bet.hkjc.com/football/getJSON.aspx?jsontype=odds_inplay.aspx
"""

import json, os, time, re
from datetime import datetime
import requests

BASE = os.path.join(os.path.dirname(__file__), 'data')
os.makedirs(BASE, exist_ok=True)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Referer': 'https://bet.hkjc.com/football/default.aspx',
    'Accept': 'application/json, text/javascript, */*',
}

def fetch_json(url, retries=3):
    """Fetch JSON from HKJC with retry"""
    for i in range(retries):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=15)
            resp.raise_for_status()
            text = resp.text.strip()
            # HKJC sometimes wraps in callback
            if text.startswith('(') and text.endswith(')'):
                text = text[1:-1]
            if text.startswith('[') or text.startswith('{'):
                return json.loads(text)
            # Try to extract JSON from JSONP
            m = re.search(r'\((\[.*\])\)', text, re.DOTALL)
            if m:
                return json.loads(m.group(1))
            m = re.search(r'\((\{.*\})\)', text, re.DOTALL)
            if m:
                return json.loads(m.group(1))
            print(f"  Warning: non-JSON response (len={len(text)}), retrying...")
        except Exception as e:
            print(f"  Attempt {i+1} failed: {e}")
            time.sleep(2)
    return None

def fetch_matches():
    """Fetch all upcoming matches with HAD odds"""
    print("📡 Fetching matches from HKJC...")

    # Try multiple endpoints
    urls = [
        'https://bet.hkjc.com/football/getJSON.aspx?jsontype=search_result.aspx',
        'https://info.cld.hkjc.com/graphql/base/getOdds?type=had',
    ]

    data = None
    for url in urls:
        data = fetch_json(url)
        if data:
            print(f"  ✅ Got data from {url.split('?')[0].split('/')[-1]}")
            break

    if not data:
        print("  ❌ Failed to fetch from API, trying web scrape...")
        return fetch_matches_fallback()

    matches = []
    if isinstance(data, list):
        for m in data:
            match = parse_hkjc_match(m)
            if match:
                matches.append(match)
    elif isinstance(data, dict):
        for key in ['matches', 'matchList', 'events', 'data']:
            if key in data:
                items = data[key] if isinstance(data[key], list) else [data[key]]
                for m in items:
                    match = parse_hkjc_match(m)
                    if match:
                        matches.append(match)
                break

    if matches:
        print(f"  ✅ Parsed {len(matches)} matches")
        save_json('matches.json', matches)
    else:
        print("  ⚠️ No matches parsed, keeping existing data")

    return matches

def parse_hkjc_match(m):
    """Parse a single match from HKJC JSON format"""
    try:
        # HKJC format varies, try multiple field names
        match_id = m.get('matchNum') or m.get('matchId') or m.get('id') or m.get('eventId', '')
        if not match_id:
            return None

        home = m.get('homeTeam', {})
        away = m.get('awayTeam', {})
        home_name = home.get('teamNameCH') or home.get('name_ch') or m.get('homeTeamNameCH') or m.get('home', '')
        away_name = away.get('teamNameCH') or away.get('name_ch') or m.get('awayTeamNameCH') or m.get('away', '')

        if not home_name:
            home_name = m.get('homeTeam') if isinstance(m.get('homeTeam'), str) else '未知'
        if not away_name:
            away_name = m.get('awayTeam') if isinstance(m.get('awayTeam'), str) else '未知'

        # Date/time
        dt_str = m.get('matchDate') or m.get('kickOffTime') or m.get('matchTime') or ''

        # HAD odds
        had = m.get('hadodds') or m.get('had') or m.get('HAD') or {}
        if isinstance(had, dict):
            hadH = float(had.get('H', had.get('h', had.get('home', 0))) or 0)
            hadD = float(had.get('D', had.get('d', had.get('draw', 0))) or 0)
            hadA = float(had.get('A', had.get('a', had.get('away', 0))) or 0)
        elif isinstance(had, list) and len(had) >= 3:
            hadH, hadD, hadA = float(had[0]), float(had[1]), float(had[2])
        else:
            # Try direct fields
            hadH = float(m.get('hadH') or m.get('H') or m.get('homeWinOdds') or 0)
            hadD = float(m.get('hadD') or m.get('D') or m.get('drawOdds') or 0)
            hadA = float(m.get('hadA') or m.get('A') or m.get('awayWinOdds') or 0)

        if hadH <= 0 or hadD <= 0 or hadA <= 0:
            return None

        return {
            'id': f'FB{match_id}' if not str(match_id).startswith('FB') else str(match_id),
            'dateTime': dt_str,
            'home': home_name,
            'away': away_name,
            'hadH': round(hadH, 2),
            'hadD': round(hadD, 2),
            'hadA': round(hadA, 2),
            'league': m.get('league', {}).get('leagueNameCH', '') if isinstance(m.get('league'), dict) else m.get('leagueName', ''),
        }
    except Exception as e:
        print(f"  Parse error: {e}")
        return None

def fetch_matches_fallback():
    """Fallback: scrape from the HKJC football page via requests"""
    print("  Trying HTML scrape fallback...")
    try:
        resp = requests.get(
            'https://bet.hkjc.com/football/default.aspx?lang=ch',
            headers=HEADERS, timeout=15
        )
        # Extract embedded JSON from the page
        text = resp.text
        # Look for match data in script tags
        matches = []
        patterns = [
            r'var\s+matchData\s*=\s*(\[.*?\]);',
            r'var\s+g_data\s*=\s*(\{.*?\});',
            r'"matches"\s*:\s*(\[.*?\])',
        ]
        for pat in patterns:
            m = re.search(pat, text, re.DOTALL)
            if m:
                try:
                    data = json.loads(m.group(1))
                    if isinstance(data, list):
                        for item in data:
                            match = parse_hkjc_match(item)
                            if match:
                                matches.append(match)
                except:
                    pass
        if matches:
            print(f"  ✅ Scraped {len(matches)} matches from HTML")
            save_json('matches.json', matches)
        return matches
    except Exception as e:
        print(f"  ❌ Fallback scrape failed: {e}")
        return []

def fetch_results():
    """Fetch match results for settlement"""
    print("📡 Fetching results from HKJC...")

    data = fetch_json('https://bet.hkjc.com/football/getJSON.aspx?jsontype=results.aspx')

    if not data:
        print("  ❌ Failed to fetch results")
        return {}

    results = {}
    items = data if isinstance(data, list) else data.get('matches', data.get('results', []))

    for m in items:
        try:
            mid = m.get('matchNum') or m.get('matchId') or m.get('id', '')
            mid = f'FB{mid}' if not str(mid).startswith('FB') else str(mid)

            # Parse scores
            fs = m.get('fullScore') or m.get('score') or m.get('result', '')
            hs_score = m.get('halfScore') or m.get('halfTimeScore', '')

            if isinstance(fs, str) and ':' in fs:
                parts = fs.split(':')
                home_score = int(parts[0].strip())
                away_score = int(parts[1].strip())
            else:
                home_score = int(m.get('homeScore', m.get('h_score', -1)))
                away_score = int(m.get('awayScore', m.get('a_score', -1)))

            if home_score < 0 or away_score < 0:
                continue

            # Half-time scores
            if isinstance(hs_score, str) and ':' in hs_score:
                hp = hs_score.split(':')
                half_h = int(hp[0].strip())
                half_a = int(hp[1].strip())
            else:
                half_h = int(m.get('halfHomeScore', m.get('ht_h_score', 0)))
                half_a = int(m.get('halfAwayScore', m.get('ht_a_score', 0)))

            results[mid] = {
                'homeScore': home_score,
                'awayScore': away_score,
                'halfHomeScore': half_h,
                'halfAwayScore': half_a,
            }
        except:
            continue

    if results:
        print(f"  ✅ Got results for {len(results)} matches")
        save_json('results.json', results)

    return results

def fetch_inplay():
    """Fetch in-play match data"""
    print("📡 Fetching in-play data...")

    data = fetch_json('https://bet.hkjc.com/football/getJSON.aspx?jsontype=odds_inplay.aspx')

    if not data:
        return []

    inplay = []
    items = data if isinstance(data, list) else data.get('matches', [])

    for m in items:
        try:
            mid = m.get('matchNum') or m.get('matchId') or ''
            mid = f'FB{mid}' if not str(mid).startswith('FB') else str(mid)

            inplay.append({
                'id': mid,
                'home': m.get('homeTeamNameCH', m.get('home', '')),
                'away': m.get('awayTeamNameCH', m.get('away', '')),
                'score': m.get('liveScore', m.get('score', '')),
                'minute': m.get('minute', m.get('runningTime', 0)),
                'status': m.get('status', 'live'),
            })
        except:
            continue

    if inplay:
        print(f"  ✅ {len(inplay)} in-play matches")
        save_json('inplay-live.json', inplay)

    return inplay

def save_json(filename, data):
    path = os.path.join(BASE, filename)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_json(filename, default=None):
    path = os.path.join(BASE, filename)
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    return default if default is not None else []

def is_match_live():
    """Check if any match is currently in-play based on match times"""
    matches = load_json('matches.json', [])
    now = datetime.now()
    for m in matches:
        dt_str = m.get('dateTime', '')
        try:
            # Parse HKJC date format: DD/MM/YYYY HH:MM
            mt = datetime.strptime(dt_str, '%d/%m/%Y %H:%M')
            # Match is "live" if within 0-120 min of kickoff
            diff = (now - mt).total_seconds() / 60
            if 0 <= diff <= 120:
                return True
        except:
            pass
    return False

if __name__ == '__main__':
    print(f"=== HKJC Data Fetch === {datetime.now().isoformat()}")
    fetch_matches()
    fetch_results()
    fetch_inplay()
    print("Done!")
