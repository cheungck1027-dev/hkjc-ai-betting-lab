#!/usr/bin/env python3
"""
In-Play Betting Engine - 即時比賽投注系統
==========================================
Simulates characters reacting to live score changes during matches.
Characters can: chase (追注), cash out (止蝕), double down (加注), or panic.
"""
import json, random, hashlib, math
from datetime import datetime

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def load_all():
    with open(f'{BASE}/characters.json') as f: chars = json.load(f)
    with open(f'{BASE}/state.json') as f: state = json.load(f)
    with open(f'{BASE}/social-bonds.json') as f: bonds = json.load(f)
    return chars, state, bonds

def inplay_rng(cid, mid, minute, salt="inplay"):
    h = hashlib.md5(f"{cid}-{mid}-{minute}-{salt}".encode()).hexdigest()
    return int(h[:8], 16) / 0xFFFFFFFF

# MBTI reaction profiles for in-play
MBTI_REACTIONS = {
    'INTJ': {'chase': 0.15, 'panic': 0.05, 'double': 0.25, 'cashout': 0.35, 'calm': 0.20},
    'INTP': {'chase': 0.10, 'panic': 0.05, 'double': 0.20, 'cashout': 0.25, 'calm': 0.40},
    'ENTJ': {'chase': 0.30, 'panic': 0.05, 'double': 0.35, 'cashout': 0.15, 'calm': 0.15},
    'ENTP': {'chase': 0.35, 'panic': 0.10, 'double': 0.25, 'cashout': 0.10, 'calm': 0.20},
    'INFJ': {'chase': 0.10, 'panic': 0.15, 'double': 0.10, 'cashout': 0.40, 'calm': 0.25},
    'INFP': {'chase': 0.15, 'panic': 0.25, 'double': 0.05, 'cashout': 0.30, 'calm': 0.25},
    'ENFJ': {'chase': 0.25, 'panic': 0.10, 'double': 0.20, 'cashout': 0.20, 'calm': 0.25},
    'ENFP': {'chase': 0.40, 'panic': 0.15, 'double': 0.15, 'cashout': 0.10, 'calm': 0.20},
    'ISTJ': {'chase': 0.05, 'panic': 0.05, 'double': 0.10, 'cashout': 0.45, 'calm': 0.35},
    'ISFJ': {'chase': 0.05, 'panic': 0.20, 'double': 0.05, 'cashout': 0.45, 'calm': 0.25},
    'ESTJ': {'chase': 0.20, 'panic': 0.05, 'double': 0.30, 'cashout': 0.25, 'calm': 0.20},
    'ESFJ': {'chase': 0.20, 'panic': 0.20, 'double': 0.10, 'cashout': 0.30, 'calm': 0.20},
    'ISTP': {'chase': 0.15, 'panic': 0.05, 'double': 0.30, 'cashout': 0.20, 'calm': 0.30},
    'ISFP': {'chase': 0.15, 'panic': 0.25, 'double': 0.05, 'cashout': 0.30, 'calm': 0.25},
    'ESTP': {'chase': 0.40, 'panic': 0.05, 'double': 0.35, 'cashout': 0.05, 'calm': 0.15},
    'ESFP': {'chase': 0.45, 'panic': 0.10, 'double': 0.20, 'cashout': 0.05, 'calm': 0.20},
}

REACTION_LABELS = {
    'chase': '追注', 'panic': '恐慌離場', 'double': '加注',
    'cashout': '止蝕/止賺', 'calm': '冷靜觀望'
}

def simulate_match_timeline(match, result):
    """Generate a realistic minute-by-minute goal timeline from final score"""
    hs, as_ = result['homeScore'], result['awayScore']
    hhs, has_ = result.get('halfHomeScore', 0), result.get('halfAwayScore', 0)

    goals = []
    # Half-time goals
    for _ in range(hhs):
        goals.append(('H', random.randint(5, 45)))
    for _ in range(has_):
        goals.append(('A', random.randint(5, 45)))
    # Second half goals
    for _ in range(hs - hhs):
        goals.append(('H', random.randint(46, 90)))
    for _ in range(as_ - has_):
        goals.append(('A', random.randint(46, 90)))

    goals.sort(key=lambda x: x[1])

    # Build timeline events
    timeline = []
    cur_h, cur_a = 0, 0
    for team, minute in goals:
        if team == 'H':
            cur_h += 1
        else:
            cur_a += 1
        timeline.append({
            'minute': minute,
            'team': team,
            'score': f"{cur_h}:{cur_a}",
            'home': match['home'],
            'away': match['away'],
        })
    return timeline

def evaluate_inplay_reaction(char, bet, timeline, state):
    """Determine how a character reacts to live score changes"""
    mem = state['memories'].get(str(char['id']), {})
    mbti = char['mbti']
    probs = MBTI_REACTIONS.get(mbti, MBTI_REACTIONS['INTJ']).copy()

    reactions = []

    for event in timeline:
        minute = event['minute']
        score_parts = event['score'].split(':')
        cur_h, cur_a = int(score_parts[0]), int(score_parts[1])

        # Is our bet winning or losing right now?
        bet_status = 'neutral'
        if bet['betType'] == '主客和':
            if bet['choice'] == 'H':
                bet_status = 'winning' if cur_h > cur_a else ('losing' if cur_h < cur_a else 'neutral')
            elif bet['choice'] == 'A':
                bet_status = 'winning' if cur_a > cur_h else ('losing' if cur_a < cur_h else 'neutral')
            else:
                bet_status = 'winning' if cur_h == cur_a else 'losing'
        elif bet['betType'] == '波膽':
            import re
            m = re.search(r'(\d+):(\d+)', bet.get('choiceLabel', ''))
            if m:
                bet_status = 'winning' if cur_h == int(m.group(1)) and cur_a == int(m.group(2)) else 'losing'
        else:
            bet_status = 'winning' if cur_h > cur_a and 'H' in bet.get('choice', '') else 'losing'

        # Adjust probabilities based on situation
        adjusted = probs.copy()
        risk = char.get('risk', 0.5)
        lose_streak = mem.get('loseStreak', 0)

        if bet_status == 'losing':
            adjusted['panic'] *= (1.5 + lose_streak * 0.2)
            adjusted['chase'] *= (1.3 if risk > 0.6 else 0.7)
            adjusted['cashout'] *= 1.4
            adjusted['calm'] *= 0.6
        elif bet_status == 'winning':
            adjusted['double'] *= (1.5 if risk > 0.5 else 0.8)
            adjusted['cashout'] *= (1.3 if risk < 0.4 else 0.6)
            adjusted['calm'] *= 1.3
            adjusted['panic'] *= 0.2

        if minute > 75:
            adjusted['cashout'] *= 1.5
            adjusted['calm'] *= 1.5

        # Normalize
        total = sum(adjusted.values())
        for k in adjusted:
            adjusted[k] /= total

        # Pick reaction
        rng = inplay_rng(char['id'], bet['matchId'], minute)
        cumul = 0
        reaction = 'calm'
        for k, v in adjusted.items():
            cumul += v
            if rng < cumul:
                reaction = k
                break

        # Generate thinking
        thinking = []
        scorer = event['home'] if event['team'] == 'H' else event['away']
        thinking.append(f"⚡ {minute}' {scorer}入球！比分 {event['score']}")

        if bet_status == 'winning':
            thinking.append(f"😊 我買嘅{bet['choiceLabel']}暫時贏緊")
        elif bet_status == 'losing':
            thinking.append(f"😰 {bet['choiceLabel']}開始危險...")

        # Reaction-specific thoughts
        if reaction == 'chase':
            chase_amt = int(bet['amount'] * random.uniform(0.3, 0.7))
            thinking.append(f"🔥 追注！再加${chase_amt:,}博翻本")
            reactions.append({
                'minute': minute, 'reaction': reaction, 'label': REACTION_LABELS[reaction],
                'status': bet_status, 'score': event['score'],
                'amount': chase_amt, 'thinking': thinking
            })
        elif reaction == 'panic':
            thinking.append(f"😱 頂唔順！即刻離場止蝕")
            reactions.append({
                'minute': minute, 'reaction': reaction, 'label': REACTION_LABELS[reaction],
                'status': bet_status, 'score': event['score'],
                'amount': 0, 'thinking': thinking
            })
            break  # Character exits after panic
        elif reaction == 'double':
            double_amt = int(bet['amount'] * random.uniform(0.5, 1.0))
            thinking.append(f"💪 形勢大好，加注${double_amt:,}！")
            reactions.append({
                'minute': minute, 'reaction': reaction, 'label': REACTION_LABELS[reaction],
                'status': bet_status, 'score': event['score'],
                'amount': double_amt, 'thinking': thinking
            })
        elif reaction == 'cashout':
            pct = random.randint(50, 80)
            thinking.append(f"🏦 Cash out {pct}%，唔好貪")
            reactions.append({
                'minute': minute, 'reaction': reaction, 'label': REACTION_LABELS[reaction],
                'status': bet_status, 'score': event['score'],
                'cashoutPct': pct, 'thinking': thinking
            })
            break  # Character exits after cashout
        else:
            thinking.append(f"🧘 保持冷靜，繼續觀察")
            reactions.append({
                'minute': minute, 'reaction': reaction, 'label': REACTION_LABELS[reaction],
                'status': bet_status, 'score': event['score'],
                'thinking': thinking
            })

    return reactions

def run_inplay(results):
    """Run in-play simulation for all active bets with results"""
    chars, state, bonds = load_all()
    char_map = {c['id']: c for c in chars}

    inplay_log = []

    for bet in state.get('activeBets', []):
        mid = bet['matchId']
        if mid not in results:
            continue

        char = char_map.get(bet['charId'])
        if not char:
            continue

        result = results[mid]
        if result['homeScore'] + result['awayScore'] == 0:
            continue  # No goals, no in-play action

        # Find matching match data
        match = {'home': bet['home'], 'away': bet['away'], 'id': mid}
        timeline = simulate_match_timeline(match, result)

        if not timeline:
            continue

        reactions = evaluate_inplay_reaction(char, bet, timeline, state)

        if reactions:
            inplay_log.append({
                'charId': char['id'],
                'charName': char['name'],
                'emoji': char['emoji'],
                'mbti': char['mbti'],
                'matchId': mid,
                'home': bet['home'],
                'away': bet['away'],
                'originalBet': {
                    'betType': bet['betType'],
                    'choice': bet['choiceLabel'],
                    'amount': bet['amount'],
                    'odds': bet['odds'],
                },
                'reactions': reactions,
                'finalScore': f"{result['homeScore']}:{result['awayScore']}",
            })

    # Save in-play log
    with open(f'{BASE}/inplay-log.json', 'w') as f:
        json.dump(inplay_log, f, ensure_ascii=False, indent=2)

    print(f"=== In-Play 即時投注模擬 ===")
    print(f"涉及 {len(inplay_log)} 筆即時反應")

    # Stats
    from collections import Counter
    reaction_counts = Counter()
    for entry in inplay_log:
        for r in entry['reactions']:
            reaction_counts[r['reaction']] += 1
    for k, v in reaction_counts.most_common():
        print(f"  {REACTION_LABELS.get(k,k)}: {v}次")

    return inplay_log


if __name__ == '__main__':
    import sys
    # Load or simulate results
    try:
        with open(f'{BASE}/results.json') as f:
            results = json.load(f)
    except:
        # Simulate for testing
        with open(f'{BASE}/matches.json') as f:
            matches = json.load(f)
        results = {}
        random.seed(42)
        for m in matches[:35]:
            hs = random.choices([0,1,2,3,4], weights=[15,35,30,15,5])[0]
            as_ = random.choices([0,1,2,3,4], weights=[15,35,30,15,5])[0]
            results[m['id']] = {
                'homeScore': hs, 'awayScore': as_,
                'halfHomeScore': random.randint(0, min(hs,2)),
                'halfAwayScore': random.randint(0, min(as_,2))
            }

    run_inplay(results)
