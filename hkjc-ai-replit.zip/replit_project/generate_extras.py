#!/usr/bin/env python3
"""
Generate all extra features:
1. 賽後覆盤戰報 (Post-match review report)
2. 角色互動對話 (Character dialogue / social feed)
3. 賽季制度 + 成就徽章 (Season system + achievements)
4. 策略對比分析數據 (Strategy analysis data)
"""
import json, random, hashlib
from collections import Counter, defaultdict
from datetime import datetime

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def load_all():
    with open(f'{BASE}/characters.json') as f: chars = json.load(f)
    with open(f'{BASE}/state.json') as f: state = json.load(f)
    with open(f'{BASE}/social-bonds.json') as f: bonds = json.load(f)
    with open(f'{BASE}/bets-log.json') as f: bets_log = json.load(f)
    try:
        with open(f'{BASE}/inplay-log.json') as f: inplay = json.load(f)
    except:
        inplay = []
    return chars, state, bonds, bets_log, inplay

# ============================================================
# 1. 賽後覆盤戰報 - Post-Match Review Report
# ============================================================
def generate_round_report(chars, state, bets_log):
    """Generate a comprehensive round review report"""
    char_map = {c['id']: c for c in chars}
    mems = state['memories']
    history = state.get('history', [])

    report = {
        'generatedAt': datetime.now().isoformat(),
        'roundNum': state.get('roundNum', 0),
    }

    if not history:
        report['headline'] = '首輪投注完成，等待結算'
        report['sections'] = []
        return report

    latest = history[-1]
    settled = latest.get('settledResults', [])

    if not settled:
        report['headline'] = '暫無結算結果'
        report['sections'] = []
        return report

    # Stats
    wins = [r for r in settled if r.get('won') is True]
    losses = [r for r in settled if r.get('won') is False]
    total_pnl = sum(r.get('pnl', 0) for r in settled)

    # Best and worst performers
    char_pnl = defaultdict(lambda: {'pnl': 0, 'wins': 0, 'total': 0, 'bets': []})
    for r in settled:
        cid = r['charId']
        char_pnl[cid]['pnl'] += r.get('pnl', 0)
        char_pnl[cid]['total'] += 1
        if r.get('won'):
            char_pnl[cid]['wins'] += 1
        char_pnl[cid]['bets'].append(r)

    best = sorted(char_pnl.items(), key=lambda x: -x[1]['pnl'])
    worst = sorted(char_pnl.items(), key=lambda x: x[1]['pnl'])

    # Biggest single wins & losses
    biggest_win = max(settled, key=lambda x: x.get('pnl', 0)) if wins else None
    biggest_loss = min(settled, key=lambda x: x.get('pnl', 0)) if losses else None

    # Upsets (high odds wins)
    upsets = sorted([r for r in wins if r.get('odds', 1) > 3], key=lambda x: -x.get('odds', 1))

    # Bet type performance
    bt_stats = defaultdict(lambda: {'wins': 0, 'total': 0, 'pnl': 0})
    for r in settled:
        bt = r.get('betType', '主客和')
        bt_stats[bt]['total'] += 1
        bt_stats[bt]['pnl'] += r.get('pnl', 0)
        if r.get('won'):
            bt_stats[bt]['wins'] += 1

    # Strategy performance
    strat_stats = defaultdict(lambda: {'wins': 0, 'total': 0, 'pnl': 0, 'chars': set()})
    for r in settled:
        c = char_map.get(r['charId'])
        if c:
            sl = c.get('strategyLabel', c.get('strategy', ''))
            strat_stats[sl]['total'] += 1
            strat_stats[sl]['pnl'] += r.get('pnl', 0)
            strat_stats[sl]['chars'].add(r['charId'])
            if r.get('won'):
                strat_stats[sl]['wins'] += 1

    # MBTI performance
    mbti_stats = defaultdict(lambda: {'wins': 0, 'total': 0, 'pnl': 0})
    for r in settled:
        c = char_map.get(r['charId'])
        if c:
            mb = c['mbti']
            mbti_stats[mb]['total'] += 1
            mbti_stats[mb]['pnl'] += r.get('pnl', 0)
            if r.get('won'):
                mbti_stats[mb]['wins'] += 1

    # Build headline
    if total_pnl > 0:
        headline = f"💰 全場大豐收！{len(wins)}勝{len(losses)}負，總賺${total_pnl:+,.0f}"
    elif total_pnl > -5000:
        headline = f"😐 小輸當贏！{len(wins)}勝{len(losses)}負，微蝕${abs(total_pnl):,.0f}"
    else:
        headline = f"💸 血洗全場！{len(wins)}勝{len(losses)}負，痛蝕${abs(total_pnl):,.0f}"

    sections = []

    # MVP
    if best:
        mvp_id, mvp_data = best[0]
        mvp = char_map.get(mvp_id)
        if mvp:
            sections.append({
                'type': 'mvp',
                'title': '🏆 本輪MVP',
                'charId': mvp_id,
                'name': mvp.get('name',''),
                'emoji': mvp.get('emoji',''),
                'mbti': mvp.get('mbti',''),
                'strategy': mvp.get('strategyLabel',''),
                'pnl': round(mvp_data['pnl'], 2),
                'record': f"{mvp_data['wins']}/{mvp_data['total']}",
            })

    # Worst performer
    if worst:
        worst_id, worst_data = worst[0]
        worst_char = char_map.get(worst_id)
        if worst_char:
            sections.append({
                'type': 'worst',
                'title': '💀 最慘烈',
                'charId': worst_id,
                'name': worst_char.get('name',''),
                'emoji': worst_char.get('emoji',''),
                'pnl': round(worst_data['pnl'], 2),
                'record': f"{worst_data['wins']}/{worst_data['total']}",
            })

    # Biggest upset
    if upsets:
        u = upsets[0]
        sections.append({
            'type': 'upset',
            'title': '🎯 最大冷門',
            'charName': u.get('charName', ''),
            'match': f"{u.get('matchId','')}",
            'choice': u.get('choice', ''),
            'odds': u.get('odds', 0),
            'amount': u.get('amount', 0),
            'pnl': round(u.get('pnl', 0), 2),
            'result': u.get('result', ''),
        })

    # Bet type analysis
    bt_analysis = []
    for bt, stats in sorted(bt_stats.items(), key=lambda x: -x[1]['total']):
        wr = round(stats['wins']/stats['total']*100, 1) if stats['total'] > 0 else 0
        bt_analysis.append({
            'betType': bt,
            'wins': stats['wins'],
            'total': stats['total'],
            'winRate': wr,
            'pnl': round(stats['pnl'], 2),
        })
    sections.append({'type': 'betTypes', 'title': '📊 投注類型表現', 'data': bt_analysis})

    # Strategy analysis
    strat_analysis = []
    for sl, stats in sorted(strat_stats.items(), key=lambda x: -x[1]['pnl']):
        wr = round(stats['wins']/stats['total']*100, 1) if stats['total'] > 0 else 0
        strat_analysis.append({
            'strategy': sl,
            'chars': len(stats['chars']),
            'wins': stats['wins'],
            'total': stats['total'],
            'winRate': wr,
            'pnl': round(stats['pnl'], 2),
        })
    sections.append({'type': 'strategies', 'title': '🎯 策略對比', 'data': strat_analysis})

    # MBTI analysis
    mbti_analysis = []
    for mb, stats in sorted(mbti_stats.items(), key=lambda x: -x[1]['pnl']):
        wr = round(stats['wins']/stats['total']*100, 1) if stats['total'] > 0 else 0
        mbti_analysis.append({
            'mbti': mb,
            'wins': stats['wins'],
            'total': stats['total'],
            'winRate': wr,
            'pnl': round(stats['pnl'], 2),
        })
    sections.append({'type': 'mbti', 'title': '🧠 MBTI對比', 'data': mbti_analysis})

    # Top 10 leaderboard change
    top10 = sorted(best[:10], key=lambda x: -x[1]['pnl'])
    sections.append({
        'type': 'top10',
        'title': '🏅 Top 10 賺錢王',
        'data': [{
            'charId': cid,
            'name': char_map.get(cid, {}).get('name', ''),
            'emoji': char_map.get(cid, {}).get('emoji', ''),
            'pnl': round(data['pnl'], 2),
            'record': f"{data['wins']}/{data['total']}"
        } for cid, data in top10]
    })

    report['headline'] = headline
    report['totalSettled'] = len(settled)
    report['wins'] = len(wins)
    report['losses'] = len(losses)
    report['totalPnL'] = round(total_pnl, 2)
    report['sections'] = sections

    return report

# ============================================================
# 2. 角色互動對話 - Character Dialogue System
# ============================================================

DIALOGUE_TEMPLATES = {
    'win_brag': [
        "{name}：「{emoji} 我就知{choice}會贏！贏咗${pnl:,}，請大家飲嘢！」",
        "{name}：「{emoji} 今日手氣真係好，{choice}果然冇令我失望！」",
        "{name}：「{emoji} 分析過數據就知道{choice}穩贏，科學派嘅勝利！」",
    ],
    'lose_complaint': [
        "{name}：「{emoji} 唉...{choice}竟然輸，蝕咗${loss:,}，想喊...」",
        "{name}：「{emoji} 點解{choice}都會輸？黑到痴線...」",
        "{name}：「{emoji} 算啦算啦，當交學費，下次一定贏番！」",
    ],
    'rival_taunt': [
        "{winner}：「{w_emoji} 喂{loser}！你話{choice}穩贏㗎喎？而家點呀？😏」",
        "{winner}：「{w_emoji} @{loser} 你條友成日反轉嚟買，幾時先學精？」",
        "{loser}：「{l_emoji} {winner}你唔好得戚住先，下場一定贏番你！」",
    ],
    'mentor_advice': [
        "{mentor}：「{m_emoji} {student}，你今次{result}，{advice}」",
        "{mentor}：「{m_emoji} @{student} 記住，{advice}。唔好心急。」",
    ],
    'couple_react': [
        "{a}：「{a_emoji} {b}你今日{result_a}？」\n{b}：「{b_emoji} {response}」",
    ],
    'group_chat': [
        "💬 群組「{group}」：\n{msg1}\n{msg2}\n{msg3}",
    ],
    'inplay_react': [
        "{name}：「{emoji} {minute}' 入球！！{reaction}」",
        "{name}：「{emoji} 頂！{minute}'比分變{score}，{reaction}」",
    ],
}

def generate_dialogues(chars, state, bonds, bets_log, inplay):
    """Generate social feed dialogues between characters"""
    char_map = {c['id']: c for c in chars}
    mems = state['memories']
    history = state.get('history', [])
    dialogues = []

    if not history:
        return dialogues

    latest = history[-1]
    settled = latest.get('settledResults', [])

    # Group settled results by character
    char_results = defaultdict(list)
    for r in settled:
        char_results[r['charId']].append(r)

    # 1. Winners brag
    for cid, results in char_results.items():
        c = char_map.get(cid)
        if not c:
            continue
        wins = [r for r in results if r.get('won')]
        losses = [r for r in results if not r.get('won')]
        total_pnl = sum(r.get('pnl', 0) for r in results)

        if wins and total_pnl > 100:
            best = max(wins, key=lambda x: x.get('pnl', 0))
            tmpl = random.choice(DIALOGUE_TEMPLATES['win_brag'])
            dialogues.append({
                'type': 'win_brag',
                'timestamp': datetime.now().isoformat(),
                'charId': cid,
                'text': tmpl.format(
                    name=c['name'], emoji=c['emoji'],
                    choice=best.get('choice', ''), pnl=int(total_pnl)
                ),
                'mood': '得意'
            })

        if losses and total_pnl < -200:
            worst = min(losses, key=lambda x: x.get('pnl', 0))
            tmpl = random.choice(DIALOGUE_TEMPLATES['lose_complaint'])
            dialogues.append({
                'type': 'lose_complaint',
                'timestamp': datetime.now().isoformat(),
                'charId': cid,
                'text': tmpl.format(
                    name=c['name'], emoji=c['emoji'],
                    choice=worst.get('choice', ''), loss=int(abs(total_pnl))
                ),
                'mood': '沮喪'
            })

    # 2. Rival taunts
    for bond in bonds:
        if bond['type'] not in ['死對頭', '競爭對手']:
            continue
        a_id, b_id = bond['charA'], bond['charB']
        a_results = char_results.get(a_id, [])
        b_results = char_results.get(b_id, [])
        a_pnl = sum(r.get('pnl', 0) for r in a_results)
        b_pnl = sum(r.get('pnl', 0) for r in b_results)

        if a_results and b_results and abs(a_pnl - b_pnl) > 200:
            winner_id = a_id if a_pnl > b_pnl else b_id
            loser_id = b_id if a_pnl > b_pnl else a_id
            w = char_map.get(winner_id)
            l = char_map.get(loser_id)
            if w and l:
                loser_results = char_results.get(loser_id, [])
                worst_bet = min(loser_results, key=lambda x: x.get('pnl', 0)) if loser_results else {}
                tmpl = random.choice(DIALOGUE_TEMPLATES['rival_taunt'])
                dialogues.append({
                    'type': 'rival_taunt',
                    'timestamp': datetime.now().isoformat(),
                    'charIds': [winner_id, loser_id],
                    'text': tmpl.format(
                        winner=w['name'], w_emoji=w['emoji'],
                        loser=l['name'], l_emoji=l['emoji'],
                        choice=worst_bet.get('choice', '反向操作')
                    ),
                    'mood': '火藥味'
                })

    # 3. Mentor advice
    for bond in bonds:
        if bond['type'] != '師徒':
            continue
        mentor_id, student_id = bond['charA'], bond['charB']
        mentor = char_map.get(mentor_id)
        student = char_map.get(student_id)
        s_results = char_results.get(student_id, [])
        if not (mentor and student and s_results):
            continue
        s_pnl = sum(r.get('pnl', 0) for r in s_results)
        s_wins = sum(1 for r in s_results if r.get('won'))
        result = f"贏咗{s_wins}場" if s_pnl > 0 else f"輸咗${abs(int(s_pnl)):,}"
        advices = [
            "控制注碼係最重要", "唔好畀情緒影響判斷",
            "買之前一定要做功課", "輸贏乃兵家常事",
            "你個分析方向啱，但注碼太大", "下次試下分散投注",
            "你太保守喇，適當時候要博一博"
        ]
        tmpl = random.choice(DIALOGUE_TEMPLATES['mentor_advice'])
        dialogues.append({
            'type': 'mentor_advice',
            'timestamp': datetime.now().isoformat(),
            'charIds': [mentor_id, student_id],
            'text': tmpl.format(
                mentor=mentor['name'], m_emoji=mentor['emoji'],
                student=student['name'],
                result=result, advice=random.choice(advices)
            ),
            'mood': '教導'
        })

    # 4. Couple reactions
    for bond in bonds:
        if bond['type'] != '情侶':
            continue
        a, b = char_map.get(bond['charA']), char_map.get(bond['charB'])
        if not (a and b):
            continue
        a_pnl = sum(r.get('pnl', 0) for r in char_results.get(bond['charA'], []))
        b_pnl = sum(r.get('pnl', 0) for r in char_results.get(bond['charB'], []))
        result_a = "贏咗" if a_pnl > 0 else "輸咗"
        if a_pnl > 0 and b_pnl > 0:
            response = "我都贏啊！今晚去食好嘢慶祝！🎉"
        elif a_pnl < 0 and b_pnl < 0:
            response = "我都輸...一齊慳啲啦😢"
        elif a_pnl > 0:
            response = f"我輸咗${abs(int(b_pnl)):,}...你贏嘅請我食飯🥺"
        else:
            response = f"我贏咗${int(b_pnl):,}！等我請你食嘢補番 ❤️"

        dialogues.append({
            'type': 'couple',
            'timestamp': datetime.now().isoformat(),
            'charIds': [bond['charA'], bond['charB']],
            'text': f"{a['name']}：「{a['emoji']} 你今日{result_a}？」\n{b['name']}：「{b['emoji']} {response}」",
            'mood': '甜蜜' if (a_pnl + b_pnl) > 0 else '苦澀'
        })

    # 5. In-play reactions
    for entry in inplay[:20]:
        c = char_map.get(entry['charId'])
        if not c or not entry.get('reactions'):
            continue
        for r in entry['reactions'][:1]:  # Just first reaction per entry
            dialogues.append({
                'type': 'inplay',
                'timestamp': datetime.now().isoformat(),
                'charId': entry['charId'],
                'text': f"{c['name']}：「{c['emoji']} {r['minute']}' 比分{r['score']}！{r['label']}！」",
                'mood': r.get('label', ''),
                'matchId': entry['matchId'],
            })

    random.shuffle(dialogues)
    return dialogues[:50]  # Cap at 50 dialogues

# ============================================================
# 3. 賽季制度 + 成就徽章 - Season & Achievement System
# ============================================================

ACHIEVEMENTS = {
    # Win streaks
    'streak_3': {'name': '三連勝', 'icon': '🔥', 'desc': '連贏3場', 'check': lambda m: m.get('winStreak',0) >= 3},
    'streak_5': {'name': '五連勝', 'icon': '🔥🔥', 'desc': '連贏5場', 'check': lambda m: m.get('winStreak',0) >= 5},
    'streak_10': {'name': '十連勝', 'icon': '🔥🔥🔥', 'desc': '連贏10場', 'check': lambda m: m.get('winStreak',0) >= 10},
    # PnL milestones
    'profit_1k': {'name': '小富翁', 'icon': '💰', 'desc': '累計盈利$1,000+', 'check': lambda m: m.get('totalPnL',0) >= 1000},
    'profit_5k': {'name': '中富翁', 'icon': '💎', 'desc': '累計盈利$5,000+', 'check': lambda m: m.get('totalPnL',0) >= 5000},
    'profit_10k': {'name': '大富翁', 'icon': '👑', 'desc': '累計盈利$10,000+', 'check': lambda m: m.get('totalPnL',0) >= 10000},
    # Win rate
    'wr_60': {'name': '精準射手', 'icon': '🎯', 'desc': '勝率60%+（至少5注）', 'check': lambda m: m.get('totalBetsPlaced',0) >= 5 and m.get('totalBetsWon',0)/max(m.get('totalBetsPlaced',0),1) >= 0.6},
    'wr_80': {'name': '神算子', 'icon': '🧙', 'desc': '勝率80%+（至少5注）', 'check': lambda m: m.get('totalBetsPlaced',0) >= 5 and m.get('totalBetsWon',0)/max(m.get('totalBetsPlaced',0),1) >= 0.8},
    # Volume
    'bets_10': {'name': '小賭怡情', 'icon': '🎲', 'desc': '累計下注10次', 'check': lambda m: m.get('totalBetsPlaced',0) >= 10},
    'bets_50': {'name': '賭場常客', 'icon': '🃏', 'desc': '累計下注50次', 'check': lambda m: m.get('totalBetsPlaced',0) >= 50},
    'bets_100': {'name': '賭王', 'icon': '♠️', 'desc': '累計下注100次', 'check': lambda m: m.get('totalBetsPlaced',0) >= 100},
    # Special
    'survivor': {'name': '倖存者', 'icon': '🛡️', 'desc': '連輸5場後翻身', 'check': lambda m: m.get('winStreak',0) > 0 and any(r.get('won') for r in m.get('betResults',[])[-3:]) if m.get('betResults') else False},
    'underdog': {'name': '撐細狗王', 'icon': '🐕', 'desc': '贏過3倍以上賠率', 'check': lambda m: any(r.get('odds',1) > 3 and r.get('won') for r in m.get('betResults',[]))},
    'diversified': {'name': '多元化', 'icon': '🎨', 'desc': '用過3種以上投注類型', 'check': lambda m: len(set(r.get('betType','') for r in m.get('betResults',[]))) >= 3},
    'comeback': {'name': '逆轉王', 'icon': '🔄', 'desc': '從虧損翻正', 'check': lambda m: m.get('totalPnL',0) > 0 and any(r.get('pnl',0) < 0 for r in m.get('betResults',[])[:3]) if m.get('betResults') else False},
    # Negative achievements (funny)
    'unlucky': {'name': '非洲人', 'icon': '🌑', 'desc': '連輸5場', 'check': lambda m: m.get('loseStreak',0) >= 5},
    'broke': {'name': '破產邊緣', 'icon': '💸', 'desc': '資金低於$500', 'check': lambda m: m.get('wallet',10000) < 500},
    'loss_5k': {'name': '大出血', 'icon': '🩸', 'desc': '累計虧損$5,000+', 'check': lambda m: m.get('totalPnL',0) <= -5000},
}

def check_achievements(state, chars):
    """Check all characters for achievements"""
    char_map = {c['id']: c for c in chars}
    achievements_data = {}

    for c in chars:
        cid = str(c['id'])
        mem = state['memories'].get(cid, {})
        earned = []

        for ach_id, ach in ACHIEVEMENTS.items():
            try:
                if ach['check'](mem):
                    earned.append({
                        'id': ach_id,
                        'name': ach['name'],
                        'icon': ach['icon'],
                        'desc': ach['desc'],
                    })
            except:
                pass

        achievements_data[c['id']] = earned

    return achievements_data

def generate_season_data(state, chars):
    """Generate season standings and stats"""
    mems = state['memories']
    char_map = {c['id']: c for c in chars}

    season = {
        'seasonNum': 1,
        'roundNum': state.get('roundNum', 0),
        'startDate': '2026-03-17',
        'standings': [],
    }

    for c in chars:
        cid = str(c['id'])
        mem = mems.get(cid, {})
        tp = mem.get('totalBetsPlaced', 0)
        tw = mem.get('totalBetsWon', 0)
        pnl = mem.get('totalPnL', 0)
        wr = round(tw / tp * 100, 1) if tp > 0 else 0

        # Score = weighted combination
        score = round(pnl * 0.4 + wr * 50 * 0.3 + tw * 100 * 0.3, 1)

        season['standings'].append({
            'charId': c['id'],
            'name': c['name'],
            'emoji': c['emoji'],
            'score': score,
            'pnl': round(pnl, 2),
            'winRate': wr,
            'totalBets': tp,
            'wins': tw,
        })

    season['standings'].sort(key=lambda x: -x['score'])
    return season

# ============================================================
# 4. 策略對比分析 - Strategy Analysis Data
# ============================================================

def generate_strategy_analysis(chars, state):
    """Generate detailed strategy comparison data for charts"""
    mems = state['memories']
    char_map = {c['id']: c for c in chars}

    # Group by strategy
    strat_data = defaultdict(lambda: {
        'chars': [], 'totalBets': 0, 'totalWins': 0,
        'totalPnL': 0, 'wallets': [], 'risks': [],
        'betTypes': Counter(), 'wrHistory': []
    })

    for c in chars:
        cid = str(c['id'])
        mem = mems.get(cid, {})
        sl = c.get('strategyLabel', c.get('strategy', ''))
        sd = strat_data[sl]
        sd['chars'].append(c['id'])
        sd['totalBets'] += mem.get('totalBetsPlaced', 0)
        sd['totalWins'] += mem.get('totalBetsWon', 0)
        sd['totalPnL'] += mem.get('totalPnL', 0)
        sd['wallets'].append(mem.get('wallet', c.get('wallet', 10000)))
        sd['risks'].append(c.get('risk', 0.5))

        for br in mem.get('betResults', []):
            sd['betTypes'][br.get('betType', '')] += 1

    # Group by MBTI
    mbti_data = defaultdict(lambda: {
        'chars': [], 'totalBets': 0, 'totalWins': 0,
        'totalPnL': 0, 'avgRisk': 0
    })

    for c in chars:
        cid = str(c['id'])
        mem = mems.get(cid, {})
        mb = c['mbti']
        md = mbti_data[mb]
        md['chars'].append(c['id'])
        md['totalBets'] += mem.get('totalBetsPlaced', 0)
        md['totalWins'] += mem.get('totalBetsWon', 0)
        md['totalPnL'] += mem.get('totalPnL', 0)

    # Risk vs Return scatter data
    scatter = []
    for c in chars:
        cid = str(c['id'])
        mem = mems.get(cid, {})
        tp = mem.get('totalBetsPlaced', 0)
        if tp > 0:
            scatter.append({
                'id': c['id'],
                'name': c['name'],
                'risk': c.get('risk', 0.5),
                'return': round(mem.get('totalPnL', 0) / tp, 2),
                'mbti': c['mbti'],
                'strategy': c.get('strategyLabel', ''),
                'bets': tp,
            })

    # Bet type analysis
    bet_type_data = defaultdict(lambda: {'total': 0, 'wins': 0, 'pnl': 0, 'amounts': []})
    for c in chars:
        cid = str(c['id'])
        mem = mems.get(cid, {})
        for br in mem.get('betResults', []):
            bt = br.get('betType', '主客和')
            bet_type_data[bt]['total'] += 1
            bet_type_data[bt]['pnl'] += br.get('pnl', 0)
            bet_type_data[bt]['amounts'].append(br.get('amount', 0))
            if br.get('won'):
                bet_type_data[bt]['wins'] += 1

    # Top & bottom performers
    perf_list = []
    for c in chars:
        cid = str(c['id'])
        mem = mems.get(cid, {})
        tp = mem.get('totalBetsPlaced', 0)
        if tp > 0:
            perf_list.append({
                'id': c['id'], 'name': c['name'], 'emoji': c.get('emoji',''),
                'mbti': c['mbti'], 'strategy': c.get('strategyLabel', ''),
                'wallet': mem.get('wallet', 10000),
                'pnl': mem.get('totalPnL', 0),
                'roi': round((mem.get('wallet', 10000) - 10000) / 100, 1),
                'winRate': round(mem.get('totalBetsWon', 0) / tp * 100, 1),
                'bets': tp,
            })
    perf_list.sort(key=lambda x: -x['pnl'])
    top5 = perf_list[:5]
    bottom5 = perf_list[-5:][::-1]

    # Build analysis output
    analysis = {
        'strategies': [],
        'mbtiComparison': [],
        'riskReturn': scatter,
        'betTypes': [],
        'top5': top5,
        'bottom5': bottom5,
    }

    for sl, sd in sorted(strat_data.items(), key=lambda x: -x[1]['totalPnL']):
        wr = round(sd['totalWins'] / sd['totalBets'] * 100, 1) if sd['totalBets'] > 0 else 0
        avg_wallet = round(sum(sd['wallets']) / len(sd['wallets']), 0) if sd['wallets'] else 0
        avg_risk = round(sum(sd['risks']) / len(sd['risks']), 2) if sd['risks'] else 0
        roi = round((avg_wallet - 10000) / 100, 1)
        analysis['strategies'].append({
            'name': sl,
            'charCount': len(sd['chars']),
            'totalBets': sd['totalBets'],
            'totalWins': sd['totalWins'],
            'winRate': wr,
            'totalPnL': round(sd['totalPnL'], 2),
            'avgWallet': avg_wallet,
            'avgRisk': avg_risk,
            'avgROI': roi,
            'topBetTypes': sd['betTypes'].most_common(3),
        })

    for mb, md in sorted(mbti_data.items(), key=lambda x: -x[1]['totalPnL']):
        wr = round(md['totalWins'] / md['totalBets'] * 100, 1) if md['totalBets'] > 0 else 0
        analysis['mbtiComparison'].append({
            'mbti': mb,
            'charCount': len(md['chars']),
            'totalBets': md['totalBets'],
            'winRate': wr,
            'totalPnL': round(md['totalPnL'], 2),
            'avgPnL': round(md['totalPnL'] / len(md['chars']), 2) if md['chars'] else 0,
        })

    for bt, bd in sorted(bet_type_data.items(), key=lambda x: -x[1]['total']):
        wr = round(bd['wins'] / bd['total'] * 100, 1) if bd['total'] > 0 else 0
        avg_amt = round(sum(bd['amounts']) / len(bd['amounts'])) if bd['amounts'] else 0
        analysis['betTypes'].append({
            'name': bt, 'total': bd['total'], 'wins': bd['wins'],
            'winRate': wr, 'pnl': round(bd['pnl'], 2), 'avgAmount': avg_amt,
        })

    return analysis


# ============================================================
# MAIN - Generate everything
# ============================================================
def run():
    chars, state, bonds, bets_log, inplay = load_all()

    print("=== Generating All Extra Features ===\n")

    # 1. Round Report
    report = generate_round_report(chars, state, bets_log)
    with open(f'{BASE}/round-report.json', 'w') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"📋 戰報: {report['headline']}")

    # 2. Dialogues
    dialogues = generate_dialogues(chars, state, bonds, bets_log, inplay)
    with open(f'{BASE}/dialogues.json', 'w') as f:
        json.dump(dialogues, f, ensure_ascii=False, indent=2)
    print(f"💬 對話: {len(dialogues)} 條社交動態")

    # 3. Achievements
    achievements = check_achievements(state, chars)
    total_badges = sum(len(v) for v in achievements.values())
    with open(f'{BASE}/achievements.json', 'w') as f:
        json.dump(achievements, f, ensure_ascii=False, indent=2)
    print(f"🏅 成就: {total_badges} 個徽章已頒發")

    # 4. Season
    season = generate_season_data(state, chars)
    with open(f'{BASE}/season.json', 'w') as f:
        json.dump(season, f, ensure_ascii=False, indent=2)
    print(f"🏆 賽季: 第{season['seasonNum']}季 第{season['roundNum']}輪")

    # 5. Strategy Analysis
    analysis = generate_strategy_analysis(chars, state)
    with open(f'{BASE}/analysis.json', 'w') as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2)
    print(f"📊 分析: {len(analysis['strategies'])}種策略 | {len(analysis['mbtiComparison'])}種MBTI")

    print("\n✅ 所有額外功能數據已生成！")

if __name__ == '__main__':
    run()
