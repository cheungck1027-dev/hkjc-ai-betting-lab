#!/usr/bin/env python3
"""
AI Betting Engine v3 - ULTIMATE VERSION
========================================
Features:
1. Multiple bet types: HAD, Handicap, Over/Under, Correct Score, Half/Full
2. Character evolution: learn from results, strategy drift, bankruptcy, loans
3. Real news influence: web-scraped injury/form data affects decisions
4. Social influence system
5. Life events & mood system
6. 100 characters with 20+ strategies
"""
import json, random, math, hashlib
from datetime import datetime
from collections import defaultdict

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

with open(f'{BASE}/characters.json') as f: CHARACTERS = json.load(f)
with open(f'{BASE}/matches.json') as f: MATCHES = json.load(f)
with open(f'{BASE}/state.json') as f: STATE = json.load(f)
with open(f'{BASE}/social-bonds.json') as f: BONDS = json.load(f)
with open(f'{BASE}/life-events.json') as f: LIFE_EVENTS = json.load(f)

# Try to load news data if available
try:
    with open(f'{BASE}/news-data.json') as f: NEWS_DATA = json.load(f)
except:
    NEWS_DATA = {}

def char_rng(cid, mid, salt="v3"):
    h = hashlib.md5(f"{cid}-{mid}-{salt}-{STATE['roundNum']}".encode()).hexdigest()
    return int(h[:8], 16) / 0xFFFFFFFF

# ============================================================
# BET TYPE SYSTEM - Derive multiple markets from HAD odds
# ============================================================

def derive_handicap(hadH, hadD, hadA):
    """Derive handicap line and odds from HAD odds"""
    # Estimate implied probabilities
    total = 1/hadH + 1/hadD + 1/hadA
    pH = (1/hadH) / total
    pA = (1/hadA) / total

    # Determine handicap line based on strength difference
    diff = pH - pA
    if diff > 0.25: line = -1.5; hOdds = round(1.6 + random.uniform(-0.2, 0.2), 2); aOdds = round(2.3 - (diff-0.25)*2, 2)
    elif diff > 0.15: line = -1.0; hOdds = round(1.8 + random.uniform(-0.15, 0.15), 2); aOdds = round(2.0 + random.uniform(-0.15, 0.15), 2)
    elif diff > 0.05: line = -0.5; hOdds = round(1.85 + random.uniform(-0.1, 0.1), 2); aOdds = round(1.95 + random.uniform(-0.1, 0.1), 2)
    elif diff > -0.05: line = 0; hOdds = round(hadH * 0.9, 2); aOdds = round(hadA * 0.9, 2)
    elif diff > -0.15: line = 0.5; hOdds = round(1.95 + random.uniform(-0.1, 0.1), 2); aOdds = round(1.85 + random.uniform(-0.1, 0.1), 2)
    else: line = 1.0; hOdds = round(2.0 + random.uniform(-0.15, 0.15), 2); aOdds = round(1.8 + random.uniform(-0.15, 0.15), 2)

    return {'line': line, 'homeOdds': max(1.1, hOdds), 'awayOdds': max(1.1, aOdds)}

def derive_overunder(hadH, hadD, hadA):
    """Derive over/under 2.5 goals odds from HAD"""
    pD = (1/hadD) / (1/hadH + 1/hadD + 1/hadA)
    # Higher draw probability = lower scoring = more likely under
    overProb = 0.5 + (0.5 - pD) * 1.2
    overProb = max(0.3, min(0.7, overProb))
    margin = 1.06
    overOdds = round(margin / overProb, 2)
    underOdds = round(margin / (1 - overProb), 2)
    return {'line': 2.5, 'overOdds': max(1.1, overOdds), 'underOdds': max(1.1, underOdds)}

def derive_correct_scores(hadH, hadD, hadA):
    """Generate a few likely correct scores with odds"""
    total = 1/hadH + 1/hadD + 1/hadA
    pH = (1/hadH) / total
    pD = (1/hadD) / total
    scores = []
    if pH > 0.5:
        scores = [('1-0', 4.5), ('2-0', 6.0), ('2-1', 5.5), ('0-0', 8.0), ('1-1', 5.0), ('0-1', 9.0)]
    elif pD > 0.35:
        scores = [('0-0', 6.0), ('1-1', 4.5), ('1-0', 5.5), ('0-1', 5.5), ('2-2', 12.0), ('2-1', 7.0)]
    else:
        scores = [('0-1', 5.0), ('0-2', 6.5), ('1-2', 6.0), ('1-1', 5.5), ('0-0', 8.0), ('1-0', 8.5)]

    return [{'score': s, 'odds': round(o + random.uniform(-0.5, 1.5), 2)} for s, o in scores]

def derive_halffull(hadH, hadD, hadA):
    """Derive half-time/full-time combinations"""
    combos = []
    for ht in ['H','D','A']:
        for ft in ['H','D','A']:
            if ht == ft == 'H': odds = round(hadH * 1.8, 2)
            elif ht == ft == 'A': odds = round(hadA * 1.8, 2)
            elif ht == ft == 'D': odds = round(hadD * 2.5, 2)
            elif ht == 'D' and ft == 'H': odds = round(hadH * 2.2, 2)
            elif ht == 'D' and ft == 'A': odds = round(hadA * 2.2, 2)
            else: odds = round(max(hadH, hadA) * 3.0 + random.uniform(0, 5), 2)
            label_map = {'H':'主','D':'和','A':'客'}
            combos.append({'ht': ht, 'ft': ft, 'label': f"{label_map[ht]}/{label_map[ft]}", 'odds': max(2.0, odds)})
    return combos

def enrich_match(match):
    """Add all bet types to a match"""
    h, d, a = match['hadH'], match['hadD'], match['hadA']
    match['handicap'] = derive_handicap(h, d, a)
    match['overunder'] = derive_overunder(h, d, a)
    match['correctScores'] = derive_correct_scores(h, d, a)
    match['halfFull'] = derive_halffull(h, d, a)
    return match

# ============================================================
# NEWS INFLUENCE SYSTEM
# ============================================================

# Fallback team news (used when news-data.json has no entry)
TEAM_NEWS_FALLBACK = {
    '費倫天拿': {'form': 'average', 'injuries': [], 'morale': 'medium', 'news': '意大利盃有望'},
    '拉素': {'form': 'average', 'injuries': [], 'morale': 'medium', 'news': '中游球隊，表現穩定'},
    '狼隊': {'form': 'poor', 'injuries': [], 'morale': 'low', 'news': '護級形勢嚴峻'},
    '賓福特': {'form': 'good', 'injuries': [], 'morale': 'medium', 'news': '主場強勢'},
    '些路迪': {'form': 'excellent', 'injuries': [], 'morale': 'high', 'news': '蘇超龍頭，歐冠表現出色'},
    '士砵亭': {'form': 'good', 'injuries': [], 'morale': 'high', 'news': '葡超前列，實力不俗'},
}

# Load REAL news from tipsme.hk scrape (news-data.json)
# This is populated by scraping tipsme.hk/zh-TW/news before each betting round
REAL_TEAM_NEWS = {}
if NEWS_DATA and 'teamNews' in NEWS_DATA:
    REAL_TEAM_NEWS = NEWS_DATA['teamNews']
    print(f"📰 Loaded real news for {len(REAL_TEAM_NEWS)} teams from {NEWS_DATA.get('source','unknown')} ({NEWS_DATA.get('scraped','?')})")

# Merge: real news takes priority over fallback
TEAM_NEWS = {**TEAM_NEWS_FALLBACK}
for team, data in REAL_TEAM_NEWS.items():
    TEAM_NEWS[team] = data

# HKJC name → news name aliases (HKJC uses slightly different Chinese names)
TEAM_ALIASES = {
    '皇家馬歐里': '皇家馬德里', '皇馬': '皇家馬德里',
    '巴黎聖日耳': '巴黎聖日耳門', '祖云达斯': '祖雲達斯',
    '馬德里體育': '馬德里體育會', '馬體會': '馬德里體育會',
    '巴塞隆拿': '巴塞隆拿', '巴塞': '巴塞隆拿',
    '拜仁慕尼黑': '拜仁慕尼黑', '拜仁': '拜仁慕尼黑',
    '多蒙特': '多蒙特', '國米': '國際米蘭',
}

def get_team_news(team_name):
    """Find team news using fuzzy matching + alias table"""
    # Exact match first
    if team_name in TEAM_NEWS:
        return TEAM_NEWS[team_name]
    # Check alias
    for alias, canonical in TEAM_ALIASES.items():
        if alias in team_name or team_name in alias:
            if canonical in TEAM_NEWS:
                return TEAM_NEWS[canonical]
    # Partial match on TEAM_NEWS keys
    for key, news in TEAM_NEWS.items():
        if key in team_name or team_name in key:
            return news
    return None

def news_influence_thinking(char, match):
    """Generate thinking based on real news/form data from tipsme.hk"""
    home_news = get_team_news(match['home'])
    away_news = get_team_news(match['away'])
    thoughts = []
    bias = 0  # positive = home bias, negative = away bias

    if home_news:
        form = home_news.get('form', 'average')
        form_labels = {'excellent':'極佳','good':'不錯','average':'一般','poor':'低迷'}
        fl = form_labels.get(form,'一般')
        thoughts.append(f"📰 {match['home']}近況{fl}: {home_news.get('news','')}")
        if form == 'excellent': bias += 0.15
        elif form == 'good': bias += 0.08
        elif form == 'poor': bias -= 0.15
        if home_news.get('injuries'):
            inj = '、'.join(home_news['injuries'])
            thoughts.append(f"🏥 {match['home']}傷兵: {inj}，影響戰力")
            bias -= 0.05 * len(home_news['injuries'])
        morale = home_news.get('morale', 'medium')
        if morale == 'high':
            thoughts.append(f"💪 {match['home']}士氣高漲，信心十足")
            bias += 0.05
        elif morale == 'low':
            thoughts.append(f"😰 {match['home']}士氣低落，可能影響發揮")
            bias -= 0.05
        if home_news.get('keyFact'):
            thoughts.append(f"📌 關鍵: {match['home']} — {home_news['keyFact']}")
        if home_news.get('recentResults'):
            rr = ', '.join(home_news['recentResults'][:3])
            thoughts.append(f"📊 {match['home']}近績: {rr}")

    if away_news:
        form = away_news.get('form', 'average')
        fl = {'excellent':'極佳','good':'不錯','average':'一般','poor':'低迷'}.get(form,'一般')
        thoughts.append(f"📰 {match['away']}近況{fl}: {away_news.get('news','')}")
        if form == 'excellent': bias -= 0.15
        elif form == 'good': bias -= 0.08
        elif form == 'poor': bias += 0.15
        if away_news.get('injuries'):
            inj = '、'.join(away_news['injuries'])
            thoughts.append(f"🏥 {match['away']}傷兵: {inj}，影響戰力")
            bias += 0.05 * len(away_news['injuries'])
        morale = away_news.get('morale', 'medium')
        if morale == 'high':
            thoughts.append(f"💪 {match['away']}士氣高漲，信心十足")
            bias -= 0.05
        elif morale == 'low':
            thoughts.append(f"😰 {match['away']}士氣低落，可能影響發揮")
            bias += 0.05
        if away_news.get('keyFact'):
            thoughts.append(f"📌 關鍵: {match['away']} — {away_news['keyFact']}")
        if away_news.get('recentResults'):
            rr = ', '.join(away_news['recentResults'][:3])
            thoughts.append(f"📊 {match['away']}近績: {rr}")

    # Comparative analysis when both teams have news
    if home_news and away_news:
        hf = home_news.get('form','average')
        af = away_news.get('form','average')
        form_rank = {'excellent':4,'good':3,'average':2,'poor':1}
        hr, ar = form_rank.get(hf,2), form_rank.get(af,2)
        if hr > ar:
            thoughts.append(f"⚖️ 狀態對比: {match['home']}({hf}) 明顯優於 {match['away']}({af})，主隊有優勢")
        elif ar > hr:
            thoughts.append(f"⚖️ 狀態對比: {match['away']}({af}) 明顯優於 {match['home']}({hf})，客隊有優勢")
        else:
            thoughts.append(f"⚖️ 狀態對比: 兩隊近況相若({hf})，勝負難料")

    # Add source attribution if using real news
    if thoughts and REAL_TEAM_NEWS:
        thoughts.insert(0, f"📡 新聞來源: tipsme.hk ({NEWS_DATA.get('scraped','?')})")

    return thoughts, bias


def generate_odds_analysis(match, char):
    """Generate detailed odds analysis thinking"""
    hadH, hadD, hadA = match['hadH'], match['hadD'], match['hadA']
    total = 1/hadH + 1/hadD + 1/hadA
    margin = total - 1
    pH = (1/hadH)/total * 100
    pD = (1/hadD)/total * 100
    pA = (1/hadA)/total * 100
    thoughts = []
    thoughts.append(f"📈 賠率分析: 主{hadH} 和{hadD} 客{hadA} (莊家利潤{margin*100:.1f}%)")
    thoughts.append(f"📈 隱含概率: 主勝{pH:.0f}% 和局{pD:.0f}% 客勝{pA:.0f}%")
    if pH > 55:
        thoughts.append(f"📈 莊家明顯看好{match['home']}，主勝機會高")
    elif pA > 55:
        thoughts.append(f"📈 莊家明顯看好{match['away']}，客勝機會高")
    else:
        thoughts.append(f"📈 賠率顯示兩隊實力接近，冷門機會較高")
    return thoughts


def generate_personal_context(char, mem):
    """Generate thinking based on character's personal situation"""
    thoughts = []
    wallet = mem['wallet']
    pnl = wallet - 10000
    roi = pnl / 100

    # Financial situation
    if wallet < 3000:
        thoughts.append(f"💰 我資金只剩${wallet:,}，要非常小心，唔好再輸")
    elif wallet > 20000:
        thoughts.append(f"💰 資金充裕${wallet:,}，可以放膽少少")
    elif pnl < -3000:
        thoughts.append(f"💰 累計虧損${abs(pnl):,}，ROI {roi:.1f}%，需要調整策略")
    elif pnl > 3000:
        thoughts.append(f"💰 累計盈利${pnl:,}，ROI +{roi:.1f}%，保持節奏")

    # Streaks
    if mem.get('winStreak', 0) >= 3:
        thoughts.append(f"🔥 連贏{mem['winStreak']}場! 手感火熱，信心十足")
    elif mem.get('loseStreak', 0) >= 3:
        thoughts.append(f"❄️ 連輸{mem['loseStreak']}場...要冷靜分析，唔好衝動")
    elif mem.get('loseStreak', 0) == 2:
        thoughts.append(f"⚠️ 連輸2場，要更加謹慎")

    # Win rate context
    tp = mem.get('totalBetsPlaced', 0)
    tw = mem.get('totalBetsWon', 0)
    if tp >= 5:
        wr = tw / tp * 100
        if wr < 30:
            thoughts.append(f"📉 勝率只有{wr:.0f}% ({tw}/{tp})，策略似乎有問題")
        elif wr > 55:
            thoughts.append(f"📈 勝率{wr:.0f}% ({tw}/{tp})，策略有效繼續執行")

    # MBTI-based personality reaction
    mbti = char.get('mbti', 'ISFJ')
    if mbti[0] == 'E':
        if mem.get('loseStreak',0) >= 2:
            thoughts.append(f"🧠 [{mbti}] 雖然最近輸咗幾場，但我覺得運氣會轉")
    else:
        if mem.get('loseStreak',0) >= 2:
            thoughts.append(f"🧠 [{mbti}] 最近連輸...我需要重新檢視下數據")

    if mbti[1] == 'N':
        thoughts.append(f"🧠 [{mbti}] 直覺告訴我今場有嘢...")
    if mbti[2] == 'T':
        thoughts.append(f"🧠 [{mbti}] 撇開感情，純粹睇數據決定")
    elif mbti[2] == 'F':
        thoughts.append(f"🧠 [{mbti}] 我對呢隊有感覺，跟住感覺行")
    if mbti[3] == 'J':
        thoughts.append(f"🧠 [{mbti}] 按計劃執行，唔好偏離策略")
    elif mbti[3] == 'P':
        thoughts.append(f"🧠 [{mbti}] 靈活應變，見到好嘢就衝")

    return thoughts

# ============================================================
# CHARACTER EVOLUTION SYSTEM
# ============================================================

def evolve_character(char, mem):
    """Characters change based on their betting history"""
    evolution_notes = []

    # Losing streak effects
    if mem['loseStreak'] >= 3:
        stress = char.get('stressResponse', 'withdraw')
        if stress == 'chase':
            char['risk'] = min(0.95, char['risk'] + 0.1)
            evolution_notes.append(f"📈 連輸{mem['loseStreak']}場! 開始追注 (風險↑)")
        elif stress == 'withdraw':
            char['risk'] = max(0.02, char['risk'] - 0.1)
            evolution_notes.append(f"📉 連輸{mem['loseStreak']}場, 縮減投注 (風險↓)")
        elif stress == 'double_down':
            char['maxSingleBetPct'] = min(0.9, char['maxSingleBetPct'] * 1.3)
            evolution_notes.append(f"🔥 越輸越加碼!")
        elif stress == 'freeze':
            evolution_notes.append(f"❄️ 嚇到唔敢買")
        elif stress == 'impulsive':
            if random.random() < 0.3:
                new_strat = random.choice(['yolo', 'excitement', 'random'])
                old = char['strategy']
                char['strategy'] = new_strat
                evolution_notes.append(f"🔄 策略大轉變! {old} → {new_strat}")

    # Winning streak effects
    if mem['winStreak'] >= 3:
        if char['strategy'] in ['follow_trend', 'ultra_safe']:
            char['risk'] = min(0.8, char['risk'] + 0.05)
            evolution_notes.append(f"🎉 連贏{mem['winStreak']}場! 信心大增")
        if char['strategy'] == 'momentum':
            char['maxSingleBetPct'] = min(0.6, char['maxSingleBetPct'] * 1.1)
            evolution_notes.append(f"📈 追勢加碼!")

    # Bankruptcy warning
    if mem['wallet'] < 1000:
        evolution_notes.append(f"⚠️ 資金告急! 只剩${mem['wallet']}")
        char['risk'] = max(0.02, char['risk'] * 0.5)
        if mem['wallet'] < 200:
            evolution_notes.append(f"💀 接近破產!")

    # Learning from win rate
    if mem['totalBetsPlaced'] >= 5:
        win_rate = mem['totalBetsWon'] / mem['totalBetsPlaced']
        if win_rate < 0.2 and char['strategy'] not in ['yolo', 'random', 'excitement']:
            # Poor performers start questioning their strategy
            if random.random() < 0.15:
                old = char['strategy']
                safe_options = ['safe_favorite', 'bankroll', 'value', 'statistical']
                char['strategy'] = random.choice(safe_options)
                evolution_notes.append(f"🧠 勝率太低({win_rate:.0%})，改變策略: {old} → {char['strategy']}")
        elif win_rate > 0.6:
            evolution_notes.append(f"🏆 勝率{win_rate:.0%}! 策略有效，繼續保持")

    # Social learning: copy successful friends
    for bond in BONDS:
        partner_id = None
        if bond['charA'] == char['id']: partner_id = bond['charB']
        elif bond['charB'] == char['id']: partner_id = bond['charA']
        if partner_id and bond['type'] == '師徒':
            pmem = STATE['memories'].get(str(partner_id), {})
            if pmem.get('totalBetsPlaced', 0) > 3:
                pwr = pmem.get('totalBetsWon', 0) / pmem['totalBetsPlaced']
                if pwr > 0.5 and random.random() < 0.2:
                    partner = next((c for c in CHARACTERS if c['id'] == partner_id), None)
                    if partner:
                        old = char['strategy']
                        char['strategy'] = partner['strategy']
                        evolution_notes.append(f"📚 向{partner['name']}學習，策略: {old} → {partner['strategy']}")

    return evolution_notes

# ============================================================
# MATCH SCORING & DECISION ENGINE
# ============================================================

BIG_TEAMS = {
    "英超": ["阿士東維拉","曼聯","伊普斯賓","李斯特城","賓福特","狼隊","利物浦","車路士","曼城","阿仙奴"],
    "歐冠": ["車路士","巴黎聖日耳門","曼城","皇家馬","阿仙奴","利華古遜","些路迪","士砵亭"],
    "意甲": ["克雷莫納","費倫天拿","科荙","拉素"],
    "英冠": ["布里斯托城","考文垂","德比","哈德斯菲爾德","盧頓"],
    "女子": ["哈馬比女足","域斯祖女足","韋克舍女足","烏茲別克女足","中華台北女足","北韓女足"],
}
LEAGUE_MAP = {"英超":"英格蘭超級聯賽","歐冠":"歐洲聯賽冠軍盃","意甲":"意大利甲組聯賽",
              "英冠":"英格蘭冠軍聯賽","女子":"女子亞洲盃"}

def get_league(team):
    for lg, teams in BIG_TEAMS.items():
        if any(t in team for t in teams): return lg
    return "其他"

def match_attractiveness(char, match):
    score = 0.25
    lg = get_league(match['home']) or get_league(match['away'])
    mapped = LEAGUE_MAP.get(lg, "")
    if mapped in char.get('preferLeagues', []): score += 0.35
    if min(match['hadH'], match['hadA']) < 1.5: score += 0.1
    if char['strategy'] in ['excitement','yolo','story','underdog'] and max(match['hadH'],match['hadA']) > 4: score += 0.15
    if char['strategy'] == 'ethical' and lg == "女子": score += 0.45
    return min(score, 1.0)

# ============================================================
# BET TYPE SELECTION - Characters choose WHAT to bet on
# ============================================================

BET_TYPE_PREFS = {
    'value': ['had', 'handicap', 'overunder'],
    'statistical': ['had', 'handicap', 'overunder', 'halffull'],
    'contrarian': ['had', 'correctscore', 'halffull'],
    'arbitrage': ['had', 'handicap'],
    'excitement': ['correctscore', 'halffull', 'had'],
    'gut_feeling': ['had', 'correctscore', 'overunder'],
    'superstitious': ['correctscore', 'had'],
    'dream': ['correctscore', 'halffull'],
    'safe_favorite': ['had', 'handicap'],
    'ultra_safe': ['had'],
    'bankroll': ['had', 'handicap'],
    'follow_trend': ['had', 'overunder'],
    'contrarian_social': ['had', 'halffull'],
    'influencer': ['had', 'overunder'],
    'story': ['had', 'correctscore', 'halffull'],
    'loyalty': ['had', 'overunder'],
    'underdog': ['had', 'correctscore'],
    'portfolio': ['had', 'handicap', 'overunder'],
    'momentum': ['had', 'handicap'],
    'hedging': ['had', 'overunder', 'handicap'],
    'yolo': ['correctscore', 'halffull', 'had'],
    'random': ['had', 'handicap', 'overunder', 'correctscore', 'halffull'],
    'ethical': ['had'],
    'seasonal': ['had', 'overunder'],
}

def choose_bet_type(char, match, rng):
    """Pick which bet type to use"""
    prefs = BET_TYPE_PREFS.get(char['strategy'], ['had'])
    # Weight toward first preference
    weights = [3, 2, 1, 0.5, 0.3][:len(prefs)]
    total_w = sum(weights)
    r = rng * total_w
    cumulative = 0
    for i, w in enumerate(weights):
        cumulative += w
        if r <= cumulative:
            return prefs[i]
    return prefs[0]

# ============================================================
# UNIFIED DECISION ENGINE
# ============================================================

def decide_bet(char, match, rng, social_influences, mood_text, news_thoughts, news_bias):
    strat = char['strategy']
    risk = char['risk']
    mem = STATE['memories'][str(char['id'])]
    wallet = mem['wallet']
    hadH, hadD, hadA = match['hadH'], match['hadD'], match['hadA']

    if rng < (1.0 - risk) * 0.35:
        return None

    think = list(news_thoughts)  # Start with news context

    # Add odds analysis
    think.extend(generate_odds_analysis(match, char))

    # Add personal context
    think.extend(generate_personal_context(char, mem))

    # Add mood if relevant
    if mood_text != "平常心":
        think.append(f"🎭 心情: {mood_text}")

    # Add social influence context
    if social_influences:
        for stype, pid, pbet in social_influences[:2]:
            pname = next((c['name'] for c in CHARACTERS if c['id']==pid), '?')
            think.append(f"👥 {stype}{pname}買咗{pbet.get('choice','')} @{pbet.get('odds','')}")

    bet_type = choose_bet_type(char, match, char_rng(char['id'], match['id'], 'type'))
    think.append(f"🎲 策略「{char.get('strategyLabel', strat)}」→ 選擇{bet_type}盤口")

    # ---- HAD BETS ----
    if bet_type == 'had':
        choice, confidence = _decide_had(char, strat, hadH, hadD, hadA, rng, think, social_influences, mem, news_bias, match)
        if choice is None: return None
        odds = {'H':hadH,'D':hadD,'A':hadA}[choice]
        label = {'H':'主勝','D':'和局','A':'客勝'}[choice]
        # Add final decision summary
        pot = calc_amount(char, confidence, wallet, 1.0) * odds
        think.append(f"✅ 最終決定: {label} @{odds}，信心{confidence*100:.0f}%")
        return {'betType': '主客和', 'choice': choice, 'choiceLabel': label, 'odds': odds, 'confidence': confidence, 'thinking': think}

    # ---- HANDICAP BETS ----
    elif bet_type == 'handicap':
        hcp = match.get('handicap', derive_handicap(hadH, hadD, hadA))
        think.append(f"📊 讓球盤: {match['home']} ({hcp['line']:+.1f})，主{hcp['homeOdds']} 客{hcp['awayOdds']}")
        adjusted_bias = news_bias + (0.1 if hcp['line'] < 0 else -0.1)
        if hcp['line'] < 0:
            think.append(f"📊 {match['home']}讓{abs(hcp['line'])}球，莊家認為主隊實力較強")
        else:
            think.append(f"📊 {match['away']}讓{abs(hcp['line'])}球，莊家認為客隊實力較強")
        if (rng + adjusted_bias > 0.5) or (strat in ['safe_favorite'] and hcp['line'] < 0):
            choice = 'H'
            odds = hcp['homeOdds']
            think.append(f"✅ 買主隊讓球 @{odds}，睇好{match['home']}大勝")
        else:
            choice = 'A'
            odds = hcp['awayOdds']
            think.append(f"✅ 買客隊受讓 @{odds}，{match['away']}唔會輸太多甚至有機會贏")
        label = f"讓球{'主' if choice=='H' else '客'}({hcp['line']:+.1f})"
        return {'betType': '讓球', 'choice': choice, 'choiceLabel': label, 'odds': odds,
                'confidence': 0.5 + rng*0.2, 'thinking': think, 'line': hcp['line']}

    # ---- OVER/UNDER BETS ----
    elif bet_type == 'overunder':
        ou = match.get('overunder', derive_overunder(hadH, hadD, hadA))
        think.append(f"⚽ 入球大細: {ou['line']}球 (大{ou['overOdds']} 細{ou['underOdds']})")
        # Reasoning based on team form
        home_news = get_team_news(match['home'])
        away_news = get_team_news(match['away'])
        if home_news and home_news.get('form') == 'excellent' and away_news and away_news.get('form') == 'poor':
            think.append(f"⚽ {match['home']}攻力強、{match['away']}防守差，大球機會高")
        elif hadD < 3.2:
            think.append(f"⚽ 和局賠率偏低({hadD})，兩隊可能踢得保守，細球機會較高")
        else:
            think.append(f"⚽ 分析兩隊進攻力同防守力...")

        if strat in ['excitement', 'story', 'yolo']:
            choice = 'over'
            think.append(f"✅ 大球! {char.get('strategyLabel',strat)}策略偏好刺激，多入球先有睇頭 @{ou['overOdds']}")
        elif strat in ['safe_favorite', 'ultra_safe', 'hedging']:
            choice = 'under'
            think.append(f"✅ 細球穩陣，{char.get('strategyLabel',strat)}策略偏保守 @{ou['underOdds']}")
        else:
            choice = 'over' if rng > 0.5 else 'under'
            think.append(f"✅ {'大' if choice=='over' else '細'}球 @{ou['overOdds'] if choice=='over' else ou['underOdds']}")
        odds = ou['overOdds'] if choice == 'over' else ou['underOdds']
        label = f"入球{'大' if choice=='over' else '細'}{ou['line']}"
        return {'betType': '入球大細', 'choice': choice, 'choiceLabel': label, 'odds': odds,
                'confidence': 0.45 + rng*0.2, 'thinking': think}

    # ---- CORRECT SCORE ----
    elif bet_type == 'correctscore':
        scores = match.get('correctScores', derive_correct_scores(hadH, hadD, hadA))
        think.append(f"🎯 波膽! 高風險高回報盤口")
        think.append(f"🎯 可選比分: {', '.join(s['score']+'@'+str(s['odds']) for s in scores[:4])}")
        if strat in ['superstitious', 'dream']:
            idx = int(char_rng(char['id'], match['id'], 'cs') * len(scores))
            pick = scores[idx % len(scores)]
            think.append(f"🎯 直覺告訴我: {match['home']} {pick['score']} {match['away']}!")
            think.append(f"✅ 跟住感覺走! @{pick['odds']}倍")
        elif strat == 'yolo':
            pick = max(scores, key=lambda s: s['odds'])
            think.append(f"🎯 搏最高賠率! {pick['score']} @{pick['odds']}倍，中一次就翻身")
            think.append(f"✅ YOLO! 人生就係要搏")
        else:
            pick = min(scores, key=lambda s: s['odds'])
            think.append(f"🎯 根據賠率分析，最可能比分: {pick['score']} @{pick['odds']}")
            think.append(f"✅ 選擇最合理比分")
        return {'betType': '波膽', 'choice': pick['score'], 'choiceLabel': f"波膽{pick['score']}",
                'odds': pick['odds'], 'confidence': 0.3 + rng*0.2, 'thinking': think}

    # ---- HALF/FULL ----
    elif bet_type == 'halffull':
        hf = match.get('halfFull', derive_halffull(hadH, hadD, hadA))
        think.append(f"⏱️ 半全場! 需要預判比賽走勢")
        if strat in ['safe_favorite', 'statistical'] and hadH < hadA:
            pick = next((x for x in hf if x['ht']=='H' and x['ft']=='H'), hf[0])
            think.append(f"⏱️ 主隊係大熱門，預計全場控制比賽")
            think.append(f"✅ 主/主 @{pick['odds']}，主隊上半場領先然後全場贏")
        elif strat in ['excitement', 'story']:
            dramatic = [x for x in hf if x['ht'] != x['ft']]
            pick = random.choice(dramatic) if dramatic else hf[0]
            think.append(f"⏱️ 搵反勝劇情! 下半場逆轉先夠刺激")
            think.append(f"✅ {pick['label']} @{pick['odds']}，期待戲劇性結局")
        else:
            idx = int(rng * len(hf))
            pick = hf[idx % len(hf)]
            think.append(f"✅ {pick['label']} @{pick['odds']}")
        return {'betType': '半全場', 'choice': pick['label'], 'choiceLabel': f"半全場{pick['label']}",
                'odds': pick['odds'], 'confidence': 0.3 + rng*0.15, 'thinking': think}

    return None

def _decide_had(char, strat, hadH, hadD, hadA, rng, think, social_influences, mem, news_bias, match=None):
    """Core HAD decision logic (kept from v2 but with news influence)"""
    implied_h, implied_d, implied_a = 1/hadH, 1/hadD, 1/hadA
    margin = implied_h + implied_d + implied_a - 1
    choice, confidence = None, 0.5

    if strat == 'value':
        think.append("📊 價值投注分析 — 搵莊家低估嘅選項")
        best_c, best_v = None, 0
        for c, odd in [('H',hadH),('D',hadD),('A',hadA)]:
            if 1.5 < odd < 6:
                v = odd / (1+margin)
                if c == 'H': v += news_bias * 0.5
                elif c == 'A': v -= news_bias * 0.5
                lbl = {'H':'主勝','D':'和局','A':'客勝'}[c]
                think.append(f"📊 {lbl}@{odd}: 價值指數{v:.2f} {'⭐有價值' if v > best_v and v > 0.9 else ''}")
                if v > best_v: best_v, best_c = v, c
        if best_c:
            choice = best_c; confidence = 0.6 + rng*0.2
            lbl = {'H':'主勝','D':'和局','A':'客勝'}[choice]
            odd = {'H':hadH,'D':hadD,'A':hadA}[choice]
            think.append(f"📊 結合新聞分析(偏差{news_bias:+.2f})，{lbl}最有價值")
        else: return None, 0

    elif strat == 'statistical':
        think.append("📐 統計模型分析 — 數據行先")
        spread = abs(hadH - hadA)
        think.append(f"📐 主客賠率差距: {spread:.2f}，新聞偏差: {news_bias:+.2f}")
        if spread < 1.5 and abs(news_bias) < 0.1:
            choice, confidence = 'D', 0.5 + rng*0.2
            think.append(f"📐 兩隊實力接近(賠率差{spread:.1f})，新聞面平均，模型偏向和局 @{hadD}")
        elif hadH + news_bias*5 < hadA - news_bias*5:
            choice, confidence = 'H', 0.55
            think.append(f"📐 主隊賠率{hadH}偏低+新聞正面，統計模型睇好主隊")
        else:
            choice, confidence = 'A', 0.55
            think.append(f"📐 客隊數據更優，統計模型睇好客隊")

    elif strat in ['excitement', 'dream']:
        think.append("🎨 直覺/夢境策略 — 跟住感覺走!")
        if hadA > 3 and rng > 0.3:
            choice, confidence = 'A', 0.4 + rng*0.3
            think.append(f"🎨 客勝@{hadA}倍! 高賠率=高刺激，值得一搏")
        elif hadH > 3 and rng > 0.5:
            choice, confidence = 'H', 0.4 + rng*0.2
            think.append(f"🎨 主勝@{hadH}倍! 賠率好高，感覺會爆冷")
        else:
            choice, confidence = random.choice(['H','D','A']), 0.3
            think.append(f"🎨 隨感覺揀{'主勝' if choice=='H' else '和局' if choice=='D' else '客勝'}，唔使想太多")

    elif strat == 'contrarian':
        think.append("🔄 逆市策略 — 同大眾對著幹")
        fav = 'H' if hadH < hadA else 'A'
        fav_name = match['home'] if fav=='H' else match['away']
        choice = 'A' if hadH < hadA else 'H'
        my_name = match['home'] if choice=='H' else match['away']
        confidence = 0.45 + rng*0.2
        think.append(f"🔄 大眾睇好{fav_name}(賠率較低)，我偏偏買{my_name}")
        think.append(f"🔄 逆市而行，冷門出嚟回報更高 @{hadH if choice=='H' else hadA}")

    elif strat in ['safe_favorite', 'bankroll']:
        m = min(hadH, hadA)
        if m > 2.0:
            think.append(f"🛡️ 最低賠率{m}太高，無明顯大熱門，今場pass")
            return None, 0
        choice = 'H' if hadH < hadA else 'A'
        fav_name = match['home'] if choice=='H' else match['away']
        confidence = 0.7 if m < 1.3 else 0.5
        think.append(f"🛡️ 穩陣策略 — 只買大熱門")
        think.append(f"🛡️ {fav_name}係大熱門 @{m}，{'非常穩陣' if m<1.3 else '尚算穩定'}，信心{confidence*100:.0f}%")

    elif strat == 'ultra_safe':
        m = min(hadH, hadA)
        if m > 1.4 or rng < 0.6:
            think.append(f"🔒 超保守策略: 最低賠率{m}{'太高' if m>1.4 else ''}，信心唔夠，唔買")
            return None, 0
        choice = 'H' if hadH < hadA else 'A'
        confidence = 0.3
        think.append(f"🔒 極保守策略 — 只係超大熱門先買")
        think.append(f"🔒 賠率{m}夠低，應該穩陣，但都要控制注碼")

    elif strat in ['follow_trend', 'influencer']:
        think.append(f"👥 {'跟風' if strat=='follow_trend' else '網紅'}策略 — 參考社交圈子")
        if social_influences:
            si = social_influences[0]
            pname = next((c['name'] for c in CHARACTERS if c['id']==si[1]), '?')
            choice = si[2]['choice'] if strat == 'follow_trend' else ('A' if si[2]['choice']=='H' else 'H')
            if strat == 'follow_trend':
                think.append(f"👥 {si[0]}{pname}買咗{si[2]['choice']}，跟住佢!")
            else:
                think.append(f"👥 {si[0]}{pname}買咗{si[2]['choice']}，我偏偏買另一邊")
        else:
            choice = 'H' if hadH < hadA else 'A'
            think.append(f"👥 今輪無社交參考，自己睇賠率決定")
        confidence = 0.4 + rng*0.15

    elif strat in ['story', 'loyalty']:
        think.append(f"📖 {'故事' if strat=='story' else '忠誠'}策略 — 感情行先")
        choice = 'H' if rng > 0.45 else 'A'
        pick_name = match['home'] if choice=='H' else match['away']
        confidence = 0.5
        think.append(f"📖 對{pick_name}有感情/有故事，支持佢!")

    elif strat in ['gut_feeling', 'superstitious', 'seasonal']:
        strat_emoji = {'gut_feeling':'🔮','superstitious':'🍀','seasonal':'📅'}
        think.append(f"{strat_emoji.get(strat,'🔮')} {char.get('strategyLabel',strat)}策略")
        if rng > 0.6: choice = 'H'
        elif rng > 0.3: choice = 'A'
        else: choice = 'D'
        confidence = 0.4 + rng*0.25
        lbl = {'H':'主勝','D':'和局','A':'客勝'}[choice]
        if strat == 'superstitious':
            think.append(f"🍀 今日運氣話我知係{lbl}!")
        elif strat == 'seasonal':
            think.append(f"📅 按照歷史規律，呢個時段{lbl}機會較高")
        else:
            think.append(f"🔮 直覺強烈暗示{lbl}，跟住gut feeling")

    elif strat == 'underdog':
        think.append("🐶 冷門獵人策略 — 專搵高賠率冷門")
        if hadH > hadA and hadH > 2.5:
            choice = 'H'
            think.append(f"🐶 {match['home']}係冷門(@{hadH})，值得一搏!")
        elif hadA > 2.5:
            choice = 'A'
            think.append(f"🐶 {match['away']}係冷門(@{hadA})，冷門中咗回報高!")
        else:
            think.append(f"🐶 冇明顯冷門(主{hadH}客{hadA})，放棄今場")
            return None, 0
        confidence = 0.4 + rng*0.2

    elif strat in ['portfolio', 'hedging']:
        think.append(f"📊 {'組合' if strat=='portfolio' else '對沖'}策略 — 分散風險")
        if hadH < 2:
            choice, confidence = 'H', 0.55
            think.append(f"📊 主隊賠率低({hadH})，穩陣選擇")
        elif hadA < 2:
            choice, confidence = 'A', 0.55
            think.append(f"📊 客隊賠率低({hadA})，穩陣選擇")
        elif rng > 0.6:
            choice, confidence = 'D', 0.35
            think.append(f"📊 兩隊勢均力敵，和局@{hadD}有價值")
        else:
            choice, confidence = ('H' if rng>0.5 else 'A'), 0.4
            think.append(f"📊 略為偏向{'主' if choice=='H' else '客'}隊")

    elif strat in ['yolo', 'random']:
        think.append("🎰 YOLO/隨機策略 — 命運話事!")
        choice = random.choice(['H','D','A'])
        confidence = 0.3 + rng*0.5
        lbl = {'H':'主勝','D':'和局','A':'客勝'}[choice]
        think.append(f"🎰 隨機揀: {lbl}! 結果點都係靠運氣")

    elif strat == 'ethical':
        think.append("🌱 道德投注策略 — 支持小眾/女子運動")
        home = match.get('home','') if match else ''
        away = match.get('away','') if match else ''
        if get_league(home) == "女子" or get_league(away) == "女子":
            choice = 'H' if hadH < hadA else 'A'; confidence = 0.5
            think.append(f"🌱 支持女子足球! 買大熱門以示支持")
        elif rng > 0.85:
            choice = random.choice(['H','A']); confidence = 0.2
            think.append(f"🌱 雖然唔係女子賽事，但偶爾都想參與下")
        else:
            think.append(f"🌱 唔係重點支持對象，今場pass")
            return None, 0

    elif strat == 'momentum':
        think.append("🚀 動量策略 — 贏開就繼續贏")
        if mem['winStreak'] > 0:
            choice = 'H' if hadH < hadA else 'A'; confidence = 0.6
            think.append(f"🚀 連贏{mem['winStreak']}場! 保持動量，繼續買大熱門")
        else:
            choice = random.choice(['H','D','A']); confidence = 0.4
            think.append(f"🚀 未有連贏勢頭，隨便揀一個試試")

    elif strat == 'contrarian_social':
        think.append("🔄 社交逆向策略 — 同大眾唱反調")
        choice = 'A' if hadH < hadA else 'H'; confidence = 0.5
        fav = match['home'] if hadH<hadA else match['away']
        my = match['home'] if choice=='H' else match['away']
        think.append(f"🔄 大眾都買{fav}，我買{my}搏冷門")

    else:
        choice = 'H' if hadH < hadA else 'A'; confidence = 0.4
        think.append(f"🔵 預設策略: 買大熱門")

    return choice, confidence

def calc_amount(char, confidence, wallet, mood_mod):
    base_pct = {'spread':0.03,'heavy':0.08,'minimal':0.02,'balanced':0.05,'tiny':0.015,
                'token':0.01,'dramatic':0.06,'confident':0.05,'reluctant':0.01,'all_in':0.1,
                'calculated':0.04,'impulse':0.07}.get(char['budgetStyle'], 0.03)
    pct = min(base_pct * (0.5 + confidence), char['maxSingleBetPct'])
    amt = max(10, min(wallet * pct, wallet * 0.4))
    amt = int(amt * mood_mod)
    return max(10, int(round(amt / 10) * 10))

# ============================================================
# SOCIAL INFLUENCE
# ============================================================
def get_social_influence(char_id, match_id, all_decisions):
    influences = []
    for bond in BONDS:
        pid = None
        if bond['charA'] == char_id: pid = bond['charB']
        elif bond['charB'] == char_id: pid = bond['charA']
        if pid and str(pid) in all_decisions:
            pb = all_decisions[str(pid)].get(match_id)
            if pb: influences.append((bond['type'], pid, pb))
    return influences

def get_mood(cid):
    events = LIFE_EVENTS.get(str(cid), [])
    if not events: return 1.0, "平常心"
    e = random.choice(events)
    return e['budgetMod'], e['text']

# ============================================================
# MAIN
# ============================================================
def run():
    rn = STATE['roundNum'] + 1
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Enrich matches with all bet types
    for m in MATCHES:
        enrich_match(m)

    print(f"{'='*60}")
    print(f"🏟️  HKJC AI 賭波聯盟 v3 - 第 {rn} 輪")
    print(f"📅 {ts} | ⚽ {len(MATCHES)}場 | 👥 {len(CHARACTERS)}人")
    print(f"📊 投注類型: 主客和/讓球/入球大細/波膽/半全場")
    print(f"{'='*60}\n")

    all_bets = []
    all_decisions = {}
    round_log = {"round": rn, "timestamp": ts, "matchCount": len(MATCHES), "characterBets": []}
    bet_type_stats = defaultdict(int)

    # Evolution phase
    evolution_log = []
    for char in CHARACTERS:
        mem = STATE['memories'][str(char['id'])]
        notes = evolve_character(char, mem)
        if notes:
            evolution_log.append({'name': char['name'], 'notes': notes})
            for n in notes:
                print(f"  🔄 {char['emoji']} {char['name']}: {n}")

    if evolution_log:
        print(f"\n📈 {len(evolution_log)}個角色有進化變化\n")

    # Sort by social energy
    energy_order = {'low': 0, 'medium': 1, 'high': 2, 'very_high': 3}
    sorted_chars = sorted(CHARACTERS, key=lambda c: energy_order.get(c.get('socialEnergy','medium'), 1))

    for char in sorted_chars:
        cid = str(char['id'])
        mem = STATE['memories'][cid]
        wallet = mem['wallet']
        mood_mod, mood_text = get_mood(char['id'])

        char_bets = []
        total_wagered = 0
        char_decisions = {}

        for match in MATCHES:
            attr = match_attractiveness(char, match)
            if attr < 0.4 + (1 - char['risk']) * 0.3:
                continue

            rng = char_rng(char['id'], match['id'])
            social = get_social_influence(char['id'], match['id'], all_decisions)
            news_thoughts, news_bias = news_influence_thinking(char, match)

            result = decide_bet(char, match, rng, social, mood_text, news_thoughts, news_bias)
            if result is None:
                continue

            remaining = wallet - total_wagered
            if remaining < 50: break

            amt = calc_amount(char, result['confidence'], remaining, mood_mod)
            amt = min(amt, remaining)
            if len(char_bets) >= char['betRange'][1]: break

            total_wagered += amt
            bet_type_stats[result['betType']] += 1

            bet = {
                "matchId": match['id'], "home": match['home'], "away": match['away'],
                "dateTime": match['dateTime'],
                "betType": result['betType'],
                "choice": result['choice'], "choiceLabel": result['choiceLabel'],
                "odds": result['odds'], "amount": amt,
                "potentialWin": round(amt * result['odds'], 2),
                "thinking": result['thinking'],
            }
            char_bets.append(bet)
            char_decisions[match['id']] = {'choice': result.get('choice','H'), 'odds': result['odds']}

        all_decisions[cid] = char_decisions

        summary = f"揀咗{len(char_bets)}場，投${total_wagered:,}" if char_bets else "今輪pass"
        if mood_text != "平常心" and char_bets:
            summary += f" ({mood_text})"

        round_log["characterBets"].append({
            "charId": char['id'], "name": char['name'], "mbti": char['mbti'],
            "strategy": char['strategy'], "strategyLabel": char.get('strategyLabel',''),
            "wallet": wallet, "betsCount": len(char_bets),
            "totalWagered": total_wagered, "summary": summary,
            "mood": mood_text, "bets": char_bets,
            "evolution": next((e['notes'] for e in evolution_log if e['name']==char['name']), [])
        })

        for bet in char_bets:
            all_bets.append({"charId": char['id'], "charName": char['name'], **bet})

    # Update state
    STATE['roundNum'] = rn
    STATE['activeBets'] = all_bets
    STATE['lastScrapeTime'] = ts

    with open(f'{BASE}/state.json', 'w') as f:
        json.dump(STATE, f, ensure_ascii=False, indent=2)
    # Accumulate bets-log: load existing rounds + append new round
    try:
        with open(f'{BASE}/bets-log.json') as f:
            existing_log = json.load(f)
        if not isinstance(existing_log, list):
            existing_log = []
        # Remove any existing entry for this round (re-run)
        existing_log = [r for r in existing_log if r.get('round') != rn]
    except:
        existing_log = []
    existing_log.append(round_log)
    with open(f'{BASE}/bets-log.json', 'w') as f:
        json.dump(existing_log, f, ensure_ascii=False, indent=2)

    # Stats
    active = len([c for c in round_log['characterBets'] if c['betsCount'] > 0])
    total_amt = sum(b['amount'] for b in all_bets)

    print(f"\n{'='*60}")
    print(f"📊 第 {rn} 輪總結")
    print(f"{'='*60}")
    print(f"👥 參與: {active}/100人 | 📝 總注數: {len(all_bets)} | 💰 ${total_amt:,}")
    print(f"\n📋 投注類型分佈:")
    for bt, cnt in sorted(bet_type_stats.items(), key=lambda x: -x[1]):
        pct = cnt / len(all_bets) * 100
        bar = '█' * int(pct / 3)
        print(f"  {bt}: {cnt}注 ({pct:.0f}%) {bar}")

    print(f"\n🏆 Top 10:")
    top = sorted(round_log['characterBets'], key=lambda x: x['totalWagered'], reverse=True)[:10]
    for i, cl in enumerate(top, 1):
        c = next(ch for ch in CHARACTERS if ch['id'] == cl['charId'])
        print(f"  {i}. {c['emoji']} {cl['name']}({c['mbti']}) {cl['betsCount']}注 ${cl['totalWagered']:,}")

    return round_log

if __name__ == '__main__':
    run()
    print(f"\n✅ v3引擎完成!")
