#!/usr/bin/env python3
"""Build the ULTIMATE interactive dashboard HTML with all features embedded"""
import json, os
from collections import defaultdict, Counter

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def load_json(name, default=None):
    path = f'{BASE}/{name}'
    if not os.path.exists(path): return default if default is not None else []
    with open(path) as f: return json.load(f)

bl = load_json('bets-log.json', [])
st = load_json('state.json', {'memories':{},'activeBets':[],'history':[],'roundNum':0})
chars = load_json('characters.json', [])
matches = load_json('matches.json', [])
report = load_json('round-report.json', {'headline':'等待數據','sections':[]})
dialogues = load_json('dialogues.json', [])
achievements = load_json('achievements.json', {})
season = load_json('season.json', {'seasonNum':1,'roundNum':0,'standings':[]})
analysis = load_json('analysis.json', {'strategies':[],'mbtiComparison':[],'riskReturn':[]})
inplay = load_json('inplay-log.json', [])

# Build compact character data with leaderboard stats
compact_chars = []
leaderboard = []
for c in chars:
    cid = str(c['id'])
    mem = st['memories'].get(cid, {})
    compact_chars.append({
        'id': c['id'], 'n': c['name'], 'age': c['age'], 't': c['title'],
        'e': c['emoji'], 'mb': c['mbti'], 'ml': c.get('mbtiLabel',''),
        'mc': c.get('mbtiColor','#999'), 'mg': c.get('mbtiGroup',''),
        's': c['strategy'], 'sl': c.get('strategyLabel', c['strategy']),
        'r': c['risk'], 'w': mem.get('wallet', c.get('wallet',10000)),
        'ach': achievements.get(str(c['id']), achievements.get(c['id'], [])),
    })
    total_placed = mem.get('totalBetsPlaced', 0)
    total_won = mem.get('totalBetsWon', 0)
    total_pnl = mem.get('totalPnL', 0)
    bet_results_list = mem.get('betResults', [])
    settled_results = [r['won'] for r in bet_results_list if r.get('won') is not None]
    if not settled_results and total_placed > 0:
        for h in st.get('history', []):
            for sr in h.get('settledResults', []):
                if sr.get('charId') == c['id'] and sr.get('won') is not None:
                    settled_results.append(sr['won'])
    if not settled_results and total_placed > 0:
        settled_results = [True]*total_won + [False]*(total_placed - total_won)
    last5 = settled_results[-5:] if settled_results else []
    last10 = settled_results[-10:] if settled_results else []
    wr_total = round(total_won/total_placed*100, 1) if total_placed > 0 else -1
    wr_5 = round(sum(last5)/len(last5)*100, 1) if last5 else -1
    wr_10 = round(sum(last10)/len(last10)*100, 1) if last10 else -1
    active_count = len([b for b in st.get('activeBets', []) if b.get('charId') == c['id']])
    total_wagered = sum(r.get('amount', r.get('odds', 1) * 100) for r in bet_results_list)
    if total_wagered == 0:
        # Fallback: estimate from active bets
        for ab in st.get('activeBets', []):
            if ab.get('charId') == c['id']:
                total_wagered += ab.get('amount', 0)
    roi = round(total_pnl / total_wagered * 100, 1) if total_wagered > 0 else 0
    leaderboard.append({
        'id': c['id'], 'n': c['name'], 'e': c['emoji'],
        'mb': c['mbti'], 'mc': c.get('mbtiColor','#999'),
        'sl': c.get('strategyLabel', c['strategy']),
        't': c['title'],
        'w': mem.get('wallet', c.get('wallet',10000)),
        'tp': total_placed, 'tw': total_won,
        'pnl': total_pnl, 'roi': roi,
        'wr': wr_total, 'w5': wr_5, 'w10': wr_10,
        'ac': active_count,
        'ws': mem.get('winStreak', 0), 'ls': mem.get('loseStreak', 0),
        'ach': achievements.get(str(c['id']), achievements.get(c['id'], [])),
    })

char_bets = bl[-1]['characterBets'] if bl else []
match_bets = defaultdict(list)
for cb in char_bets:
    for b in cb.get('bets', []):
        # Keep only final decision for match view (detail in PD)
        raw_th = b.get('thinking', [])
        key_th = [t for t in raw_th if t.startswith('✅')][:1]
        match_bets[b['matchId']].append({
            'ci': cb['charId'], 'cn': cb['name'],
            'bt': b['betType'], 'cl': b['choiceLabel'],
            'o': b['odds'], 'a': b['amount'], 'th': key_th
        })

compact_matches = []
for m in matches:
    mid = m['id']
    bets = match_bets.get(mid, [])
    compact_matches.append({
        'id': mid, 'dt': m['dateTime'], 'h': m['home'], 'a': m['away'],
        'hO': m['hadH'], 'dO': m['hadD'], 'aO': m['hadA'], 'bc': len(bets),
    })
compact_matches.sort(key=lambda x: -x['bc'])

# Compact CB data (minimal - just summary, no per-bet detail; detail is in PD)
compact_cb = []
for cb in char_bets:
    compact_cb.append({
        'charId': cb['charId'], 'name': cb['name'],
        'mbti': cb.get('mbti',''), 'sl': cb.get('strategyLabel',''),
        'w': cb.get('wallet',0), 'n': cb.get('betsCount',0),
        'tw': cb.get('totalWagered',0), 'sm': cb.get('summary',''),
        'md': cb.get('mood',''), 'ev': cb.get('evolution', []),
    })

# JSON encode all data
j = lambda d: json.dumps(d, ensure_ascii=False)
round_info = bl[-1] if bl else {'round': 0}

# Build match-grouped inplay data (real match reactions)
match_lookup = {m['id']: m for m in matches}
from collections import defaultdict as _dd
ip_by_match = _dd(list)
for ip in inplay:
    ip_by_match[ip.get('matchId','')].append(ip)

compact_inplay_matches = []
for mid in sorted(ip_by_match.keys(), key=lambda x: -len(ip_by_match[x])):
    entries = ip_by_match[mid]
    m = match_lookup.get(mid, {})
    rxs = []
    for e in entries:
        for rx in e.get('reactions', []):
            rxs.append({
                'min': rx.get('minute',0), 'ci': e.get('charId', e.get('charID', 0)),
                'cn': e.get('charName',''),
                'e': e.get('emoji',''), 'mb': e.get('mbti',''),
                'rx': rx.get('reaction',''), 'lb': rx.get('label',''),
                'st': rx.get('status',''), 'sc': rx.get('score',''),
                'th': rx.get('thinking',[])[:3],
                'ob': e.get('originalBet',{}),
            })
    rxs.sort(key=lambda x: x['min'])
    # Extract match events (goals) from score changes
    events = []
    seen_scores = set()
    fs_str = entries[0].get('finalScore','')
    for r in rxs:
        sc = r['sc']
        if sc and sc not in seen_scores:
            seen_scores.add(sc)
            events.append({'min': r['min'], 'sc': sc, 'type': 'goal'})
    # Add kickoff + full-time
    events.insert(0, {'min': 0, 'sc': '0:0', 'type': 'kickoff'})
    events.append({'min': 90, 'sc': fs_str, 'type': 'ft'})
    # Build chat messages from reactions (with richer text from thinking)
    chats = []
    for r in rxs:
        # Use last thinking line as chat message, or label
        msg = r['th'][-1] if r['th'] else r['lb']
        chats.append({
            'min': r['min'], 'ci': r['ci'], 'cn': r['cn'], 'e': r['e'],
            'mb': r['mb'], 'rx': r['rx'], 'lb': r['lb'],
            'msg': msg, 'st': r['st'], 'sc': r['sc'],
            'ob': r['ob'],
        })
    compact_inplay_matches.append({
        'id': mid, 'h': m.get('home','未知'), 'a': m.get('away','未知'),
        'dt': m.get('dateTime',''), 'fs': fs_str,
        'hO': m.get('hadH',0), 'dO': m.get('hadD',0), 'aO': m.get('hadA',0),
        'pc': len(entries), 'rx': rxs, 'ev': events, 'ch': chats,
    })

# Also keep simple compact_inplay for backwards compat (IP var)
compact_inplay = []
for ip in inplay[:60]:
    compact_inplay.append({
        'ci': ip['charId'], 'cn': ip.get('charName',''),
        'e': ip.get('emoji',''), 'mb': ip.get('mbti',''),
        'mid': ip.get('matchId',''),
        'ob': ip.get('originalBet',{}),
        'rx': ip.get('reactions',[]),
        'fs': ip.get('finalScore',''),
    })

# Compact dialogues
compact_dialogues = []
for d in dialogues[:50]:
    compact_dialogues.append({
        'type': d.get('type',''),
        'text': d.get('text',''),
        'mood': d.get('mood',''),
    })

# Build the HTML
html_parts = []

html_parts.append(f'''<!DOCTYPE html>
<html lang="zh-HK">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HKJC AI 賭波聯盟 v4 Ultimate</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:-apple-system,BlinkMacSystemFont,'Microsoft YaHei',sans-serif;background:#0a1128;color:#e0e0e0;min-height:100vh}}
.header{{background:linear-gradient(135deg,#0d1b3e,#1a2252);border-bottom:2px solid #d4af37;padding:20px;text-align:center}}
.header h1{{font-size:2.2em;color:#d4af37;text-shadow:0 2px 10px rgba(212,175,55,0.3)}}
.header .stats{{display:flex;justify-content:center;gap:20px;margin-top:12px;flex-wrap:wrap}}
.header .stat{{background:rgba(212,175,55,0.1);padding:8px 16px;border-radius:20px;border:1px solid rgba(212,175,55,0.3);font-size:0.9em}}
.stat b{{color:#d4af37}}
.tabs{{display:flex;background:#0d1b3e;border-bottom:1px solid #2a3a6a;position:sticky;top:0;z-index:100;overflow-x:auto}}
.tab{{padding:12px 14px;text-align:center;cursor:pointer;border-bottom:3px solid transparent;transition:all 0.2s;font-size:0.85em;white-space:nowrap;flex-shrink:0}}
.tab:hover{{background:rgba(212,175,55,0.1)}}
.tab.active{{border-bottom-color:#d4af37;color:#d4af37;background:rgba(212,175,55,0.05)}}
.panel{{display:none;padding:15px;max-width:1400px;margin:0 auto}}
.panel.active{{display:block}}
.search-bar{{width:100%;padding:12px 18px;background:#1a2252;border:1px solid #2a3a6a;color:#e0e0e0;border-radius:8px;font-size:1em;margin-bottom:15px}}
.search-bar:focus{{outline:none;border-color:#d4af37}}
.filters{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:15px}}
.filter-chip{{padding:6px 14px;border-radius:16px;border:1px solid #2a3a6a;cursor:pointer;font-size:0.85em;transition:all 0.2s}}
.filter-chip:hover,.filter-chip.active{{border-color:#d4af37;color:#d4af37;background:rgba(212,175,55,0.1)}}
.person-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px}}
.person-card{{background:#1a2252;border-radius:10px;border:1px solid #2a3a6a;cursor:pointer;transition:all 0.2s;overflow:hidden}}
.person-card:hover{{border-color:#d4af37;transform:translateY(-2px);box-shadow:0 4px 15px rgba(212,175,55,0.15)}}
.person-card.expanded{{grid-column:1/-1}}
.pc-header{{display:flex;align-items:center;padding:12px 15px;gap:12px}}
.pc-emoji{{font-size:2em}}
.pc-info{{flex:1}}
.pc-name{{font-size:1.1em;font-weight:bold}}
.pc-sub{{font-size:0.8em;color:#888;margin-top:2px}}
.mbti-badge{{display:inline-block;padding:2px 8px;border-radius:10px;font-size:0.75em;font-weight:bold}}
.strat-badge{{display:inline-block;padding:2px 8px;border-radius:10px;font-size:0.7em;background:rgba(212,175,55,0.15);color:#d4af37;margin-left:6px}}
.pc-stats{{display:flex;gap:15px;padding:0 15px 10px;font-size:0.85em}}
.pc-stats span{{color:#aaa}}
.pc-stats b{{color:#d4af37}}
.pc-bets{{border-top:1px solid #2a3a6a;padding:12px 15px;display:none}}
.person-card.expanded .pc-bets{{display:block}}
.bet-item{{background:#0d1b3e;border-radius:8px;padding:12px;margin-bottom:10px;border-left:3px solid #d4af37}}
.bet-item .bi-match{{font-weight:bold;margin-bottom:4px}}
.bi-choice{{display:inline-block;padding:3px 10px;border-radius:12px;font-size:0.85em;font-weight:bold;margin-right:8px}}
.bi-had{{background:rgba(212,175,55,0.2);color:#d4af37}}
.bi-handicap{{background:rgba(74,158,204,0.2);color:#4a9ecc}}
.bi-ou{{background:rgba(76,175,80,0.2);color:#4caf50}}
.bi-cs{{background:rgba(239,83,80,0.2);color:#ef5350}}
.bi-hf{{background:rgba(156,39,176,0.2);color:#ce93d8}}
.bi-amount{{font-size:0.9em;color:#aaa}}
.thinking-box{{background:#0a1128;border-radius:6px;padding:10px;margin-top:8px;font-size:0.85em;line-height:1.6}}
.thinking-box div{{padding:2px 0}}
.match-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:12px}}
.match-card{{background:#1a2252;border-radius:10px;border:1px solid #2a3a6a;overflow:hidden;cursor:pointer;transition:all 0.2s}}
.match-card:hover{{border-color:#d4af37}}
.match-card.expanded{{grid-column:1/-1}}
.mc-header{{padding:12px 15px;display:flex;justify-content:space-between;align-items:center}}
.mc-teams{{font-weight:bold;font-size:1.05em}}
.mc-time{{font-size:0.8em;color:#888}}
.mc-odds{{display:flex;gap:10px;padding:0 15px 8px}}
.mc-odd{{background:#0d1b3e;padding:4px 10px;border-radius:6px;font-size:0.85em;text-align:center}}
.mc-odd small{{display:block;color:#888;font-size:0.8em}}
.mc-count{{background:rgba(212,175,55,0.15);color:#d4af37;padding:4px 12px;border-radius:12px;font-size:0.85em;font-weight:bold}}
.mc-bettors{{border-top:1px solid #2a3a6a;padding:12px 15px;display:none}}
.match-card.expanded .mc-bettors{{display:block}}
.bettor-row{{display:flex;align-items:center;gap:10px;padding:8px;background:#0d1b3e;border-radius:8px;margin-bottom:6px;flex-wrap:wrap}}
.bettor-row .br-name{{font-weight:bold;min-width:80px}}
.bettor-row .br-amount{{color:#d4af37;font-size:0.9em;margin-left:auto}}
.bettor-thinking{{margin-top:6px;padding:8px;background:#0a1128;border-radius:6px;font-size:0.82em;line-height:1.5;display:none}}
.bettor-row.show-think .bettor-thinking{{display:block}}
.bt-bar{{display:flex;height:24px;border-radius:12px;overflow:hidden;margin:10px 0}}
.bt-seg{{display:flex;align-items:center;justify-content:center;font-size:0.7em;font-weight:bold}}
.sort-row{{display:flex;gap:8px;margin-bottom:10px;align-items:center;font-size:0.85em}}
.sort-row select{{background:#1a2252;color:#e0e0e0;border:1px solid #2a3a6a;padding:6px 10px;border-radius:6px}}
/* Leaderboard */
.lb-table{{width:100%;border-collapse:separate;border-spacing:0 4px}}
.lb-table th{{text-align:left;padding:10px 12px;color:#d4af37;font-size:0.8em;border-bottom:1px solid #2a3a6a;cursor:pointer;user-select:none;white-space:nowrap;position:sticky;top:0;background:#0a1128;z-index:10}}
.lb-table th:hover{{color:#fff}}
.lb-table th.sorted{{color:#fff;text-decoration:underline}}
.lb-table td{{padding:8px 12px;font-size:0.85em}}
.lb-table tr.lb-row{{background:#1a2252;transition:all 0.15s}}
.lb-table tr.lb-row:hover{{background:#1f2a60}}
.lb-rank{{font-size:1.2em;font-weight:bold;text-align:center}}
.lb-name-cell{{display:flex;align-items:center;gap:8px}}
.lb-name-cell .lb-emoji{{font-size:1.4em}}
.lb-name-cell .lb-title{{font-size:0.7em;color:#888}}
.wr-bar{{width:60px;height:6px;background:#2a3a6a;border-radius:3px;overflow:hidden;display:inline-block;vertical-align:middle;margin-left:4px}}
.wr-fill{{height:100%;border-radius:3px}}
.pnl-pos{{color:#4caf50;font-weight:bold}}
.pnl-neg{{color:#ef5350;font-weight:bold}}
.pnl-zero{{color:#888}}
.streak-badge{{display:inline-block;padding:2px 6px;border-radius:8px;font-size:0.7em;font-weight:bold}}
.streak-win{{background:rgba(76,175,80,0.2);color:#4caf50}}
.streak-lose{{background:rgba(239,83,80,0.2);color:#ef5350}}
.lb-summary{{display:flex;gap:15px;flex-wrap:wrap;margin-bottom:15px}}
.lb-summary-card{{background:#1a2252;border-radius:10px;padding:12px 16px;border:1px solid #2a3a6a;flex:1;min-width:140px;text-align:center}}
.lb-summary-card .val{{font-size:1.5em;font-weight:bold;color:#d4af37}}
.lb-summary-card .lbl{{font-size:0.75em;color:#888;margin-top:2px}}
.lb-pending-note{{text-align:center;padding:10px;background:rgba(212,175,55,0.08);border-radius:8px;color:#d4af37;font-size:0.85em;margin-bottom:12px;border:1px dashed rgba(212,175,55,0.3)}}
/* Report */
.rpt-headline{{font-size:1.6em;font-weight:bold;text-align:center;padding:20px;color:#d4af37}}
.rpt-section{{background:#1a2252;border-radius:10px;padding:15px;margin-bottom:15px;border:1px solid #2a3a6a}}
.rpt-section h3{{color:#d4af37;margin-bottom:10px;font-size:1.1em}}
.rpt-mvp{{display:flex;align-items:center;gap:15px;padding:10px;background:#0d1b3e;border-radius:10px}}
.rpt-mvp .mvp-emoji{{font-size:3em}}
.rpt-bar{{display:flex;align-items:center;gap:8px;margin:6px 0}}
.rpt-bar-fill{{height:20px;border-radius:4px;display:flex;align-items:center;padding:0 8px;font-size:0.75em;font-weight:bold;min-width:30px}}
/* Social Feed */
.social-feed{{max-width:700px;margin:0 auto}}
.social-msg{{background:#1a2252;border-radius:10px;padding:14px;margin-bottom:10px;border-left:3px solid #d4af37;white-space:pre-line;line-height:1.6;font-size:0.92em}}
.social-msg.win_brag{{border-left-color:#4caf50}}
.social-msg.lose_complaint{{border-left-color:#ef5350}}
.social-msg.rival_taunt{{border-left-color:#ff9800}}
.social-msg.mentor_advice{{border-left-color:#4a9ecc}}
.social-msg.couple{{border-left-color:#e91e63}}
.social-msg.inplay{{border-left-color:#9c27b0}}
.social-mood{{display:inline-block;padding:2px 8px;border-radius:10px;font-size:0.7em;background:rgba(212,175,55,0.1);color:#d4af37;margin-top:6px}}
/* InPlay */
.ip-card{{background:#1a2252;border-radius:12px;margin-bottom:12px;border:1px solid #2a3a6a;overflow:hidden}}
.ip-header{{display:flex;justify-content:space-between;align-items:center;padding:14px 16px 4px}}
.ip-split{{display:flex;gap:0;border-top:1px solid #2a3a6a;min-height:300px}}
.ip-events-panel{{width:280px;min-width:280px;border-right:1px solid #2a3a6a;padding:12px 14px;background:#0d1535}}
.ip-chat-panel{{flex:1;display:flex;flex-direction:column;background:#0a1128}}
.ip-panel-title{{font-size:0.85em;font-weight:bold;color:#d4af37;padding-bottom:10px;border-bottom:1px solid #1a2252;margin-bottom:10px}}
.ip-events-list{{display:flex;flex-direction:column;gap:0}}
.ip-ev-item{{display:flex;align-items:center;gap:10px;padding:8px 0;border-left:3px solid #2a3a6a;padding-left:12px;margin-left:8px;font-size:0.85em}}
.ip-ev-goal{{border-left-color:#d4af37}}
.ip-ev-kickoff{{border-left-color:#4caf50}}
.ip-ev-ft{{border-left-color:#ef5350}}
.ip-ev-min{{display:inline-block;background:#d4af37;color:#0a1128;padding:2px 8px;border-radius:4px;font-weight:bold;font-size:0.8em;min-width:30px;text-align:center}}
.ip-ev-ft .ip-ev-min{{background:#ef5350;color:#fff}}
.ip-ev-kickoff .ip-ev-min{{background:#4caf50;color:#fff}}
.ip-ev-text{{color:#e0e8ff}}
.ip-chat-list{{flex:1;overflow-y:auto;padding:10px 14px;max-height:400px;display:flex;flex-direction:column;gap:6px}}
.ip-chat-msg{{display:flex;gap:8px;align-items:flex-start}}
.ip-chat-time{{min-width:32px;color:#d4af37;font-size:0.75em;font-weight:bold;padding-top:6px;text-align:right}}
.ip-chat-bubble{{flex:1;background:#111d45;border-radius:10px;padding:8px 12px;border:1px solid #1a2a5a}}
.ip-chat-double{{border-left:3px solid #4caf50}}
.ip-chat-chase{{border-left:3px solid #ff9800}}
.ip-chat-panic{{border-left:3px solid #ef5350}}
.ip-chat-cashout{{border-left:3px solid #2196f3}}
.ip-chat-calm{{border-left:3px solid #666}}
.ip-chat-name{{font-size:0.85em;margin-bottom:3px}}
.ip-chat-text{{font-size:0.9em;color:#e0e8ff;line-height:1.4}}
.ip-chat-meta{{font-size:0.72em;color:#666;margin-top:4px}}
.ip-reaction{{display:inline-block;padding:2px 8px;border-radius:8px;font-size:0.75em;font-weight:bold}}
.ip-chase{{background:rgba(255,152,0,0.2);color:#ff9800}}
.ip-panic{{background:rgba(239,83,80,0.2);color:#ef5350}}
.ip-double{{background:rgba(76,175,80,0.2);color:#4caf50}}
.ip-cashout{{background:rgba(74,158,204,0.2);color:#4a9ecc}}
.ip-calm{{background:rgba(158,158,158,0.2);color:#999}}
@media(max-width:768px){{.ip-split{{flex-direction:column}}.ip-events-panel{{width:100%;min-width:100%;border-right:none;border-bottom:1px solid #2a3a6a}}}}
/* Achievements */
.ach-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px}}
.ach-badge{{display:flex;align-items:center;gap:8px;background:#1a2252;padding:8px 12px;border-radius:8px;border:1px solid #2a3a6a}}
.ach-icon{{font-size:1.5em}}
.ach-name{{font-weight:bold;font-size:0.85em}}
.ach-desc{{font-size:0.7em;color:#888}}
/* Charts area */
.chart-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:15px}}
.chart-card{{background:#1a2252;border-radius:10px;padding:15px;border:1px solid #2a3a6a}}
.chart-card h3{{color:#d4af37;margin-bottom:10px;font-size:1em}}
.chart-bar{{display:flex;align-items:center;gap:8px;margin:5px 0;font-size:0.82em}}
.chart-label{{min-width:80px;text-align:right;color:#aaa}}
.chart-fill{{height:18px;border-radius:4px;display:flex;align-items:center;padding:0 6px;font-size:0.7em;font-weight:bold;color:#fff}}
.scatter-dot{{position:absolute;width:8px;height:8px;border-radius:50%;cursor:pointer;transition:transform 0.15s}}
.scatter-dot:hover{{transform:scale(2);z-index:10}}
::-webkit-scrollbar{{width:6px}}
::-webkit-scrollbar-track{{background:#0a1128}}
::-webkit-scrollbar-thumb{{background:#2a3a6a;border-radius:3px}}
</style>
</head>
<body>
<div class="header">
  <h1>🏆 HKJC AI 賭波聯盟 v4 Ultimate</h1>
  <div class="stats">
    <div class="stat">第 <b>{round_info.get('round',0)}</b> 輪</div>
    <div class="stat">👥 <b>{len([c for c in char_bets if c.get('betsCount',0)>0])}</b>/100 參與</div>
    <div class="stat">📝 <b>{len(st.get('activeBets',[]))}</b> 注</div>
    <div class="stat">💰 <b>${sum(b["amount"] for b in st.get("activeBets",[])):,}</b></div>
    <div class="stat">⚽ <b>{len(matches)}</b> 場</div>
    <div class="stat">🏅 <b>{sum(len(v) for v in achievements.values())}</b> 成就</div>
  </div>
</div>

<div class="tabs">
  <div class="tab active" onclick="showTab(0)">🏆 排行榜</div>
  <div class="tab" onclick="showTab(1)">📋 戰報</div>
  <div class="tab" onclick="showTab(2)">💬 社交</div>
  <div class="tab" onclick="showTab(3)">⚡ 即場直播</div>
  <div class="tab" onclick="showTab(4)">👤 每人</div>
  <div class="tab" onclick="showTab(5)">⚽ 賽事</div>
  <div class="tab" onclick="showTab(6)">📊 分析</div>
  <div class="tab" onclick="showTab(7)">🏅 成就</div>
</div>
''')

# Panel 0: Leaderboard
html_parts.append('''
<div class="panel active" id="p0">
  <div class="lb-summary" id="lb-summary"></div>
  <div id="lb-pending-note"></div>
  <input class="search-bar" id="search-lb" placeholder="🔍 搜索角色名稱、MBTI、策略..." oninput="filterLB()">
  <div class="filters" id="lb-filters"></div>
  <div style="overflow-x:auto">
    <table class="lb-table">
      <thead><tr>
        <th onclick="sortLB('rank')">#</th>
        <th onclick="sortLB('name')">角色</th>
        <th onclick="sortLB('mbti')">MBTI</th>
        <th onclick="sortLB('strategy')">策略</th>
        <th onclick="sortLB('total')" class="sorted">總勝率</th>
        <th onclick="sortLB('last10')">近10場</th>
        <th onclick="sortLB('last5')">近5場</th>
        <th onclick="sortLB('pnl')">盈虧</th>
        <th onclick="sortLB('wallet')">資金</th>
        <th onclick="sortLB('bets')">注數</th>
        <th onclick="sortLB('streak')">連勝/敗</th>
        <th>成就</th>
      </tr></thead>
      <tbody id="lb-body"></tbody>
    </table>
  </div>
</div>
''')

# Panel 1: Round Report
html_parts.append('''<div class="panel" id="p1"><div id="report-area"></div></div>''')

# Panel 2: Social Feed
html_parts.append('''<div class="panel" id="p2"><div class="social-feed" id="social-feed"></div></div>''')

# Panel 3: In-Play (real match reactions)
html_parts.append('''<div class="panel" id="p3">
  <div class="lb-summary" id="ip-summary"></div>
  <div id="inplay-area"></div>
</div>''')

# Panel 4: People
html_parts.append('''
<div class="panel" id="p4">
  <input class="search-bar" id="search-people" placeholder="🔍 搜索角色名稱、MBTI、策略..." oninput="filterPeople()">
  <div class="sort-row">
    <span>排序:</span>
    <select id="sort-people" onchange="filterPeople()">
      <option value="bets">投注數 ↓</option>
      <option value="wagered">投注額 ↓</option>
      <option value="wallet">資金 ↓</option>
      <option value="name">名稱</option>
    </select>
  </div>
  <div class="person-grid" id="person-grid"></div>
</div>
''')

# Panel 5: Matches
html_parts.append('''
<div class="panel" id="p5">
  <input class="search-bar" id="search-matches" placeholder="🔍 搜索球隊名稱..." oninput="filterMatches()">
  <div class="sort-row">
    <span>排序:</span>
    <select id="sort-matches" onchange="filterMatches()">
      <option value="popular">最多人買 ↓</option>
      <option value="time">開賽時間</option>
    </select>
  </div>
  <div class="match-grid" id="match-grid"></div>
</div>
''')

# Panel 6: Analysis
html_parts.append('''<div class="panel" id="p6"><div id="analysis-area"></div></div>''')

# Panel 7: Achievements
html_parts.append('''<div class="panel" id="p7"><div id="achievements-area"></div></div>''')

# Script with all data
html_parts.append(f'''
<script>
const C={j(compact_chars)};
const CB={j(compact_cb)};
const MB={j(dict(match_bets))};
const MA={j(compact_matches)};
const LB={j(leaderboard)};
const RPT={j(report)};
const DLG={j(compact_dialogues)};
const IP={j(compact_inplay)};
const IPM={j(compact_inplay_matches)};
const ANA={j(analysis)};
const charMap=Object.fromEntries(C.map(c=>[c.id,c]));

function showTab(i){{
  document.querySelectorAll('.tab').forEach((el,idx)=>el.classList.toggle('active',idx===i));
  document.querySelectorAll('.panel').forEach((el,idx)=>el.classList.toggle('active',idx===i));
}}

function btClass(bt){{
  if(bt==='主客和')return'bi-had';if(bt==='讓球')return'bi-handicap';
  if(bt==='入球大細')return'bi-ou';if(bt==='波膽')return'bi-cs';return'bi-hf';
}}

function renderThinking(th){{
  return(th||[]).map(t=>'<div>'+t+'</div>').join('');
}}

function wrColor(wr){{
  if(wr<0)return'#555';if(wr>=70)return'#4caf50';if(wr>=50)return'#d4af37';if(wr>=30)return'#ff9800';return'#ef5350';
}}
function wrDisplay(wr){{
  if(wr<0)return'<span style="color:#555">—</span>';
  return`<span style="color:${{wrColor(wr)}};font-weight:bold">${{wr}}%</span><div class="wr-bar"><div class="wr-fill" style="width:${{wr}}%;background:${{wrColor(wr)}}"></div></div>`;
}}
function pnlDisplay(pnl){{
  if(pnl>0)return`<span class="pnl-pos">+$${{pnl.toLocaleString()}}</span>`;
  if(pnl<0)return`<span class="pnl-neg">-$${{Math.abs(pnl).toLocaleString()}}</span>`;
  return'<span class="pnl-zero">$0</span>';
}}
function streakDisplay(ws,ls){{
  if(ws>0)return`<span class="streak-badge streak-win">🔥${{ws}}</span>`;
  if(ls>0)return`<span class="streak-badge streak-lose">❄️${{ls}}</span>`;
  return'—';
}}
function rankMedal(i){{
  if(i===0)return'🥇';if(i===1)return'🥈';if(i===2)return'🥉';return i+1;
}}
function achBadges(ach){{
  return(ach||[]).slice(0,3).map(a=>`<span title="${{a.name}}: ${{a.desc}}" style="cursor:help">${{a.icon}}</span>`).join('');
}}

// ============ LEADERBOARD ============
let lbSort='total',lbDir=-1,lbMbtiFilter='';
function sortLB(col){{
  if(lbSort===col)lbDir*=-1;else{{lbSort=col;lbDir=-1;}}
  document.querySelectorAll('.lb-table th').forEach(th=>th.classList.remove('sorted'));
  event.target.classList.add('sorted');
  filterLB();
}}
function lbSortFn(a,b){{
  let va,vb;
  switch(lbSort){{
    case'rank':case'total':va=a.wr;vb=b.wr;break;
    case'last10':va=a.w10;vb=b.w10;break;
    case'last5':va=a.w5;vb=b.w5;break;
    case'pnl':va=a.pnl;vb=b.pnl;break;
    case'wallet':va=a.w;vb=b.w;break;
    case'bets':va=a.tp;vb=b.tp;break;
    case'streak':va=a.ws-a.ls;vb=b.ws-b.ls;break;
    case'name':return lbDir*a.n.localeCompare(b.n);
    case'mbti':return lbDir*a.mb.localeCompare(b.mb);
    case'strategy':return lbDir*a.sl.localeCompare(b.sl);
    default:va=a.wr;vb=b.wr;
  }}
  if(va===-1&&vb===-1)return 0;if(va===-1)return 1;if(vb===-1)return -1;
  return lbDir*(va-vb);
}}
function renderLB(list){{
  const tb=list.reduce((s,x)=>s+x.tp,0),tw=list.reduce((s,x)=>s+x.tw,0),
    tp=list.reduce((s,x)=>s+x.pnl,0),pb=list.reduce((s,x)=>s+x.ac,0),
    pc=list.filter(x=>x.pnl>0).length;
  document.getElementById('lb-summary').innerHTML=`
    <div class="lb-summary-card"><div class="val">${{list.length}}</div><div class="lbl">參賽</div></div>
    <div class="lb-summary-card"><div class="val">${{tb}}</div><div class="lbl">已結算</div></div>
    <div class="lb-summary-card"><div class="val">${{tb>0?Math.round(tw/tb*100):0}}%</div><div class="lbl">平均勝率</div></div>
    <div class="lb-summary-card"><div class="val" style="color:${{tp>=0?'#4caf50':'#ef5350'}}">${{tp>=0?'+':''}}$${{tp.toLocaleString()}}</div><div class="lbl">總盈虧</div></div>
    <div class="lb-summary-card"><div class="val">${{pb}}</div><div class="lbl">待結算</div></div>
    <div class="lb-summary-card"><div class="val">${{pc}}</div><div class="lbl">盈利人數</div></div>`;
  if(pb>0&&tb===0){{
    document.getElementById('lb-pending-note').innerHTML='⏳ 共 <b>'+pb+'</b> 注待結算 — 比賽結束後自動更新！';
    document.getElementById('lb-pending-note').className='lb-pending-note';
  }}else{{document.getElementById('lb-pending-note').innerHTML='';document.getElementById('lb-pending-note').className='';}}
  list.sort(lbSortFn);
  document.getElementById('lb-body').innerHTML=list.map((p,i)=>`<tr class="lb-row">
    <td class="lb-rank">${{rankMedal(i)}}</td>
    <td><div class="lb-name-cell"><span class="lb-emoji">${{p.e}}</span><div><span class="char-link" onclick="event.stopPropagation();goToPerson(${{p.id}})" style="font-weight:bold">${{p.n}}</span><div class="lb-title">${{p.t}}</div></div></div></td>
    <td><span class="mbti-badge" style="background:${{p.mc}}22;color:${{p.mc}}">${{p.mb}}</span></td>
    <td><span class="strat-badge">${{p.sl}}</span></td>
    <td>${{wrDisplay(p.wr)}}</td><td>${{wrDisplay(p.w10)}}</td><td>${{wrDisplay(p.w5)}}</td>
    <td>${{pnlDisplay(p.pnl)}}</td>
    <td style="color:#d4af37">$${{p.w.toLocaleString()}}</td>
    <td>${{p.tp>0?p.tw+'/'+p.tp:(p.ac>0?'<span style="color:#888">'+p.ac+'待結</span>':'0')}}</td>
    <td>${{streakDisplay(p.ws,p.ls)}}</td>
    <td>${{achBadges(p.ach)}}</td>
  </tr>`).join('');
}}
function filterLB(){{
  const q=document.getElementById('search-lb').value.toLowerCase();
  let list=[...LB];
  if(q)list=list.filter(p=>p.n.toLowerCase().includes(q)||p.mb.toLowerCase().includes(q)||p.sl.includes(q));
  if(lbMbtiFilter)list=list.filter(p=>p.mb===lbMbtiFilter);
  renderLB(list);
}}

// ============ REPORT ============
function renderReport(){{
  const el=document.getElementById('report-area');
  let h=`<div class="rpt-headline">${{RPT.headline||'等待數據'}}</div>`;
  if(RPT.totalSettled)h+=`<div style="text-align:center;color:#888;margin-bottom:20px">結算${{RPT.totalSettled}}注 | ${{RPT.wins}}勝${{RPT.losses}}負 | ${{RPT.totalPnL>=0?'+':''}}$${{RPT.totalPnL?.toLocaleString()||0}}</div>`;
  (RPT.sections||[]).forEach(s=>{{
    h+=`<div class="rpt-section"><h3>${{s.title}}</h3>`;
    if(s.type==='mvp'||s.type==='worst'){{
      h+=`<div class="rpt-mvp"><div class="mvp-emoji">${{s.emoji}}</div><div><span class="char-link" onclick="goToPerson(${{s.charId||0}})">${{s.name}}</span> <span class="mbti-badge" style="background:rgba(212,175,55,0.2);color:#d4af37">${{s.mbti||''}}</span> <span class="strat-badge">${{s.strategy||''}}</span><div style="margin-top:6px;font-size:1.2em">${{pnlDisplay(s.pnl)}} (${{s.record}})</div></div></div>`;
    }}
    if(s.type==='upset'&&s.charName){{
      h+=`<div style="padding:10px;background:#0d1b3e;border-radius:8px"><span class="char-link" onclick="goToPerson(${{s.charId||0}})">${{s.charName}}</span> 買 ${{s.choice}} @${{s.odds}} → 結果 ${{s.result}} ${{pnlDisplay(s.pnl)}}</div>`;
    }}
    if(s.type==='betTypes'){{
      (s.data||[]).forEach(d=>{{
        const w=Math.max(d.winRate*2,10);
        const c=d.pnl>=0?'#4caf50':'#ef5350';
        h+=`<div class="rpt-bar"><span style="min-width:70px">${{d.betType}}</span><div class="rpt-bar-fill" style="width:${{w}}px;background:${{c}}">${{d.winRate}}%</div><span style="color:#888;font-size:0.8em">${{d.wins}}/${{d.total}} ${{pnlDisplay(d.pnl)}}</span></div>`;
      }});
    }}
    if(s.type==='strategies'){{
      (s.data||[]).slice(0,10).forEach(d=>{{
        const w=Math.max(d.winRate*2,10);
        const c=d.pnl>=0?'#4caf50':'#ef5350';
        h+=`<div class="rpt-bar"><span style="min-width:80px;font-size:0.85em">${{d.strategy}}</span><div class="rpt-bar-fill" style="width:${{w}}px;background:${{c}}">${{d.winRate}}%</div><span style="color:#888;font-size:0.8em">${{d.chars}}人 ${{pnlDisplay(d.pnl)}}</span></div>`;
      }});
    }}
    if(s.type==='mbti'){{
      (s.data||[]).forEach(d=>{{
        const w=Math.max(d.winRate*2,10);
        const c=d.pnl>=0?'#4caf50':'#ef5350';
        h+=`<div class="rpt-bar"><span style="min-width:50px">${{d.mbti}}</span><div class="rpt-bar-fill" style="width:${{w}}px;background:${{c}}">${{d.winRate}}%</div><span style="color:#888;font-size:0.8em">${{pnlDisplay(d.pnl)}}</span></div>`;
      }});
    }}
    if(s.type==='top10'){{
      (s.data||[]).forEach((d,i)=>{{
        h+=`<div style="display:flex;align-items:center;gap:10px;padding:6px 0"><b>${{rankMedal(i)}}</b> ${{d.emoji}} <span class="char-link" onclick="goToPerson(${{d.charId||0}})">${{d.name}}</span> <span style="margin-left:auto">${{pnlDisplay(d.pnl)}} (${{d.record}})</span></div>`;
      }});
    }}
    h+='</div>';
  }});
  el.innerHTML=h;
}}

// ============ SOCIAL FEED ============
function renderSocial(){{
  document.getElementById('social-feed').innerHTML=DLG.map(d=>
    `<div class="social-msg ${{d.type}}"><div>${{d.text}}</div>${{d.mood?`<div class="social-mood">${{d.mood}}</div>`:''}}</div>`
  ).join('')||'<div style="text-align:center;color:#888;padding:40px">等待社交動態...</div>';
}}

// ============ IN-PLAY (REAL MATCH REACTIONS) ============
function rxEmoji(rx){{
  const map={{double:'💰',chase:'🔥',panic:'😱',cashout:'🏦',calm:'😌'}};
  return map[rx]||'💬';
}}
function rxColor(rx){{
  const map={{double:'#4caf50',chase:'#ff9800',panic:'#ef5350',cashout:'#2196f3',calm:'#888'}};
  return map[rx]||'#888';
}}
function renderInPlay(){{
  const el=document.getElementById('inplay-area');
  const sm=document.getElementById('ip-summary');
  if(!IPM||!IPM.length){{el.innerHTML='<div style="text-align:center;color:#888;padding:40px">等待即時比賽數據...</div>';return;}}
  const totalRx=IPM.reduce((s,m)=>s+(m.ch||m.rx).length,0);
  const totalPc=IPM.reduce((s,m)=>s+m.pc,0);
  sm.innerHTML=`
    <div class="lb-summary-card"><div class="val">${{IPM.length}}</div><div class="lbl">場比賽</div></div>
    <div class="lb-summary-card"><div class="val">${{totalPc}}</div><div class="lbl">參與角色</div></div>
    <div class="lb-summary-card"><div class="val">${{totalRx}}</div><div class="lbl">即時反應</div></div>
    <div class="lb-summary-card"><div class="val">${{IPM.reduce((s,m)=>s+(m.ch||m.rx).filter(r=>r.rx==='double').length,0)}}</div><div class="lbl">加注</div></div>
    <div class="lb-summary-card"><div class="val">${{IPM.reduce((s,m)=>s+(m.ch||m.rx).filter(r=>r.rx==='panic').length,0)}}</div><div class="lbl">恐慌</div></div>
    <div class="lb-summary-card"><div class="val">${{IPM.reduce((s,m)=>s+(m.ch||m.rx).filter(r=>r.rx==='cashout').length,0)}}</div><div class="lbl">止蝕</div></div>`;
  el.innerHTML=IPM.map((m,mi)=>{{
    // Left: match events timeline
    const evs=m.ev||[];
    const evHtml=evs.map(ev=>{{
      if(ev.type==='kickoff')return`<div class="ip-ev-item ip-ev-kickoff"><span class="ip-ev-min">⏱</span><span class="ip-ev-text">🏟️ 開波 <b>0:0</b></span></div>`;
      if(ev.type==='ft')return`<div class="ip-ev-item ip-ev-ft"><span class="ip-ev-min">FT</span><span class="ip-ev-text">🏁 完場 <b style="color:#d4af37;font-size:1.1em">${{ev.sc}}</b></span></div>`;
      return`<div class="ip-ev-item ip-ev-goal"><span class="ip-ev-min">${{ev.min}}'</span><span class="ip-ev-text">⚽ 入球！比分 <b style="color:#d4af37">${{ev.sc}}</b></span></div>`;
    }}).join('');
    // Right: chatroom
    const chats=m.ch||m.rx||[];
    const chatHtml=chats.map(c=>{{
      const stIcon=c.st==='winning'?'📈':'📉';
      const msgText=c.msg||c.lb||c.th?.[c.th.length-1]||c.lb;
      return`<div class="ip-chat-msg">
        <div class="ip-chat-time">${{c.min}}'</div>
        <div class="ip-chat-bubble ip-chat-${{c.rx}}">
          <div class="ip-chat-name"><span class="char-link" onclick="event.stopPropagation();goToPerson(${{c.ci||0}})">${{c.e}} ${{c.cn}}</span> <span class="mbti-badge" style="background:${{rxColor(c.rx)}}22;color:${{rxColor(c.rx)}};font-size:0.7em">${{c.lb}}</span></div>
          <div class="ip-chat-text">${{msgText}}</div>
          <div class="ip-chat-meta">${{stIcon}} ${{c.sc}} · ${{c.ob?.betType||''}} ${{c.ob?.choice||''}} @${{c.ob?.odds||''}} $$${{(c.ob?.amount||0).toLocaleString()}}</div>
        </div>
      </div>`;
    }}).join('');
    return`<div class="ip-card">
      <div class="ip-header" style="cursor:pointer" onclick="const d=this.parentNode.querySelector('.ip-split');d.style.display=d.style.display==='none'?'flex':'none'">
        <div><b style="font-size:1.1em">${{m.h}} vs ${{m.a}}</b> <span style="color:#d4af37;font-size:1.2em;font-weight:bold;margin-left:10px">${{m.fs}}</span></div>
        <div style="display:flex;gap:8px"><span style="background:#0d1b3e;padding:3px 8px;border-radius:6px;font-size:0.8em">${{m.id}}</span><span style="background:#0d1b3e;padding:3px 8px;border-radius:6px;font-size:0.8em">${{m.pc}}人</span><span style="background:#0d1b3e;padding:3px 8px;border-radius:6px;font-size:0.8em">${{chats.length}}反應</span></div>
      </div>
      <div style="padding:0 14px 6px;font-size:0.82em;color:#888">主${{m.hO}} 和${{m.dO}} 客${{m.aO}} | ${{m.dt}} <span style="float:right;cursor:pointer;color:#d4af37" onclick="const d=this.closest('.ip-card').querySelector('.ip-split');d.style.display=d.style.display==='none'?'flex':'none'">▼ 展開</span></div>
      <div class="ip-split" style="display:${{mi===0?'flex':'none'}}">
        <div class="ip-events-panel">
          <div class="ip-panel-title">⚽ 賽事動態</div>
          <div class="ip-events-list">${{evHtml}}</div>
        </div>
        <div class="ip-chat-panel">
          <div class="ip-panel-title">💬 即時聊天室 <span style="color:#888;font-size:0.8em">(${{chats.length}})</span></div>
          <div class="ip-chat-list">${{chatHtml||'<div style="color:#888;text-align:center;padding:20px">暫無訊息</div>'}}</div>
        </div>
      </div>
    </div>`;
  }}).join('');
}}

// ============ PEOPLE ============
function renderPeople(list){{
  document.getElementById('person-grid').innerHTML=list.map(cb=>{{
    const c=charMap[cb.charId];if(!c)return'';
    const achHtml=(c.ach||[]).map(a=>`<span title="${{a.desc}}" style="cursor:help">${{a.icon}}</span>`).join(' ');
    const lb=LB.find(p=>p.id===cb.charId);
    const pnl=lb?lb.pnl:0;
    const wr=lb?lb.wr:-1;
    const pnlC=pnl>=0?'#4caf50':'#ef5350';
    return`<div class="person-card" onclick="goToPerson(${{cb.charId}})" style="cursor:pointer">
      <div class="pc-header">
        <div class="pc-emoji">${{c.e}}</div>
        <div class="pc-info">
          <div class="pc-name"><span class="char-link">${{c.n}}</span> <span style="font-size:0.8em;color:#888">${{c.age||''}}歲 ${{c.t||''}}</span></div>
          <div class="pc-sub"><span class="mbti-badge" style="background:${{c.mc}}22;color:${{c.mc}}">${{c.mb}} ${{c.ml||''}}</span><span class="strat-badge">${{cb.sl||c.sl}}</span></div>
        </div>
        <div style="text-align:right"><div style="color:#d4af37;font-weight:bold">${{cb.n}}注</div><div style="font-size:0.8em;color:#888">$${{(cb.tw||0).toLocaleString()}}</div></div>
      </div>
      <div class="pc-stats">
        <span>💰<b>$${{c.w.toLocaleString()}}</b></span>
        <span style="color:${{pnlC}}">盈虧<b>${{pnl>=0?'+':''}}$${{pnl.toLocaleString()}}</b></span>
        <span>勝率<b>${{wr>=0?wr+'%':'—'}}</b></span>
        ${{achHtml?'<span>'+achHtml+'</span>':''}}
      </div>
      <div class="pc-bets">
        ${{cb.sm?'<div style="padding:6px;color:#bbb;font-size:0.85em">'+cb.sm+'</div>':'<div style="color:#888;padding:10px">今輪無投注</div>'}}
        ${{(cb.ev||[]).map(e=>'<div style="padding:3px 6px;font-size:0.8em;color:#aaa">'+e+'</div>').join('')}}
        ${{cb.md&&cb.md!=='平常心'?'<div style="padding:3px 6px;font-size:0.8em;color:#888">🎭 '+cb.md+'</div>':''}}
      </div>
    </div>`;
  }}).join('');
}}
function filterPeople(){{
  const q=document.getElementById('search-people').value.toLowerCase();
  const sort=document.getElementById('sort-people').value;
  let list=[...CB];
  if(q)list=list.filter(cb=>{{const c=charMap[cb.charId];return c&&(c.n.toLowerCase().includes(q)||c.mb.toLowerCase().includes(q)||(c.sl||'').includes(q));}});
  if(sort==='bets')list.sort((a,b)=>(b.n||0)-(a.n||0));
  else if(sort==='wagered')list.sort((a,b)=>(b.tw||0)-(a.tw||0));
  else if(sort==='wallet')list.sort((a,b)=>(charMap[b.charId]?.w||0)-(charMap[a.charId]?.w||0));
  else list.sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  renderPeople(list);
}}

// ============ MATCHES ============
function renderMatches(list){{
  document.getElementById('match-grid').innerHTML=list.map(m=>{{
    const bets=MB[m.id]||[];
    const choiceStr=Object.entries(bets.reduce((a,b)=>{{a[b.cl]=(a[b.cl]||0)+1;return a;}},{{}})).sort((a,b)=>b[1]-a[1]).map(([k,v])=>v+'人 '+k).join(' | ');
    return`<div class="match-card" onclick="this.classList.toggle('expanded')">
      <div class="mc-header"><div><div class="mc-teams">${{m.h}} vs ${{m.a}}</div><div class="mc-time">${{m.dt}} | ${{m.id}}</div></div><div class="mc-count">${{m.bc}}人</div></div>
      <div class="mc-odds"><div class="mc-odd"><small>主</small>${{m.hO}}</div><div class="mc-odd"><small>和</small>${{m.dO}}</div><div class="mc-odd"><small>客</small>${{m.aO}}</div></div>
      ${{choiceStr?'<div style="padding:0 15px 8px;font-size:0.85em;color:#aaa">'+choiceStr+'</div>':''}}
      <div class="mc-bettors">${{bets.map(b=>`
        <div class="bettor-row" onclick="event.stopPropagation();this.classList.toggle('show-think')">
          <span class="br-name char-link" onclick="event.stopPropagation();goToPerson(${{b.ci}})">${{charMap[b.ci]?.e||''}} ${{b.cn}}</span>
          <span class="bi-choice ${{btClass(b.bt)}}">${{b.bt}}</span>
          <span>${{b.cl}} @${{b.o}}</span>
          <span class="br-amount">$${{b.a.toLocaleString()}}</span>
          <div class="bettor-thinking">${{renderThinking(b.th)}}</div>
        </div>`).join('')||'<div style="color:#888">無人投注</div>'}}</div>
    </div>`;
  }}).join('');
}}
function filterMatches(){{
  const q=document.getElementById('search-matches').value.toLowerCase();
  const sort=document.getElementById('sort-matches').value;
  let list=[...MA];
  if(q)list=list.filter(m=>m.h.toLowerCase().includes(q)||m.a.toLowerCase().includes(q));
  if(sort==='popular')list.sort((a,b)=>b.bc-a.bc);
  else list.sort((a,b)=>a.dt.localeCompare(b.dt));
  renderMatches(list);
}}

// ============ ANALYSIS ============
function renderAnalysis(){{
  const el=document.getElementById('analysis-area');
  let h='';

  // Top & Bottom performers
  h+='<div class="chart-grid" style="margin-bottom:15px">';
  h+='<div class="chart-card"><h3>🏆 盈利最高 Top 5</h3>';
  (ANA.top5||[]).forEach((p,i)=>{{
    const rc=p.pnl>=0?'#4caf50':'#ef5350';
    h+=`<div style="display:flex;align-items:center;gap:8px;padding:8px;background:#0d1b3e;border-radius:6px;margin-bottom:4px;border-left:3px solid ${{rc}}">
      <span style="font-size:0.9em;color:#d4af37;min-width:18px">#${{i+1}}</span>
      <span style="font-size:1.2em">${{p.emoji}}</span>
      <div style="flex:1"><span class="char-link" onclick="goToPerson(${{p.id||0}})">${{p.name}}</span><div style="font-size:0.75em;color:#888">${{p.mbti}} · ${{p.strategy}} · ${{p.bets}}注</div></div>
      <div style="text-align:right"><div style="color:${{rc}};font-weight:bold">${{p.pnl>=0?'+':''}}$${{p.pnl.toLocaleString()}}</div><div style="font-size:0.75em;color:#888">ROI ${{p.roi>=0?'+':''}}${{p.roi}}%</div></div>
    </div>`;
  }});
  h+='</div>';
  h+='<div class="chart-card"><h3>📉 虧損最高 Bottom 5</h3>';
  (ANA.bottom5||[]).forEach((p,i)=>{{
    const rc=p.pnl>=0?'#4caf50':'#ef5350';
    h+=`<div style="display:flex;align-items:center;gap:8px;padding:8px;background:#0d1b3e;border-radius:6px;margin-bottom:4px;border-left:3px solid ${{rc}}">
      <span style="font-size:1.2em">${{p.emoji}}</span>
      <div style="flex:1"><span class="char-link" onclick="goToPerson(${{p.id||0}})">${{p.name}}</span><div style="font-size:0.75em;color:#888">${{p.mbti}} · ${{p.strategy}} · ${{p.bets}}注</div></div>
      <div style="text-align:right"><div style="color:${{rc}};font-weight:bold">${{p.pnl>=0?'+':''}}$${{p.pnl.toLocaleString()}}</div><div style="font-size:0.75em;color:#888">勝率${{p.winRate}}%</div></div>
    </div>`;
  }});
  h+='</div></div>';

  h+='<div class="chart-grid">';

  // Strategy chart (enhanced)
  h+='<div class="chart-card"><h3>🎯 策略勝率對比</h3>';
  (ANA.strategies||[]).forEach(s=>{{
    const c=s.totalPnL>=0?'#4caf50':'#ef5350';
    const roiC=s.avgROI>=0?'#4caf50':'#ef5350';
    h+=`<div class="chart-bar"><span class="chart-label">${{s.name}}</span><div class="chart-fill" style="width:${{Math.max(s.winRate*1.5,8)}}px;background:${{c}}">${{s.winRate}}%</div><span style="color:#888;font-size:0.72em">${{s.charCount}}人 ${{s.totalBets}}注 <span style="color:${{c}}">${{pnlDisplay(s.totalPnL)}}</span> <span style="color:${{roiC}}">ROI${{s.avgROI>=0?'+':''}}${{s.avgROI||0}}%</span></span></div>`;
  }});
  h+='</div>';

  // MBTI chart (enhanced)
  h+='<div class="chart-card"><h3>🧠 MBTI勝率對比</h3>';
  (ANA.mbtiComparison||[]).forEach(m=>{{
    const c=m.totalPnL>=0?'#4caf50':'#ef5350';
    h+=`<div class="chart-bar"><span class="chart-label">${{m.mbti}}</span><div class="chart-fill" style="width:${{Math.max(m.winRate*1.5,8)}}px;background:${{c}}">${{m.winRate}}%</div><span style="color:#888;font-size:0.72em">${{m.charCount}}人 ${{m.totalBets}}注 <span style="color:${{c}}">${{pnlDisplay(m.totalPnL)}}</span> 均${{pnlDisplay(m.avgPnL)}}</span></div>`;
  }});
  h+='</div>';

  // Bet type analysis (NEW)
  h+='<div class="chart-card"><h3>🎲 盤口類型分析</h3>';
  (ANA.betTypes||[]).forEach(bt=>{{
    const c=bt.pnl>=0?'#4caf50':'#ef5350';
    const pct=bt.total>0?Math.round(bt.total/(ANA.betTypes||[]).reduce((s,b)=>s+b.total,0)*100):0;
    h+=`<div style="background:#0d1b3e;border-radius:6px;padding:10px;margin-bottom:6px;border-left:3px solid ${{c}}">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <b>${{bt.name}}</b>
        <span style="color:${{c}};font-weight:bold">${{pnlDisplay(bt.pnl)}}</span>
      </div>
      <div style="font-size:0.8em;color:#888;margin-top:4px">
        ${{bt.total}}注(${{pct}}%) · 勝率${{bt.winRate}}% · 平均注碼$${{(bt.avgAmount||0).toLocaleString()}}
      </div>
      <div style="background:#1a2252;border-radius:3px;height:6px;margin-top:4px"><div style="background:${{c}};height:100%;border-radius:3px;width:${{bt.winRate}}%"></div></div>
    </div>`;
  }});
  h+='</div>';

  // Risk vs Return scatter (text-based)
  h+='<div class="chart-card" style="grid-column:1/-1"><h3>📈 風險 vs 回報 散佈圖 <span style="font-size:0.6em;color:#888">(${{(ANA.riskReturn||[]).length}}人)</span></h3>';
  h+='<div style="position:relative;height:300px;background:#0d1b3e;border-radius:8px;overflow:hidden">';
  h+='<div style="position:absolute;left:0;top:50%;width:100%;border-top:1px dashed #2a3a6a"></div>';
  h+='<div style="position:absolute;left:50%;top:0;height:100%;border-left:1px dashed #2a3a6a"></div>';
  h+='<div style="position:absolute;left:5px;top:5px;font-size:0.7em;color:#888">高回報</div>';
  h+='<div style="position:absolute;left:5px;bottom:5px;font-size:0.7em;color:#888">低回報</div>';
  h+='<div style="position:absolute;right:5px;bottom:5px;font-size:0.7em;color:#888">高風險→</div>';
  (ANA.riskReturn||[]).forEach(d=>{{
    const x=d.risk*90+5;
    const maxR=Math.max(...(ANA.riskReturn||[]).map(dd=>Math.abs(dd['return'])),1);
    const y=50-d['return']/maxR*45;
    const c=d['return']>=0?'#4caf50':'#ef5350';
    h+=`<div class="scatter-dot" style="left:${{x}}%;top:${{y}}%;background:${{c}}" title="${{d.name}} (${{d.mbti}}) ${{d.strategy}}\\n風險:${{d.risk}} 每注回報:$${{d['return']}} ${{d.bets}}注"></div>`;
  }});
  h+='</div></div>';
  h+='</div>';
  el.innerHTML=h;
}}

// ============ ACHIEVEMENTS ============
function renderAchievements(){{
  const el=document.getElementById('achievements-area');
  // Count achievement frequency
  const achCounts={{}};
  C.forEach(c=>{{(c.ach||[]).forEach(a=>{{achCounts[a.name]=(achCounts[a.name]||0)+1;}});}});
  const totalBadges=C.reduce((s,c)=>s+(c.ach||[]).length,0);

  let h=`<div class="lb-summary" style="margin-bottom:20px">
    <div class="lb-summary-card"><div class="val">${{totalBadges}}</div><div class="lbl">總徽章</div></div>
    <div class="lb-summary-card"><div class="val">${{Object.keys(achCounts).length}}</div><div class="lbl">徽章類型</div></div>
    <div class="lb-summary-card"><div class="val">${{C.filter(c=>(c.ach||[]).length>0).length}}</div><div class="lbl">獲獎人數</div></div>
  </div>`;

  // Badge leaderboard
  h+='<h3 style="color:#d4af37;margin-bottom:10px">🏅 徽章統計</h3><div class="ach-grid" style="margin-bottom:20px">';
  Object.entries(achCounts).sort((a,b)=>b[1]-a[1]).forEach(([name,cnt])=>{{
    const sample=C.find(c=>(c.ach||[]).find(a=>a.name===name));
    const ach=sample?(sample.ach||[]).find(a=>a.name===name):null;
    h+=`<div class="ach-badge"><div class="ach-icon">${{ach?.icon||'🏅'}}</div><div><div class="ach-name">${{name}} x${{cnt}}</div><div class="ach-desc">${{ach?.desc||''}}</div></div></div>`;
  }});
  h+='</div>';

  // Per-character achievements
  h+='<h3 style="color:#d4af37;margin-bottom:10px">👤 個人成就</h3>';
  const withAch=C.filter(c=>(c.ach||[]).length>0).sort((a,b)=>(b.ach||[]).length-(a.ach||[]).length);
  h+=withAch.map(c=>{{
    const badges=(c.ach||[]).map(a=>`<div class="ach-badge"><div class="ach-icon">${{a.icon}}</div><div><div class="ach-name">${{a.name}}</div><div class="ach-desc">${{a.desc}}</div></div></div>`).join('');
    return`<div style="background:#1a2252;border-radius:10px;padding:12px;margin-bottom:8px;border:1px solid #2a3a6a">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px"><span style="font-size:1.4em">${{c.e}}</span><span class="char-link" onclick="goToPerson(${{c.id}})">${{c.n}}</span><span class="mbti-badge" style="background:${{c.mc}}22;color:${{c.mc}}">${{c.mb}}</span><span style="color:#d4af37;margin-left:auto">${{(c.ach||[]).length}}個徽章</span></div>
      <div class="ach-grid">${{badges}}</div>
    </div>`;
  }}).join('');

  el.innerHTML=h;
}}

// ============ INIT ============
const mbtiTypes=[...new Set(LB.map(p=>p.mb))].sort();
document.getElementById('lb-filters').innerHTML=mbtiTypes.map(mb=>{{
  const color=LB.find(p=>p.mb===mb)?.mc||'#999';
  return`<div class="filter-chip" style="color:${{color}};border-color:${{color}}44" onclick="lbMbtiFilter=lbMbtiFilter==='${{mb}}'?'':'${{mb}}';this.parentNode.querySelectorAll('.filter-chip').forEach(e=>e.classList.remove('active'));if(lbMbtiFilter)this.classList.add('active');filterLB()">${{mb}}</div>`;
}}).join('');

filterLB();renderReport();renderSocial();renderInPlay();filterPeople();filterMatches();renderAnalysis();renderAchievements();
</script>
</body></html>''')

html = '\n'.join(html_parts)
with open(f'{BASE}/dashboard.html', 'w') as f:
    f.write(html)
print(f"Dashboard generated: {len(html):,} bytes")
