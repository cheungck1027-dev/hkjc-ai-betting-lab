#!/usr/bin/env python3
"""
Scrape football news from tipsme.hk and update news-data.json
This script is meant to be run via Claude in Chrome (browser scraping)
since tipsme.hk is blocked by the VM network proxy.

For manual update:
1. Open https://tipsme.hk/zh-TW/news in Chrome
2. Run the JS extraction from build process
3. Update news-data.json with new headlines + team analysis

For automated update within Claude sessions:
- The scheduled task can use Claude in Chrome MCP to scrape
- Or the user can provide updated news data manually
"""

import json, os
from datetime import datetime

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def analyze_headline(headline):
    """Extract team names and sentiment from a headline"""
    teams = {}

    # Team name mapping (HKJC Chinese names)
    team_map = {
        '利物浦': '利物浦', '熱刺': '熱刺', '曼聯': '曼聯', '曼城': '曼城',
        '阿仙奴': '阿仙奴', '車路士': '車路士', '紐卡素': '紐卡素',
        '阿士東維拉': '阿士東維拉', '愛華頓': '愛華頓', '韋斯咸': '韋斯咸',
        '狼隊': '狼隊', '賓福特': '賓福特', '般尼茅斯': '般尼茅斯',
        '富咸': '富咸', '水晶宮': '水晶宮', '白禮頓': '白禮頓',
        '修咸頓': '修咸頓', '伊普斯維奇': '伊普斯維奇', '諾定咸森林': '諾定咸森林',
        '李斯特城': '李斯特城',
        '皇家馬': '皇家馬德里', '皇馬': '皇家馬德里', '巴塞': '巴塞隆拿',
        '馬體會': '馬德里體育會', '馬德里體育會': '馬德里體育會',
        '巴黎': '巴黎聖日耳門', '拜仁': '拜仁慕尼黑',
        '利華古遜': '利華古遜', '多蒙特': '多蒙特',
        '國際米蘭': '國際米蘭', 'AC米蘭': 'AC米蘭', '祖雲達斯': '祖雲達斯',
        '拿坡里': '拿坡里', '費倫天拿': '費倫天拿', '亞特蘭大': '阿特蘭大',
        '些路迪': '些路蒂', '加拉塔沙雷': '加拉塔沙雷',
    }

    title = headline.get('title', '')
    found_teams = []
    for short, full in team_map.items():
        if short in title:
            found_teams.append(full)

    # Detect score patterns like "3:1", "0:1", "1：1"
    import re
    score_match = re.search(r'(\d+)\s*[:\：]\s*(\d+)', title)

    # Detect sentiment
    positive_words = ['勝', '贏', '大勝', '狂勝', '險勝', '榜首', '冠軍', '極佳', '回勇', '強勢']
    negative_words = ['負', '敗', '慘敗', '失分', '失守', '低迷', '不敵', '頹勢', '出局', '落後']
    draw_words = ['和', '逼和', '打和']

    sentiment = 'neutral'
    for w in positive_words:
        if w in title:
            sentiment = 'positive'
            break
    for w in negative_words:
        if w in title:
            sentiment = 'negative'
            break
    for w in draw_words:
        if w in title:
            sentiment = 'draw'
            break

    return {
        'teams': found_teams,
        'score': f"{score_match.group(1)}-{score_match.group(2)}" if score_match else None,
        'sentiment': sentiment,
        'tag': headline.get('tag', ''),
        'date': headline.get('date', ''),
    }


def build_team_news_from_headlines(headlines):
    """Aggregate headlines into per-team news analysis"""
    team_data = {}

    for h in headlines:
        analysis = analyze_headline(h)
        for team in analysis['teams']:
            if team not in team_data:
                team_data[team] = {
                    'headlines': [],
                    'wins': 0, 'draws': 0, 'losses': 0,
                    'results': []
                }
            team_data[team]['headlines'].append(h['title'])

            if analysis['sentiment'] == 'positive':
                team_data[team]['wins'] += 1
            elif analysis['sentiment'] == 'negative':
                team_data[team]['losses'] += 1
            elif analysis['sentiment'] == 'draw':
                team_data[team]['draws'] += 1

    # Convert to teamNews format
    team_news = {}
    for team, data in team_data.items():
        w, d, l = data['wins'], data['draws'], data['losses']
        total = w + d + l

        if total == 0:
            form = 'average'
        elif w / max(total, 1) >= 0.6:
            form = 'excellent'
        elif w / max(total, 1) >= 0.4:
            form = 'good'
        elif l / max(total, 1) >= 0.6:
            form = 'poor'
        else:
            form = 'average'

        if form in ('excellent', 'good'):
            morale = 'high'
        elif form == 'poor':
            morale = 'low'
        else:
            morale = 'medium'

        team_news[team] = {
            'form': form,
            'morale': morale,
            'injuries': [],
            'news': data['headlines'][0][:60] if data['headlines'] else '',
            'recentResults': [],
            'keyFact': f"近{total}條新聞: {w}正面 {d}平手 {l}負面" if total > 0 else ''
        }

    return team_news


if __name__ == '__main__':
    # This is a helper - the actual scraping needs browser access
    # Load existing news-data.json if available
    path = f'{BASE}/news-data.json'
    if os.path.exists(path):
        with open(path) as f:
            nd = json.load(f)
        print(f"Existing news-data.json: {len(nd.get('headlines',[]))} headlines, {len(nd.get('teamNews',{}))} teams")
        print(f"Source: {nd.get('source')}, Scraped: {nd.get('scraped')}")

        # Auto-analyze headlines
        auto_news = build_team_news_from_headlines(nd.get('headlines', []))
        print(f"\nAuto-analysis found {len(auto_news)} teams from headlines")
        for team, data in sorted(auto_news.items()):
            print(f"  {team}: form={data['form']}, morale={data['morale']}")
    else:
        print("No news-data.json found. Scrape tipsme.hk first.")
