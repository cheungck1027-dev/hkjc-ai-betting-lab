#!/usr/bin/env python3
"""
HKJC AI Betting Lab - Main Server
==================================
- Serves the dashboard
- Auto-fetches real HKJC data every 10 min (or 2 min during live matches)
- Runs betting engine + settlement automatically
- WebSocket for live updates
"""

import os, json, time, threading, subprocess, sys
from datetime import datetime
from flask import Flask, send_from_directory, jsonify, send_file

app = Flask(__name__, static_folder='static')

BASE = os.path.join(os.path.dirname(__file__), 'data')
STATIC = os.path.join(os.path.dirname(__file__), 'static')
os.makedirs(BASE, exist_ok=True)
os.makedirs(STATIC, exist_ok=True)

# ── Status tracking ──
status = {
    'lastFetch': None,
    'lastBuild': None,
    'lastError': None,
    'isLive': False,
    'matchCount': 0,
    'charCount': 100,
    'autoRunning': True,
    'fetchInterval': 600,  # 10 min default
    'liveInterval': 120,   # 2 min during live
}

def load_json(name, default=None):
    path = os.path.join(BASE, name)
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    return default if default is not None else []

def run_script(name, args=None):
    """Run a python script in the project directory"""
    script = os.path.join(os.path.dirname(__file__), name)
    if not os.path.exists(script):
        print(f"  ⚠️ Script not found: {name}")
        return False
    cmd = [sys.executable, script] + (args or [])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120,
                                cwd=os.path.dirname(__file__))
        if result.stdout:
            print(result.stdout)
        if result.returncode != 0:
            print(f"  ❌ {name} error: {result.stderr}")
            return False
        return True
    except Exception as e:
        print(f"  ❌ {name} exception: {e}")
        return False

def full_pipeline():
    """Run the complete data pipeline:
    1. Fetch real HKJC data
    2. Run betting engine (AI characters make decisions)
    3. Settle finished matches
    4. Generate extras (report, social, analysis, inplay, achievements)
    5. Build dashboard
    """
    print(f"\n{'='*50}")
    print(f"🔄 Full pipeline run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*50}")

    try:
        # Step 1: Fetch real data
        print("\n📡 Step 1: Fetching HKJC data...")
        run_script('fetch_hkjc.py')
        status['lastFetch'] = datetime.now().isoformat()

        # Step 2: Run betting engine
        print("\n🎰 Step 2: Running betting engine...")
        run_script('ai_betting_engine_v3.py')

        # Step 3: Settle bets
        print("\n💰 Step 3: Settling bets...")
        run_script('settle_bets.py')

        # Step 4: Generate extras
        print("\n📊 Step 4: Generating extras...")
        run_script('generate_extras.py')

        # Step 5: In-play engine
        print("\n⚡ Step 5: Running in-play engine...")
        run_script('inplay_engine.py')

        # Step 6: Build dashboard
        print("\n🏗️ Step 6: Building dashboard...")
        run_script('build_dashboard.py')
        run_script('build_ultimate.py')

        status['lastBuild'] = datetime.now().isoformat()
        status['lastError'] = None

        # Update match count
        matches = load_json('matches.json', [])
        status['matchCount'] = len(matches)

        # Check if any match is live
        from fetch_hkjc import is_match_live
        status['isLive'] = is_match_live()

        print(f"\n✅ Pipeline complete! {len(matches)} matches, live={status['isLive']}")

    except Exception as e:
        status['lastError'] = str(e)
        print(f"\n❌ Pipeline error: {e}")

def auto_runner():
    """Background thread: runs pipeline on schedule"""
    # Wait for initial startup
    time.sleep(5)

    # Run initial pipeline
    full_pipeline()

    while status['autoRunning']:
        # Determine interval: 2 min if live, 10 min otherwise
        interval = status['liveInterval'] if status['isLive'] else status['fetchInterval']
        print(f"\n⏰ Next run in {interval}s ({'LIVE MODE' if status['isLive'] else 'normal'})")

        # Sleep in small chunks so we can stop quickly
        for _ in range(interval):
            if not status['autoRunning']:
                break
            time.sleep(1)

        if status['autoRunning']:
            full_pipeline()

# ── Routes ──

@app.route('/')
def index():
    """Serve the dashboard"""
    # Try full-dashboard.html first (single file), then index.html
    for fname in ['full-dashboard.html', 'index.html']:
        path = os.path.join(BASE, fname)
        if os.path.exists(path):
            return send_file(path)
    return '<h1>Dashboard not built yet. Waiting for first pipeline run...</h1>', 503

@app.route('/data/<path:filename>')
def serve_data(filename):
    """Serve data files (JS, JSON)"""
    return send_from_directory(BASE, filename)

@app.route('/<path:filename>')
def serve_root_file(filename):
    """Serve files from data directory (for JS imports in index.html)"""
    path = os.path.join(BASE, filename)
    if os.path.exists(path):
        return send_from_directory(BASE, filename)
    return 'Not found', 404

@app.route('/api/status')
def api_status():
    return jsonify(status)

@app.route('/api/refresh', methods=['POST'])
def api_refresh():
    """Manually trigger a pipeline run"""
    threading.Thread(target=full_pipeline, daemon=True).start()
    return jsonify({'ok': True, 'message': 'Pipeline started'})

@app.route('/api/matches')
def api_matches():
    return jsonify(load_json('matches.json', []))

@app.route('/api/characters')
def api_characters():
    return jsonify(load_json('characters.json', []))

@app.route('/api/state')
def api_state():
    return jsonify(load_json('state.json', {}))

# ── Start ──
if __name__ == '__main__':
    print("🏈 HKJC AI Betting Lab Server Starting...")
    print(f"📂 Data directory: {BASE}")

    # Start auto-runner in background
    runner_thread = threading.Thread(target=auto_runner, daemon=True)
    runner_thread.start()

    # Start Flask
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
